
#!/bin/bash

echo "Bootstrapping EKS FinOps AI Agent Platform"

python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt

echo "Environment setup complete"
