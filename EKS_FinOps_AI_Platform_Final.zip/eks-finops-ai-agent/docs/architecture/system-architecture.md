
# System Architecture

## Core Principles

- Modular agent-based design
- Read-only analysis in initial phases
- Deterministic calculations before LLM reasoning
- Structured JSON communication between agents
- Historical trend-based optimization

---

## Architecture Layers

### Data Sources
- AWS Cost Explorer
- AWS Pricing API
- EKS APIs
- EC2 APIs
- Prometheus
- Kubernetes API

### Intelligence Layer
- Billing Intelligence Agent
- Metrics Intelligence Agent
- Cost Attribution Agent
- Optimization Recommendation Agent

### AI Layer
- LLM Reporting Agent
- Conversational Analysis

### Orchestration Layer
- Master Orchestrator Agent

---

## Recommended Analysis Windows

| Analysis Type | Window |
|---|---|
| Rightsizing | 30 days |
| Cost Trends | 90 days |
| Forecasting | 3-12 months |
| Spot Analysis | 14 days |
