
# Phase 1 — Billing Intelligence Agent

## Goal

Analyze AWS EKS-related cloud spending.

---

## Responsibilities

- Fetch AWS billing data
- Identify EKS-related infra costs
- Analyze trends
- Detect anomalies
- Generate structured outputs
- Generate LLM summaries

---

## AWS Services Used

- AWS Cost Explorer
- AWS Pricing API
- AWS EC2 APIs
- AWS EKS APIs

---

## Initial Deliverables

- Daily cost reports
- Monthly trend analysis
- Cost spike detection
- Top cost contributor analysis
- AI-generated summaries

---

## Future Enhancements

- CUR integration
- Forecasting
- Multi-account analysis
- Savings Plans analysis
- RI recommendations
