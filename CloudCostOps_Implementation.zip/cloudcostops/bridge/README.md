# The Bridge Service + `ccops` CLI

This folder contains the only code you need to build and run. Everything
here is plain Python with very few dependencies.

## Files in this folder

| File                  | What it does                                                       |
|-----------------------|--------------------------------------------------------------------|
| `ccops`               | The command-line tool you run. Parses commands, prints answers.    |
| `bridge.py`           | The orchestrator — ties OptScale, the prompt, and Gauss together.  |
| `optscale_client.py`  | All code that talks to OptScale. The only file that knows its API. |
| `gauss_client.py`     | All code that talks to Gauss. The only file that knows its API.    |
| `prompt_builder.py`   | Turns cost data + a question into a structured prompt for the AI.  |
| `config.py`           | Loads settings from your `.env` file.                              |
| `.env.example`        | Template for your settings. Copy to `.env` and fill in.            |
| `requirements.txt`    | The Python packages to install.                                    |
| `tests/test_bridge.py`| Basic tests — run `pytest` to confirm everything is wired up.      |

## How the pieces fit together

```
   ccops  ──calls──►  bridge.py
                         │
                         ├──► optscale_client.py ──► OptScale (cost data)
                         │
                         ├──► prompt_builder.py  (data + question -> prompt)
                         │
                         └──► gauss_client.py    ──► Gauss (the AI answer)
```

The `ccops` CLI never talks to OptScale or Gauss directly. It only ever
calls `bridge.py`. That keeps each file small and easy to understand.

## Run it (mock mode — works immediately)

```bash
python3 -m venv venv
source venv/bin/activate           # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env               # mock mode is the default
chmod +x ccops
./ccops doctor                     # confirms your setup
./ccops ask "why did our bill go up?"
```

## Run the tests

```bash
pytest
```

All tests run in mock mode, so they need no real services.

## Switching to real services

1. Stand up OptScale — see `../docs/02-install-optscale.md`.
2. Get your OptScale URL, token and org ID — see `../docs/03-configure-optscale.md`.
3. Get your Gauss URL and API key from your Gauss team.
4. Edit `.env`: set `MOCK_MODE=false` and fill in the values.
5. Run `./ccops doctor` — it will tell you if anything is missing.

## Where to customise

| You want to…                                  | Edit this file        |
|------------------------------------------------|-----------------------|
| Change how the AI is asked / its tone          | `prompt_builder.py`   |
| Add a new `ccops` command                      | `ccops` + `bridge.py` |
| Fix an OptScale API endpoint path              | `optscale_client.py`  |
| Adjust the Gauss request/response shape        | `gauss_client.py`     |
| Add a new setting                              | `config.py` + `.env`  |

## Security notes (even on one internal network)

- **Secrets** live only in `.env`, which you never commit to git.
- The Bridge **authenticates** to both OptScale and Gauss (tokens in `.env`).
- Every question is written to an **audit log** (`ccops_audit.log`).
- When you deploy this for the team, run it on a shared server, put the
  `ccops` command behind your normal SSO/login, and keep the audit log.
