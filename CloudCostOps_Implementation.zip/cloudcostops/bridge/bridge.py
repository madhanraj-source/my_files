"""
bridge.py
---------
The Bridge is the "orchestrator". It ties everything together:

    1. Ask OptScale for the relevant cost data
    2. Use prompt_builder to turn that data into a prompt
    3. Send the prompt to Gauss
    4. Return the answer (plus the raw data, in case the CLI wants it)

The CLI (`ccops`) calls the methods on this class. The Bridge does not
know or care whether it is talking to real services or mock data — that
decision lives in config.py / the client classes.
"""

import datetime
from config import Config
from optscale_client import OptScaleClient
from gauss_client import GaussClient
from prompt_builder import build_prompt


class BridgeResult:
    """A small container for what the Bridge returns to the CLI."""
    def __init__(self, answer: str, raw_data: dict, question: str):
        self.answer = answer        # the plain-English answer from Gauss
        self.raw_data = raw_data    # the underlying OptScale data
        self.question = question    # the question that was asked


class Bridge:
    """The orchestration layer between the CLI, OptScale, and Gauss."""

    def __init__(self):
        self.optscale = OptScaleClient()
        self.gauss = GaussClient()

    # ------------------------------------------------------------------
    # One private helper that all the commands share.
    # ------------------------------------------------------------------
    def _run(self, question: str, data: dict) -> BridgeResult:
        """Build a prompt from `data`, ask Gauss, log it, return the result."""
        prompt = build_prompt(question, data)
        answer = self.gauss.ask(prompt)
        self._audit(question)
        return BridgeResult(answer=answer, raw_data=data, question=question)

    def _audit(self, question: str):
        """Append the question to a local audit log (who asked what, when)."""
        try:
            line = f"{datetime.datetime.now().isoformat()}\t{question}\n"
            with open(Config.AUDIT_LOG, "a", encoding="utf-8") as f:
                f.write(line)
        except Exception:
            # Auditing must never crash the tool. If it fails, carry on.
            pass

    # ------------------------------------------------------------------
    # The commands — one method per `ccops` sub-command.
    # ------------------------------------------------------------------
    def handle_anomaly(self, days=None) -> BridgeResult:
        """`ccops anomaly` — investigate recent cost spikes."""
        data = self.optscale.get_anomalies(days=days)
        question = "Why did our cloud costs change recently? What is the root cause?"
        return self._run(question, data)

    def handle_cost(self, service=None, days=None) -> BridgeResult:
        """`ccops cost` — explain the cost breakdown, optionally for one service."""
        data = self.optscale.get_cost_by_service(days=days, service=service)
        if service:
            question = f"Explain our {service} spend and whether it is trending up or down."
        else:
            question = "Explain our overall cloud cost breakdown by service."
        return self._run(question, data)

    def handle_recommend(self, top=3) -> BridgeResult:
        """`ccops recommend` — triage the most impactful savings actions."""
        data = self.optscale.get_recommendations(top=top)
        question = (
            f"Which {top} recommendations should we act on first, and why? "
            "Mention the potential savings."
        )
        return self._run(question, data)

    def handle_ask(self, question: str, days=None) -> BridgeResult:
        """
        `ccops ask "..."` — a free-form question.
        We give Gauss a broad context (summary + services + anomalies) so it
        can answer whatever was asked.
        """
        data = {
            "summary": self.optscale.get_cost_summary(days=days),
            "by_service": self.optscale.get_cost_by_service(days=days),
            "anomalies": self.optscale.get_anomalies(days=days),
        }
        return self._run(question, data)

    # ------------------------------------------------------------------
    # Health check — used by `ccops doctor`.
    # ------------------------------------------------------------------
    def health(self) -> dict:
        """Check that the Bridge can reach its dependencies."""
        return {
            "mode": "mock" if Config.MOCK_MODE else "real",
            "optscale_reachable": self.optscale.healthcheck(),
            "gauss_reachable": self.gauss.healthcheck(),
        }
