"""
optscale_client.py
------------------
Talks to OptScale — the tool that holds all your cloud cost data.

This file is the ONLY place that knows about OptScale's API. If OptScale
changes, you only fix things here; the rest of the Bridge stays the same.

IMPORTANT FOR REAL MODE:
  OptScale's exact API endpoint paths can differ slightly between versions.
  The real API calls below are written against OptScale's documented REST API,
  but you should confirm the paths against YOUR installation's API docs:
        https://<your-optscale-host>/docs   (or the OptScale GitHub docs)
  The methods are clearly marked with "VERIFY:" comments where this matters.

In MOCK mode none of this matters — the client returns realistic sample data.
"""

import requests
from config import Config


class OptScaleClient:
    """A thin wrapper around the OptScale REST API."""

    def __init__(self):
        self.base_url = Config.OPTSCALE_URL
        self.token = Config.OPTSCALE_TOKEN
        self.org_id = Config.OPTSCALE_ORG_ID
        self.mock = Config.MOCK_MODE
        self.timeout = Config.REQUEST_TIMEOUT

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------
    def _headers(self):
        # OptScale uses a token in the request header for authentication.
        return {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.token}",
        }

    def _get(self, path, params=None):
        """Make a GET request to OptScale and return parsed JSON."""
        url = f"{self.base_url}{path}"
        resp = requests.get(url, headers=self._headers(),
                            params=params, timeout=self.timeout)
        resp.raise_for_status()  # raises an error if the request failed
        return resp.json()

    # ------------------------------------------------------------------
    # Public methods — these are what the Bridge calls
    # ------------------------------------------------------------------
    def get_cost_summary(self, days=None):
        """Total spend over the last `days`, plus the previous period to compare."""
        days = days or Config.DEFAULT_WINDOW_DAYS
        if self.mock:
            return self._mock_cost_summary(days)
        # VERIFY: confirm this endpoint path against your OptScale API docs.
        return self._get(
            f"/restapi/v2/organizations/{self.org_id}/summary_expenses",
            params={"start_date": _days_ago(days * 2), "end_date": _today()},
        )

    def get_cost_by_service(self, days=None, service=None):
        """Spend broken down by cloud service (EKS, S3, RDS, ...)."""
        days = days or Config.DEFAULT_WINDOW_DAYS
        if self.mock:
            return self._mock_cost_by_service(days, service)
        # VERIFY: confirm this endpoint path against your OptScale API docs.
        data = self._get(
            f"/restapi/v2/organizations/{self.org_id}/breakdown_expenses",
            params={"breakdown_by": "service_name",
                    "start_date": _days_ago(days), "end_date": _today()},
        )
        return data

    def get_anomalies(self, days=None):
        """Cost anomalies OptScale has detected (unexpected spikes/drops)."""
        days = days or Config.DEFAULT_WINDOW_DAYS
        if self.mock:
            return self._mock_anomalies(days)
        # VERIFY: confirm this endpoint path against your OptScale API docs.
        return self._get(
            f"/restapi/v2/organizations/{self.org_id}/optimizations",
            params={"types": "anomaly"},
        )

    def get_recommendations(self, top=None):
        """OptScale's cost-saving recommendations (rightsizing, idle resources...)."""
        if self.mock:
            return self._mock_recommendations(top)
        # VERIFY: confirm this endpoint path against your OptScale API docs.
        return self._get(
            f"/restapi/v2/organizations/{self.org_id}/optimizations",
        )

    def healthcheck(self):
        """Quick check that OptScale is reachable. Returns True/False."""
        if self.mock:
            return True
        try:
            requests.get(f"{self.base_url}/restapi/v2/version",
                         timeout=self.timeout)
            return True
        except Exception:
            return False

    # ------------------------------------------------------------------
    # MOCK DATA — realistic sample data so you can develop without OptScale
    # ------------------------------------------------------------------
    def _mock_cost_summary(self, days):
        return {
            "window_days": days,
            "current_period_total": 184302.55,
            "previous_period_total": 173901.10,
            "change_pct": 5.98,
            "currency": "USD",
        }

    def _mock_cost_by_service(self, days, service):
        services = [
            {"service": "AmazonEKS", "current": 24180.40, "previous": 19655.00, "change_pct": 23.0},
            {"service": "AmazonS3", "current": 8910.25, "previous": 8020.00, "change_pct": 11.1},
            {"service": "AmazonRDS", "current": 31420.00, "previous": 31100.00, "change_pct": 1.0},
            {"service": "AmazonEC2", "current": 78500.00, "previous": 79010.00, "change_pct": -0.6},
            {"service": "AmazonCloudWatch", "current": 4120.00, "previous": 3990.00, "change_pct": 3.3},
        ]
        if service:
            s = service.lower()
            services = [x for x in services if s in x["service"].lower()]
        return {"window_days": days, "services": services, "currency": "USD"}

    def _mock_anomalies(self, days):
        return {
            "window_days": days,
            "anomalies": [
                {
                    "id": "anomaly-91f",
                    "service": "AmazonEKS",
                    "region": "us-east-1",
                    "baseline_weekly": 412.50,
                    "current_weekly": 507.40,
                    "change_pct": 23.0,
                    "first_seen": _days_ago(6),
                    "top_driver": {
                        "resource": "node-group-prod-3",
                        "detail": "14 new pods created",
                        "created_on": _days_ago(6),
                    },
                },
                {
                    "id": "anomaly-22a",
                    "service": "AmazonS3",
                    "region": "us-east-1",
                    "baseline_weekly": 180.00,
                    "current_weekly": 201.00,
                    "change_pct": 11.7,
                    "first_seen": _days_ago(4),
                    "top_driver": {
                        "resource": "bucket: app-logs-prod",
                        "detail": "log retention increased; stored data up ~40%",
                        "created_on": None,
                    },
                },
            ],
        }

    def _mock_recommendations(self, top):
        recs = [
            {"title": "Rightsize 8 over-provisioned dev EC2 instances",
             "monthly_saving": 1840.00, "category": "rightsizing", "effort": "low"},
            {"title": "Delete 14 unattached EBS volumes",
             "monthly_saving": 420.00, "category": "idle_resources", "effort": "low"},
            {"title": "Buy a Savings Plan for steady-state RDS usage",
             "monthly_saving": 2600.00, "category": "commitment", "effort": "medium"},
            {"title": "Schedule non-prod EKS node groups to stop overnight",
             "monthly_saving": 980.00, "category": "scheduling", "effort": "medium"},
            {"title": "Move infrequently-accessed S3 data to a cheaper tier",
             "monthly_saving": 310.00, "category": "storage_tiering", "effort": "low"},
        ]
        # Sort by biggest saving first.
        recs.sort(key=lambda r: r["monthly_saving"], reverse=True)
        if top:
            recs = recs[:top]
        return {"recommendations": recs, "currency": "USD"}


# ---------------------------------------------------------------------
# Tiny date helpers (kept here so this file has no extra dependencies)
# ---------------------------------------------------------------------
def _today():
    from datetime import date
    return date.today().isoformat()


def _days_ago(n):
    from datetime import date, timedelta
    return (date.today() - timedelta(days=n)).isoformat()
