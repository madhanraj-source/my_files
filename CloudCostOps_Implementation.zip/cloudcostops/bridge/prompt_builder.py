"""
prompt_builder.py
-----------------
Turns raw cost data from OptScale into a well-structured prompt for Gauss.

A good prompt has three parts:
  SYSTEM   — who the AI is and how it should behave
  CONTEXT  — the actual data (facts from OptScale)
  QUESTION — what the user asked

Keeping prompt-building in its own file means you can improve how the AI
is asked WITHOUT touching the data or networking code.
"""

import json

# The SYSTEM message is the AI's "job description". Tweak this text to
# change the tone and style of every answer the tool gives.
SYSTEM_PROMPT = (
    "You are a senior FinOps analyst. You explain cloud cost data in clear, "
    "plain English for engineers. Be concise and specific. When you identify "
    "a cost increase, name the service and the likely driver, and finish with "
    "one practical recommendation. Do not invent numbers that are not in the "
    "data you are given."
)


def _format_context(data: dict) -> str:
    """
    Turn the OptScale data (a Python dict) into clean text the AI can read.
    We use indented JSON because it is readable and unambiguous.
    """
    return "COST DATA FROM OPTSCALE:\n" + json.dumps(data, indent=2)


def build_prompt(question: str, data: dict) -> dict:
    """
    Build the three-part prompt.

    Returns a dict:
        { "system": "...", "context": "...", "question": "..." }
    which is exactly what GaussClient.ask() expects.
    """
    return {
        "system": SYSTEM_PROMPT,
        "context": _format_context(data),
        "question": question.strip(),
    }
