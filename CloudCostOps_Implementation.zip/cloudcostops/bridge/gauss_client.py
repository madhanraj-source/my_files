"""
gauss_client.py
---------------
Talks to Gauss — your internal AI model that does the reasoning.

This file is the ONLY place that knows about the Gauss API. If the Gauss
API shape is different at your company, you only adjust things here.

IMPORTANT FOR REAL MODE:
  Every internal LLM API is slightly different. The `ask()` method below
  uses a common request/response shape, but you MUST confirm:
    - the exact URL path (e.g. /v1/chat, /generate, /completions ...)
    - the request body field names
    - where the answer text sits in the response JSON
  against your Gauss API documentation. The spots to check are marked
  with "VERIFY:" comments.

In MOCK mode none of this matters — the client produces a realistic
plain-English answer from the context it was given.
"""

import requests
from config import Config


class GaussClient:
    """A thin wrapper around the Gauss internal LLM API."""

    def __init__(self):
        self.url = Config.GAUSS_URL
        self.api_key = Config.GAUSS_API_KEY
        self.model = Config.GAUSS_MODEL
        self.mock = Config.MOCK_MODE
        self.timeout = Config.REQUEST_TIMEOUT

    def ask(self, prompt: dict) -> str:
        """
        Send a prompt to Gauss and return the answer as plain text.

        `prompt` is a dict with three parts (built by prompt_builder.py):
            { "system": "...", "context": "...", "question": "..." }
        """
        if self.mock:
            return self._mock_answer(prompt)

        # VERIFY: confirm the URL path for your Gauss deployment.
        url = f"{self.url}/v1/chat/completions"

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }

        # VERIFY: confirm the request body shape your Gauss API expects.
        # This uses the common "messages" format. Some internal models
        # instead expect a single "prompt" string — adjust if needed.
        body = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": prompt["system"]},
                {"role": "user",
                 "content": f"{prompt['context']}\n\nQUESTION: {prompt['question']}"},
            ],
        }

        resp = requests.post(url, headers=headers, json=body,
                             timeout=self.timeout)
        resp.raise_for_status()
        data = resp.json()

        # VERIFY: confirm where the answer text sits in the response.
        # Common shape: data["choices"][0]["message"]["content"]
        try:
            return data["choices"][0]["message"]["content"].strip()
        except (KeyError, IndexError):
            # Fallback so you can see the raw response while debugging.
            return f"[Could not parse Gauss response. Raw JSON]\n{data}"

    def healthcheck(self) -> bool:
        """Quick check that Gauss is reachable. Returns True/False."""
        if self.mock:
            return True
        try:
            requests.get(self.url, timeout=self.timeout)
            return True
        except Exception:
            return False

    # ------------------------------------------------------------------
    # MOCK ANSWER — produces a realistic plain-English response so you can
    # see what good output looks like without a real Gauss connection.
    # ------------------------------------------------------------------
    def _mock_answer(self, prompt: dict) -> str:
        context = prompt.get("context", "")
        question = prompt.get("question", "").lower()

        # The mock "reasons" by looking for clues in the context text.
        if "anomaly" in context.lower() or "anomal" in question:
            return (
                "The main cost increase is in Amazon EKS (us-east-1), up about "
                "23% week-over-week. The driver is node-group-prod-3 — 14 new "
                "pods were created roughly 6 days ago and the cluster scaled up "
                "but never scaled back down. There is also a smaller S3 increase "
                "(~12%) from a log-retention change.\n\n"
                "Recommendation: review the HPA thresholds and cluster-autoscaler "
                "scale-down settings for that node group, and check whether the "
                "new workload's resource requests are over-provisioned."
            )
        if "recommend" in context.lower() or "recommend" in question or "save" in question:
            return (
                "The three highest-impact actions right now:\n"
                "  1. Buy a Savings Plan for steady-state RDS usage — ~$2,600/month.\n"
                "  2. Rightsize 8 over-provisioned dev EC2 instances — ~$1,840/month.\n"
                "  3. Schedule non-prod EKS node groups to stop overnight — ~$980/month.\n\n"
                "Items 1 and 2 are low effort. Together these recommendations "
                "represent roughly $5,400/month in potential savings."
            )
        if "service" in question or "breakdown" in context.lower():
            return (
                "Spend is concentrated in three services: EC2 is the largest line "
                "item but is essentially flat. EKS rose ~23% and is the main reason "
                "the overall bill moved. S3 is up ~11%. RDS and CloudWatch are "
                "broadly stable.\n\n"
                "If you want to bring the bill down, EKS is where the attention "
                "should go — it is both large and trending up."
            )
        # Generic fallback.
        return (
            "Based on the cost data provided: the overall bill rose about 6% "
            "versus the previous period. The increase is led by Amazon EKS, "
            "with a smaller contribution from S3. Most other services are stable.\n\n"
            "The clearest next step is to investigate the EKS increase — see "
            "`ccops anomaly` for the detailed root cause."
        )
