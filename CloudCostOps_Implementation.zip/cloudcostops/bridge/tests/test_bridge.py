"""
test_bridge.py
--------------
Basic tests for the Bridge. These run entirely in MOCK mode, so they need
no real OptScale or Gauss — they just confirm the wiring works.

Run them with:
    cd bridge
    pytest

If all tests pass, your Bridge logic is sound.
"""

import os
import sys

# Make sure we can import the bridge modules regardless of where pytest is run.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Force mock mode for tests, no matter what the .env says.
os.environ["MOCK_MODE"] = "true"

from bridge import Bridge          # noqa: E402
from optscale_client import OptScaleClient  # noqa: E402
from gauss_client import GaussClient        # noqa: E402
from prompt_builder import build_prompt     # noqa: E402


def test_optscale_mock_returns_data():
    """OptScale client (mock) should return non-empty cost data."""
    client = OptScaleClient()
    summary = client.get_cost_summary()
    assert summary["current_period_total"] > 0
    assert "services" in client.get_cost_by_service()
    assert "anomalies" in client.get_anomalies()
    assert "recommendations" in client.get_recommendations()


def test_prompt_builder_has_three_parts():
    """A built prompt must always have system, context and question."""
    prompt = build_prompt("why did costs rise?", {"some": "data"})
    assert "system" in prompt and prompt["system"]
    assert "context" in prompt and "some" in prompt["context"]
    assert prompt["question"] == "why did costs rise?"


def test_gauss_mock_returns_text():
    """Gauss client (mock) should return a non-empty string answer."""
    client = GaussClient()
    prompt = build_prompt("explain anomalies", {"anomalies": []})
    answer = client.ask(prompt)
    assert isinstance(answer, str)
    assert len(answer) > 10


def test_bridge_anomaly_end_to_end():
    """The whole flow: Bridge -> OptScale -> prompt -> Gauss -> result."""
    bridge = Bridge()
    result = bridge.handle_anomaly()
    assert result.answer            # we got an answer
    assert result.raw_data          # we got the underlying data
    assert "anomal" in result.question.lower() or "cost" in result.question.lower()


def test_bridge_recommend_respects_top():
    """`recommend --top N` should pass N through to OptScale."""
    bridge = Bridge()
    result = bridge.handle_recommend(top=2)
    assert len(result.raw_data["recommendations"]) == 2


def test_bridge_health_in_mock_mode():
    """In mock mode, the health check should report everything reachable."""
    bridge = Bridge()
    health = bridge.health()
    assert health["mode"] == "mock"
    assert health["optscale_reachable"] is True
    assert health["gauss_reachable"] is True
