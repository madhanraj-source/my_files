"""
config.py
---------
Loads all settings for the Bridge from a `.env` file.

Why a .env file?
  - It keeps secrets (API tokens) OUT of the code.
  - You never commit `.env` to git — only `.env.example` (the template).

You do not normally edit this file. You edit `.env`.
"""

import os
import sys

# python-dotenv reads the .env file and loads it into environment variables.
try:
    from dotenv import load_dotenv
except ImportError:
    print("ERROR: python-dotenv is not installed.")
    print("Run:  pip install -r requirements.txt")
    sys.exit(1)

# Load the .env file that sits next to this code.
_here = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(_here, ".env"))


def _get_bool(name: str, default: str = "false") -> bool:
    """Read an environment variable and interpret it as true/false."""
    return os.getenv(name, default).strip().lower() in ("true", "1", "yes", "on")


class Config:
    """All Bridge settings in one place."""

    # ----- Mode -----
    # When MOCK_MODE is true, the Bridge uses built-in sample data instead of
    # talking to real OptScale / Gauss. Great for learning and development.
    MOCK_MODE = _get_bool("MOCK_MODE", "true")

    # ----- OptScale (the cost data source) -----
    OPTSCALE_URL = os.getenv("OPTSCALE_URL", "").rstrip("/")
    OPTSCALE_TOKEN = os.getenv("OPTSCALE_TOKEN", "")
    OPTSCALE_ORG_ID = os.getenv("OPTSCALE_ORG_ID", "")

    # ----- Gauss (the AI reasoning model) -----
    GAUSS_URL = os.getenv("GAUSS_URL", "").rstrip("/")
    GAUSS_API_KEY = os.getenv("GAUSS_API_KEY", "")
    GAUSS_MODEL = os.getenv("GAUSS_MODEL", "gauss-default")

    # ----- Behaviour -----
    # How many days of cost history to look at by default.
    DEFAULT_WINDOW_DAYS = int(os.getenv("DEFAULT_WINDOW_DAYS", "30"))
    # Network timeout (seconds) for calls to OptScale and Gauss.
    REQUEST_TIMEOUT = int(os.getenv("REQUEST_TIMEOUT", "30"))
    # Write every query to a local log file for auditing.
    AUDIT_LOG = os.getenv("AUDIT_LOG", "ccops_audit.log")

    @classmethod
    def validate(cls):
        """
        Check that required settings are present.
        In mock mode nothing is required. In real mode we need the URLs/tokens.
        Returns a list of human-readable problems (empty list = all good).
        """
        problems = []
        if cls.MOCK_MODE:
            return problems  # nothing required in mock mode

        if not cls.OPTSCALE_URL:
            problems.append("OPTSCALE_URL is empty (set it in .env)")
        if not cls.OPTSCALE_TOKEN:
            problems.append("OPTSCALE_TOKEN is empty (set it in .env)")
        if not cls.OPTSCALE_ORG_ID:
            problems.append("OPTSCALE_ORG_ID is empty (set it in .env)")
        if not cls.GAUSS_URL:
            problems.append("GAUSS_URL is empty (set it in .env)")
        if not cls.GAUSS_API_KEY:
            problems.append("GAUSS_API_KEY is empty (set it in .env)")
        return problems

    @classmethod
    def describe(cls) -> str:
        """A short human-readable summary of the current mode."""
        if cls.MOCK_MODE:
            return "MODE: mock (using built-in sample data — no real services contacted)"
        return f"MODE: real (OptScale: {cls.OPTSCALE_URL} | Gauss: {cls.GAUSS_URL})"
