#!/usr/bin/env bash
# ======================================================================
#  healthcheck.sh — quick check that your CloudCostOps setup is healthy
# ======================================================================
#  Run this from anywhere:
#      bash scripts/healthcheck.sh
#
#  It checks:
#    1. Python is installed
#    2. The Bridge dependencies are installed
#    3. The .env file exists
#    4. `ccops doctor` runs cleanly
# ======================================================================

set -u

# Find the bridge folder relative to this script.
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BRIDGE_DIR="$(cd "$SCRIPT_DIR/../bridge" && pwd)"

echo "=== CloudCostOps health check ==="
echo

# 1. Python
if command -v python3 >/dev/null 2>&1; then
    echo "[OK]   python3 found: $(python3 --version 2>&1)"
else
    echo "[FAIL] python3 not found. Install it: sudo apt install python3 python3-venv python3-pip"
    exit 1
fi

# 2. Dependencies (check one known package)
if python3 -c "import requests, dotenv" >/dev/null 2>&1; then
    echo "[OK]   Bridge dependencies are installed"
else
    echo "[WARN] Bridge dependencies not found."
    echo "       Run:  cd $BRIDGE_DIR && pip install -r requirements.txt"
fi

# 3. .env file
if [ -f "$BRIDGE_DIR/.env" ]; then
    echo "[OK]   .env file exists"
else
    echo "[WARN] .env file missing."
    echo "       Run:  cd $BRIDGE_DIR && cp .env.example .env"
fi

# 4. ccops doctor
echo
echo "--- running 'ccops doctor' ---"
cd "$BRIDGE_DIR" && python3 ccops doctor

echo
echo "=== health check complete ==="
