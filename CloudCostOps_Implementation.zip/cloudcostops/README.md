# CloudCostOps — Implementation Package

An AI-powered FinOps assistant that lets engineers ask about cloud costs
in **plain English** from the command line. It runs entirely inside your
own network.

```
  You type:   $ ccops ask "why did our bill go up last week?"
  You get:    A clear, plain-English answer — reasoned from your real cost data.
```

---

## What's in this package

| Folder / file        | What it is                                                        |
|----------------------|-------------------------------------------------------------------|
| `README.md`          | This file — start here                                            |
| `docs/`              | The step-by-step guide (read these in order, 01 → 06)             |
| `bridge/`            | The Bridge service + the `ccops` CLI — the code you will run      |
| `scripts/`           | Small helper scripts (a health check)                             |

---

## How the system works (the 30-second version)

```
   ┌─────────────────────  YOUR NETWORK  ─────────────────────┐
   │                                                          │
   │   CLI  ──►  Bridge  ──►  OptScale  ──►  (private path) ──────►  Cloud billing APIs
   │   ($ ccops)   │                                          │
   │               └──►  Gauss (internal LLM)                 │
   │                                                          │
   └──────────────────────────────────────────────────────────┘
```

1. **OptScale** — open-source tool that collects all your cloud cost data and stores it.
2. **Bridge** — a small Python service (the code in this package). It pulls data from
   OptScale, turns it into a question for the AI, and formats the answer.
3. **Gauss** — your internal AI model that does the reasoning.
4. **CLI (`ccops`)** — what you actually type commands into.

The Bridge is the only new thing you build. Everything else already exists.

---

## The recommended path (for a beginner)

You do **not** have to set up everything at once. Do it in two stages:

### Stage 1 — Get the Bridge + CLI working in "mock mode" (30 minutes)

Mock mode means the Bridge uses **fake sample data** instead of talking to a real
OptScale or Gauss. This lets you see the whole thing working *today*, on your
laptop, before any infrastructure exists.

➡️ Go straight to **`docs/04-setup-bridge.md`** and follow the "Mock mode" section.

### Stage 2 — Connect it to the real OptScale and Gauss (later)

Once you're comfortable, stand up OptScale and point the Bridge at it.

➡️ `docs/01-prerequisites.md` → `02-install-optscale.md` → `03-configure-optscale.md`
→ then the "Real mode" section of `04-setup-bridge.md`.

---

## Quick start (mock mode — try it right now)

```bash
# 1. Go into the bridge folder
cd bridge

# 2. (Recommended) create a Python virtual environment
python3 -m venv venv
source venv/bin/activate          # on Windows: venv\Scripts\activate

# 3. Install the dependencies
pip install -r requirements.txt

# 4. Create your config file from the template
cp .env.example .env
# (the template already has MOCK_MODE=true — no editing needed for now)

# 5. Make the CLI runnable
chmod +x ccops

# 6. Try it!
./ccops ask "why did our bill go up last week?"
./ccops anomaly
./ccops cost --service eks
./ccops recommend --top 3
```

If you see a sensible answer printed in your terminal — it works. 🎉
From here, read `docs/` in order to connect the real services.

---

## Documentation index

| Read in this order                  | What it covers                                 |
|-------------------------------------|------------------------------------------------|
| `docs/01-prerequisites.md`          | What you need before you start                 |
| `docs/02-install-optscale.md`       | Installing OptScale                             |
| `docs/03-configure-optscale.md`     | Connecting cloud accounts + getting API access  |
| `docs/04-setup-bridge.md`           | Setting up the Bridge + CLI (mock and real)     |
| `docs/05-run-and-test.md`           | Using `ccops` day to day                        |
| `docs/06-troubleshooting.md`        | Fixes for common problems                       |

---

## A note on safety

Even though everything runs inside your network, the package is built with
good habits: secrets live in a `.env` file (never committed), the Bridge
authenticates to OptScale and Gauss, and every request can be logged.
See `docs/06-troubleshooting.md` and `bridge/README.md` for details.
