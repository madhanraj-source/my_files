# 06 — Troubleshooting

Common problems and how to fix them. Work top to bottom — the first
sections cover the most frequent issues.

> **Golden rule:** when something breaks, run `./ccops doctor` first.
> It tells you whether the problem is configuration or connectivity.

---

## Bridge / CLI issues

### `python-dotenv is not installed` or `ModuleNotFoundError`

The dependencies aren't installed, or your virtual environment isn't active.

```bash
cd cloudcostops/bridge
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

### `./ccops: Permission denied`

The CLI file isn't marked executable.

```bash
chmod +x ccops
```

Or just run it with Python directly: `python3 ccops ask "..."`

### `Configuration is incomplete`

You're in real mode (`MOCK_MODE=false`) but some values in `.env` are
empty. `ccops doctor` lists exactly which ones. Fill them in, or set
`MOCK_MODE=true` to go back to mock mode.

### `.env` changes don't seem to take effect

- Make sure you edited `.env`, **not** `.env.example`.
- Make sure the file is in the `bridge/` folder, next to `config.py`.
- Make sure there are no spaces around the `=` (use `KEY=value`, not `KEY = value`).

### The CLI output looks plain / unstyled

`rich` isn't installed. The tool still works — it just falls back to plain
text. Install it with `pip install -r requirements.txt` for the nicer
output.

---

## OptScale issues

### `OptScale : NOT REACHABLE` in `ccops doctor`

- Check `OPTSCALE_URL` in `.env` — it should be the base URL, no trailing
  path, e.g. `https://optscale.internal.mycompany.com`.
- From the Bridge machine, test the connection:
  `curl -sS https://<your-optscale-host>/restapi/v2/version`
  If that fails, it's a network/DNS/firewall issue, not a Bridge issue.
- Confirm the Bridge machine is allowed to reach the OptScale machine on
  the network.

### Real-mode commands error, but mock mode worked fine

This almost always means an **API endpoint path mismatch**. OptScale's
exact paths can differ by version.

1. Open your OptScale API docs — usually `https://<your-optscale-host>/docs`.
2. Open `bridge/optscale_client.py`.
3. Find the comments marked `# VERIFY:` — each sits above a real API call.
4. Compare the path in the code to the path in your OptScale docs and
   correct it.

This is expected; `optscale_client.py` is deliberately the *only* file you
might need to adjust for your OptScale version.

### `401 Unauthorized` from OptScale

Your `OPTSCALE_TOKEN` is wrong, expired, or wasn't copied fully. Create a
fresh token in the OptScale UI (see `03-configure-optscale.md`) and update
`.env`.

### The OptScale UI won't open after install

- Give it time — services can take several minutes to come up after the
  installer finishes.
- Check the install logs (the OptScale repo's README explains where).
- Confirm the server has enough RAM — OptScale struggles below ~16 GB.

### OptScale shows no cost data

- The first billing import can take hours. Be patient.
- Re-check the cloud credentials you entered — read-only billing access
  must be valid.
- Look in the OptScale UI's data source status for an error message.

---

## Gauss issues

### `Gauss : NOT REACHABLE` in `ccops doctor`

- Check `GAUSS_URL` in `.env`.
- From the Bridge machine: `curl -sS <your-gauss-url>` — confirm it responds.
- Confirm the Bridge machine is allowed to reach Gauss on the network.

### Gauss calls fail or return something unexpected

Every internal LLM API is shaped slightly differently. Open
`bridge/gauss_client.py` and check the comments marked `# VERIFY:`:

- the **URL path** (`/v1/chat/completions` may differ for your Gauss),
- the **request body** field names,
- where the **answer text** sits in the response JSON.

Adjust those three things to match your Gauss API documentation.

### `401` / `403` from Gauss

Your `GAUSS_API_KEY` is wrong or lacks permission. Get a valid credential
from your Gauss team and update `.env`.

---

## Security reminders (even on one internal network)

These aren't "problems" — they're things to get right before you let the
team use it:

- **Never commit `.env`** to git. Only `.env.example` belongs in version
  control. (Add `.env` to your `.gitignore`.)
- **Keep the audit log.** `ccops_audit.log` records who asked what.
- **Put `ccops` behind your normal login/SSO** when you deploy it on a
  shared server — "same network" doesn't mean "no access control".
- **Get Gauss's data-retention policy in writing.** Even an internal model
  may log prompts; you want to know for how long and who can see them.
- **Use read-only cloud credentials** for OptScale — it never needs write
  access.

---

## Still stuck?

1. Run `./ccops doctor` and read its output carefully.
2. Reproduce the problem in **mock mode** (`MOCK_MODE=true`). If it works
   in mock mode, the bug is in configuration or the external service, not
   the Bridge code.
3. Run `pytest` from the `bridge/` folder — if tests pass, the core logic
   is sound.
4. Check the relevant `# VERIFY:` comments in `optscale_client.py` /
   `gauss_client.py`.
