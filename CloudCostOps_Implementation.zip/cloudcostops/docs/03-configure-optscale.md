# 03 — Configure OptScale

OptScale is running but empty. Now you will:

1. Create an organization.
2. Connect a cloud account so cost data flows in.
3. Create an API token (so the Bridge can read the data).
4. Find your organization ID.

By the end you'll have the three values the Bridge needs:
`OPTSCALE_URL`, `OPTSCALE_TOKEN`, `OPTSCALE_ORG_ID`.

> The exact button names and menu locations can vary slightly by OptScale
> version. The **concepts** below are stable — look for the equivalent
> option in your UI. The OptScale docs have version-specific screenshots.

---

## Step 1 — Create an organization

In OptScale, an **organization** is the top-level container for all your
cost data.

1. Log in to the OptScale web UI.
2. If it didn't prompt you during signup, find the option to **create an
   organization** (often in the top-left selector or under Settings).
3. Give it a name (e.g. your team or company name).

---

## Step 2 — Connect a cloud account

This is what makes cost data appear. You'll do this once per cloud.

1. Go to the **Data Sources** (sometimes called "Cloud Accounts" or
   "Connect cloud account") section.
2. Choose your cloud — **AWS**, **Azure**, or **GCP**.
3. OptScale will ask for **read-only billing credentials**:
   - **AWS** — typically an IAM role ARN or access key with billing/Cost
     Explorer read permissions, and the name of your Cost & Usage Report
     bucket. OptScale's screen lists exactly what it needs.
   - **Azure** — a service principal (app ID, secret, tenant ID) with the
     `Cost Management Reader` role.
   - **GCP** — a service account key with `Billing Account Viewer`.
4. Submit. OptScale validates the credentials and begins importing data.

> **Get these credentials from whoever owns your cloud accounts.**
> Always request **read-only** access — OptScale never writes anything.

### Then: wait for data to import

The first import can take a while — sometimes a few hours — because
OptScale pulls your billing history. You can move on; just don't expect
the Bridge to show real numbers until the import has run at least once.

You'll know it worked when the OptScale **dashboard shows cost charts**.

---

## Step 3 — Create an API token

The Bridge logs in to OptScale using a **token**, not your password.

1. In the OptScale UI, look under your **user/profile settings** or an
   **API / Tokens** section.
2. Create a new **API token**.
3. **Copy it now** and keep it somewhere safe — you usually cannot see it
   again after closing the dialog.

This value becomes `OPTSCALE_TOKEN` in your `.env` file.

> If you cannot find a token option in the UI, OptScale also issues tokens
> via its authentication API — the OptScale docs show the exact call. Ask
> your OptScale admin if unsure.

---

## Step 4 — Find your organization ID

The Bridge needs your organization's **ID** (a long unique string), not
its display name.

- The easiest way: open your organization in the OptScale UI and look at
  the browser's address bar. The URL usually contains the organization ID
  (a string like `a1b2c3d4-....`).
- Alternatively, the OptScale API has an endpoint that lists your
  organizations and their IDs.

This value becomes `OPTSCALE_ORG_ID` in your `.env` file.

---

## Step 5 — Note your three values

Write these down — you'll paste them into the Bridge's `.env` file next:

| `.env` variable     | Where it came from                                   |
|---------------------|------------------------------------------------------|
| `OPTSCALE_URL`      | The base URL of your OptScale UI (e.g. `https://optscale.internal.mycompany.com`) |
| `OPTSCALE_TOKEN`    | The API token you created in Step 3                  |
| `OPTSCALE_ORG_ID`   | The organization ID you found in Step 4              |

---

## Checkpoint

- [ ] An organization exists in OptScale
- [ ] At least one cloud account is connected
- [ ] The OptScale dashboard shows real cost data (import has run)
- [ ] You have an API token saved
- [ ] You have your organization ID

All ticked? Continue to **`04-setup-bridge.md`**.
