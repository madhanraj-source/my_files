# 01 — Prerequisites

> **You can skip most of this for now.** If you just want to see the tool
> working today, jump to `04-setup-bridge.md` and follow the **Mock mode**
> section — it only needs Python. Come back here when you're ready to
> connect the real services.

This page lists everything you need for the **full** setup.

---

## A. For running the Bridge + CLI (needed always)

| Requirement       | How to check / get it                                  |
|-------------------|--------------------------------------------------------|
| A Linux machine   | You already have one.                                  |
| Python 3.9+       | Run `python3 --version`. If missing: `sudo apt install python3 python3-venv python3-pip` |
| pip               | Comes with Python. Check: `pip3 --version`             |
| Basic terminal    | You'll run a handful of commands — all provided.       |

That's it for mock mode.

---

## B. For OptScale (needed only for real mode)

OptScale is a real platform, so it needs real resources.

| Requirement            | Notes                                                          |
|------------------------|----------------------------------------------------------------|
| A server or VM         | Not your laptop for the real deployment — see the README. For a first test, a machine with enough RAM is fine. |
| CPU / RAM              | Plan for **8 vCPU and 16 GB RAM minimum**; 32 GB is comfortable. OptScale runs several services. |
| Disk                   | 100 GB+ free — it stores historical cost data.                 |
| A Kubernetes option    | OptScale deploys on Kubernetes. For a single machine you'll use a lightweight distribution like **k3s** or **minikube**, or OptScale's own installer. |
| Outbound internet OR a private path to the cloud billing APIs | OptScale must reach AWS / Azure / GCP billing endpoints to pull data. |
| `git`, `docker`        | `sudo apt install git docker.io`                               |

---

## C. Cloud account access (needed only for real mode)

To let OptScale read your cost data, you need **read-only** billing
credentials for each cloud you use:

- **AWS** — an IAM role or user with billing read permissions
  (the AWS-managed `Billing` read policy, plus Cost Explorer access).
- **Azure** — a service principal with the `Cost Management Reader` role.
- **GCP** — a service account with `Billing Account Viewer`.

> Ask whoever owns your cloud accounts for **read-only** billing access.
> OptScale never needs write access — it only reads cost data.

---

## D. Gauss access (needed only for real mode)

From your internal Gauss team, you need:

- The **API endpoint URL** for Gauss.
- An **API key / credential** your service can use.
- The **model name** to request.
- Their **data-retention policy** in writing (do they log prompts? for how long?).
  This matters even though Gauss is internal — see `06-troubleshooting.md`.

---

## Checklist before you start the full setup

- [ ] Python 3.9+ works (`python3 --version`)
- [ ] You have a server/VM for OptScale with enough RAM
- [ ] You have read-only billing credentials for your cloud(s)
- [ ] You have the Gauss URL, API key, and model name
- [ ] You can reach OptScale and Gauss from the machine the Bridge runs on

Once these are ticked, continue to **`02-install-optscale.md`**.
