# 04 — Set Up the Bridge + CLI

This is the part you can do **right now**, even before OptScale exists.

There are two modes:

- **Mock mode** — uses built-in sample data. No real services needed.
  Start here. Takes about 10 minutes.
- **Real mode** — connects to your actual OptScale and Gauss. Do this
  once you've completed docs `01`–`03`.

---

## Part A — Mock mode (do this first)

### Step 1 — Open a terminal in the `bridge` folder

```bash
cd cloudcostops/bridge
```

### Step 2 — Create a virtual environment

A virtual environment keeps this project's Python packages separate from
the rest of your system. Recommended, not mandatory.

```bash
python3 -m venv venv
source venv/bin/activate
# On Windows instead:  venv\Scripts\activate
```

Your prompt should now show `(venv)` at the start.

### Step 3 — Install the dependencies

```bash
pip install -r requirements.txt
```

This installs four small packages (see `requirements.txt` for what each does).

### Step 4 — Create your config file

```bash
cp .env.example .env
```

The template already has `MOCK_MODE=true`, so **you don't need to edit
anything yet**.

### Step 5 — Make the CLI runnable

```bash
chmod +x ccops
```

### Step 6 — Check your setup

```bash
./ccops doctor
```

You should see something like:

```
MODE: mock (using built-in sample data — no real services contacted)
Configuration looks OK.
Checking connectivity…
  OptScale : OK
  Gauss    : OK

You are in MOCK mode — both checks pass automatically.
```

### Step 7 — Try it

```bash
./ccops ask "why did our bill go up last week?"
./ccops anomaly
./ccops cost --service eks
./ccops recommend --top 3
```

Each command should print a clear, plain-English answer in a panel.

🎉 **If you see answers — the Bridge works.** You've built and run the
whole thing. The only difference in real mode is *where the data comes
from*.

### Step 8 (optional) — Run the tests

```bash
pytest
```

All tests should pass. They confirm the internal wiring is correct.

---

## Part B — Real mode (after OptScale + Gauss are ready)

Do this once you've finished docs `01`–`03` and have OptScale running
with data, plus your Gauss details.

### Step 1 — Edit your `.env` file

Open `cloudcostops/bridge/.env` in a text editor and change it:

```ini
# switch off mock mode
MOCK_MODE=false

# from docs/03-configure-optscale.md
OPTSCALE_URL=https://optscale.internal.mycompany.com
OPTSCALE_TOKEN=paste-your-optscale-token-here
OPTSCALE_ORG_ID=paste-your-org-id-here

# from your Gauss team
GAUSS_URL=https://gauss.internal.mycompany.com
GAUSS_API_KEY=paste-your-gauss-key-here
GAUSS_MODEL=gauss-default
```

Save the file.

### Step 2 — Check connectivity

```bash
./ccops doctor
```

This now actually contacts OptScale and Gauss. You want to see:

```
MODE: real (OptScale: https://... | Gauss: https://...)
Configuration looks OK.
Checking connectivity…
  OptScale : OK
  Gauss    : OK
```

If either says `NOT REACHABLE`, see `06-troubleshooting.md`.

### Step 3 — Try a real query

```bash
./ccops ask "why did our bill go up last week?"
```

This time the answer is reasoned from your **real** cost data.

### Step 4 — If an OptScale call fails

OptScale's exact API endpoint paths can differ by version. If real-mode
commands error out while mock mode worked fine, the most likely cause is
an endpoint path mismatch.

Open `bridge/optscale_client.py` and look for the comments marked
`# VERIFY:`. Compare those paths against your OptScale install's API
docs (usually at `https://<your-optscale-host>/docs`) and adjust. This is
the one file you may need to tweak — it's deliberately the only place
that knows OptScale's API.

Same idea for Gauss: if Gauss calls fail, check the `# VERIFY:` comments
in `bridge/gauss_client.py` against your Gauss API documentation.

---

## You're done

- Mock mode proves the Bridge logic works.
- Real mode connects it to your live data.

Next: **`05-run-and-test.md`** for day-to-day usage, or
**`06-troubleshooting.md`** if something isn't working.
