# 05 — Using `ccops` Day to Day

Once the Bridge is set up, here's how engineers use it.

> Run these from inside `cloudcostops/bridge/` with your virtual
> environment active (`source venv/bin/activate`).

---

## The commands

### `ccops ask "..."` — free-form questions

The most flexible command. Ask anything about your costs.

```bash
./ccops ask "why did our bill go up last week?"
./ccops ask "what is driving our EKS spend?"
./ccops ask "are there any savings we are missing?"
```

### `ccops anomaly` — investigate spikes

Pulls the anomalies OptScale detected and explains the root cause.

```bash
./ccops anomaly
./ccops anomaly --days 14      # look back 14 days instead of the default
```

### `ccops cost` — cost breakdown

Explains where the money is going, by service.

```bash
./ccops cost                   # all services
./ccops cost --service eks     # focus on one service
./ccops cost --service rds --days 60
```

### `ccops recommend` — savings triage

Shows the highest-impact savings actions, ranked.

```bash
./ccops recommend              # top 3 by default
./ccops recommend --top 5
```

### `ccops doctor` — check the setup

Run this any time something seems wrong. It checks your configuration and
whether OptScale and Gauss are reachable.

```bash
./ccops doctor
```

### `ccops --help`

Lists every command. Add `--help` after any command for its options:

```bash
./ccops --help
./ccops cost --help
```

---

## Handy tricks

### Pipe the output into other tools

Because `ccops` is just a CLI, it composes with everything else:

```bash
# email yourself a monthly summary
./ccops ask "give me a one-paragraph monthly cost summary" | mail -s "FinOps update" you@company.com

# save an answer to a file
./ccops anomaly > anomaly-report.txt
```

### Make `ccops` available everywhere

So you don't have to type `./ccops` from one folder, you can add it to
your PATH. One simple way:

```bash
# from inside the bridge/ folder
sudo ln -s "$(pwd)/ccops" /usr/local/bin/ccops
```

Now you can just type `ccops ask "..."` from anywhere. (You still need the
virtual environment active, or install the requirements system-wide.)

---

## What good output looks like

```
$ ./ccops anomaly

Investigating cost anomalies…

╭───────────────────────── CloudCostOps ──────────────────────────╮
│ The main cost increase is in Amazon EKS (us-east-1), up about    │
│ 23% week-over-week. The driver is node-group-prod-3 — 14 new     │
│ pods were created roughly 6 days ago and the cluster scaled up   │
│ but never scaled back down...                                    │
╰──────────────────────────────────────────────────────────────────╯
Question: Why did our cloud costs change recently? What is the root cause?
```

---

## The audit log

Every question is appended to `ccops_audit.log` in the `bridge/` folder,
with a timestamp. This is useful for knowing who asked what. Keep it; in a
shared deployment, ship it to your normal log system.

---

## Tips for good answers

- The quality of "why" answers depends on your **cloud resource tagging**.
  Well-tagged resources (team, service, environment) let the AI give sharp,
  specific root causes.
- Use `--days` to widen or narrow the time window when a question is about
  a longer trend.
- If an answer seems off, run the same question in mock mode to confirm
  the *Bridge* is fine and the issue is in the data, not the code.

Next: **`06-troubleshooting.md`** for fixes to common problems.
