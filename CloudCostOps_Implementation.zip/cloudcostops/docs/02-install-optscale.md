# 02 — Install OptScale

OptScale is open-source software you host yourself. This page explains
**what** you are doing and **why**, step by step. For the exact commands,
you will follow OptScale's official installer — those commands can change
between versions, so the official repo is always the source of truth.

> **Official source:** the OptScale project on GitHub —
> search for **"hystax optscale"**. Use the README and `docs/` there for
> the precise, version-correct commands.

> **Reminder:** you do **not** need OptScale to start. The Bridge runs in
> mock mode without it. Set this up when you're ready for real data.

---

## What you're about to do (the big picture)

1. Get a server/VM ready.
2. Get the OptScale installer.
3. Run the installer — it sets up everything (the database, the services, the web UI).
4. Open the OptScale web UI in a browser.
5. Create your login.

Then, in the **next** doc (`03`), you connect your cloud accounts and get API access.

---

## Step 1 — Prepare the server

On the machine that will host OptScale:

```bash
# update the system
sudo apt update && sudo apt upgrade -y

# install the basics
sudo apt install -y git curl docker.io
```

Confirm it has enough resources (see `01-prerequisites.md` — aim for
8 vCPU / 16 GB RAM minimum).

---

## Step 2 — Get the OptScale installer

```bash
# clone the official OptScale repository
git clone https://github.com/hystax/optscale.git
cd optscale
```

> If that URL has moved, search GitHub for **"hystax optscale"** —
> it is the official open-source repository.

Open the repository's `README.md`. It describes the supported install
methods. There are usually two:

- **A full installer** (Ansible-based) that builds a Kubernetes cluster
  and deploys all of OptScale. Best for a real, lasting deployment.
- **A lighter / evaluation install** for trying it on a single machine.

For your **first** real deployment, the full installer on a dedicated VM
is the right choice.

---

## Step 3 — Run the installer

Follow the steps in the OptScale repo's README. At a high level you will:

1. Provide some configuration (hostname, admin email, etc.) — the repo
   shows exactly which file to edit.
2. Run the install command the README gives you.
3. **Wait.** The installer pulls images and starts many services. This
   can take 20–40 minutes. That is normal.

While it runs, it is setting up:

- the databases that store cost data (MongoDB + ClickHouse),
- OptScale's microservices,
- the REST API (this is what the Bridge will call later),
- the web dashboard UI.

---

## Step 4 — Open the web UI

When the installer finishes, it tells you the URL for the OptScale web
interface — usually `https://<your-server-hostname>/`.

Open that URL in a browser. You should see the OptScale login page.

> If the page does not load, see `06-troubleshooting.md` →
> "OptScale UI won't open".

---

## Step 5 — Create your account

1. On the login page, choose to create an account / sign up.
2. Create your admin user (email + password).
3. Log in.

You now have OptScale running. It has **no cost data yet** — that comes
in the next step when you connect a cloud account.

---

## Checkpoint

- [ ] OptScale installer finished without errors
- [ ] The OptScale web UI loads in a browser
- [ ] You can log in with your new account

If all three are ticked, continue to **`03-configure-optscale.md`**.
