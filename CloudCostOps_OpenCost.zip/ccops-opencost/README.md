# CloudCostOps — OpenCost + Gauss Edition

Ask your Kubernetes cloud costs questions in plain English from the terminal.

```
$ ccops ask "why is the payments team spending so much this week?"

╭──────────────── CloudCostOps ─────────────────╮
│ The payments namespace costs $342/week, up 38% │
│ from last week. The driver is checkout-api —   │
│ it scaled from 3 to 9 replicas on Tuesday and  │
│ never scaled back down. CPU efficiency is only │
│ 18% — the pods are heavily over-provisioned.   │
│                                                │
│ Recommendation: check the HPA settings for    │
│ checkout-api and reduce resource requests.     │
╰────────────────────────────────────────────────╯
```

---

## What this is

A small Python service (the **Bridge**) that sits between your terminal
and two existing systems:

- **OpenCost** — an open-source tool already running in your Kubernetes
  cluster that knows the cost of every pod, namespace, and deployment.
- **Gauss** — your internal LLM that explains what the numbers mean in
  plain English.

You type a question. The Bridge fetches the relevant cost data from
OpenCost, builds a clear prompt, sends it to Gauss, and prints the answer.

```
  You                OpenCost            Gauss
   │                   (K8s cluster)      (internal LLM)
   │  $ ccops ask      │                  │
   └──► Bridge ────────┤                  │
              pulls cost data             │
              builds prompt ─────────────►│
                         ◄─── explanation─┤
   ◄── prints answer ───┘
```

**Everything runs inside your network. No data leaves.**

---

## What you can do with it

| Command | What it does |
|---|---|
| `ccops ask "..."` | Ask anything in plain English |
| `ccops cost` | Cost breakdown by namespace |
| `ccops cost --by deployment` | Cost breakdown by deployment |
| `ccops savings` | Which workloads are over-provisioned and by how much |
| `ccops trend` | This week vs last week — what changed and why |
| `ccops doctor` | Check your setup is correct |

---

## What you need

### To run in mock mode (no real services needed — start here)
- Python 3.9 or newer
- That is all. Takes 10 minutes.

### To run in real mode (connects to actual data)
- A running Kubernetes cluster with OpenCost installed (Step 1 below)
- Access to Gauss — the URL, API key, and model name from your Gauss team
- The Bridge server must be able to reach both OpenCost and Gauss on the network

---

## Quick start — mock mode (do this first)

Mock mode uses built-in sample data. No Kubernetes, no Gauss needed.
Do this to see the tool working before setting up any real services.

```bash
# 1. Go into the bridge folder
cd bridge

# 2. Create a Python virtual environment (keeps dependencies isolated)
python3 -m venv venv
source venv/bin/activate
# Windows: venv\Scripts\activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Create your config file
cp .env.example .env
# The template already has MOCK_MODE=true — no changes needed yet

# 5. Make the CLI runnable
chmod +x ccops

# 6. Check your setup
./ccops doctor

# 7. Try it
./ccops ask "which team is spending the most?"
./ccops cost
./ccops savings
./ccops trend
```

You should see clear, plain-English answers in your terminal.
**If you do — the Bridge works. The only difference in real mode is where the data comes from.**

---

## Real mode — Step 1: Install OpenCost in your Kubernetes cluster

OpenCost runs inside your existing Kubernetes cluster.
Run these commands from a machine that has `kubectl` access to your cluster.

```bash
# Create the opencost namespace
kubectl create namespace opencost

# Install OpenCost (official one-command install)
kubectl apply --server-side \
  -f https://raw.githubusercontent.com/opencost/opencost/develop/kubernetes/opencost.yaml

# Check it is running (wait until STATUS shows Running, takes 1-2 minutes)
kubectl get pods -n opencost
```

Expected output when ready:
```
NAME                        READY   STATUS    RESTARTS   AGE
opencost-xxxx-xxxx          1/1     Running   0          2m
prometheus-server-xxxx      1/1     Running   0          2m
```

OpenCost is now collecting cost data from your cluster. It keeps the last
14 days of data automatically.

**Verify it works** — run this from any machine with kubectl:
```bash
kubectl port-forward -n opencost service/opencost 9090:9090
# Then open http://localhost:9090 in a browser — you should see the OpenCost UI
# Press Ctrl+C when done
```

---

## Real mode — Step 2: Expose OpenCost to the Bridge server

The Bridge runs on a server (not inside the cluster), so it needs a stable
network address to reach OpenCost. The cleanest approach for a corporate
network is a **NodePort service**.

```bash
# Create a NodePort so OpenCost is reachable from outside the cluster
kubectl expose deployment opencost \
  --namespace opencost \
  --type NodePort \
  --name opencost-external \
  --port 9090

# Find the assigned port (look for 9090:XXXXX/TCP in the output)
kubectl get service opencost-external -n opencost
```

Example output:
```
NAME                TYPE       CLUSTER-IP    PORT(S)          AGE
opencost-external   NodePort   10.96.0.100   9090:32145/TCP   10s
```

In this example, OpenCost is reachable at `http://<any-k8s-node-ip>:32145`.

Get a node IP:
```bash
kubectl get nodes -o wide
# Look at the INTERNAL-IP column
```

Your OpenCost URL would be: `http://<node-ip>:<nodeport>`
e.g. `http://10.0.1.50:32145`

Test it from the Bridge server:
```bash
curl "http://10.0.1.50:32145/model/allocation?window=1d&aggregate=namespace"
# You should get JSON back with namespace cost data
```

---

## Real mode — Step 3: Configure the Bridge

Edit `bridge/.env` (you already created it in the Quick Start):

```ini
# Switch off mock mode
MOCK_MODE=false

# OpenCost — the URL you found in Step 2
OPENCOST_URL=http://10.0.1.50:32145

# Gauss — get these from your Gauss team
GAUSS_URL=https://gauss.internal.yourcompany.com
GAUSS_API_KEY=your-api-key-here
GAUSS_MODEL=gauss-default
```

Save the file, then:

```bash
./ccops doctor
```

Expected output:
```
MODE: real  (OpenCost: http://10.0.1.50:32145 | Gauss: https://gauss...)
Configuration looks OK.
Checking connectivity...
  OpenCost : OK  (found 8 namespaces)
  Gauss    : OK
```

---

## Real mode — Step 4: Try it with real data

```bash
./ccops cost
./ccops savings
./ccops ask "which team should reduce their resource requests first?"
```

---

## All commands

### `ccops ask "your question"`
Ask anything in plain English. The Bridge pulls a broad context
(all namespaces, efficiency data, week-over-week trends) and lets Gauss
answer whatever you asked.

```bash
./ccops ask "why did our costs go up this week?"
./ccops ask "which namespace has the worst resource efficiency?"
./ccops ask "how much would we save if we right-sized all dev workloads?"
./ccops ask "what is the most expensive deployment we have?"
```

### `ccops cost`
Cost breakdown. By default shows all namespaces. Use `--by` to change
the grouping, `--window` to change the time range.

```bash
./ccops cost                          # all namespaces, last 7 days
./ccops cost --by deployment          # by deployment
./ccops cost --window 30d             # last 30 days
./ccops cost --namespace payments     # one namespace only
```

### `ccops savings`
Shows which workloads are over-provisioned — where the requested
CPU/memory is much higher than what is actually used. These are your
rightsizing opportunities.

```bash
./ccops savings                # top 5 savings opportunities
./ccops savings --top 10
```

### `ccops trend`
Compares the current period against the previous period of the same
length. Shows what changed, by how much, and which namespaces drove it.

```bash
./ccops trend                  # this week vs last week
./ccops trend --window 30d     # this month vs last month
```

### `ccops doctor`
Checks configuration and connectivity. Run this first if anything
seems wrong.

```bash
./ccops doctor
```

---

## Project structure

```
cloudcostops-opencost/
├── README.md                     ← you are here
├── .gitignore
├── docs/
│   ├── 01-install-opencost.md    ← detailed OpenCost install guide
│   ├── 02-configure-gauss.md     ← Gauss configuration details
│   └── 03-troubleshooting.md     ← fixes for common problems
└── bridge/
    ├── ccops                     ← the CLI you run
    ├── bridge.py                 ← orchestrator (ties everything together)
    ├── opencost_client.py        ← ALL OpenCost API calls live here
    ├── gauss_client.py           ← ALL Gauss API calls live here
    ├── prompt_builder.py         ← builds the AI prompt from cost data
    ├── config.py                 ← loads settings from .env
    ├── .env.example              ← config template (copy to .env)
    ├── requirements.txt          ← Python dependencies
    └── tests/
        └── test_bridge.py        ← run with: pytest
```

**One rule to remember:** `opencost_client.py` is the only file that
talks to OpenCost. `gauss_client.py` is the only file that talks to
Gauss. If something breaks with real services, those are the two files
to look at — everything else stays the same.

---

## Configuration reference

All settings go in `bridge/.env`.

| Setting | Default | What it does |
|---|---|---|
| `MOCK_MODE` | `true` | Use sample data instead of real services |
| `OPENCOST_URL` | _(empty)_ | Base URL of your OpenCost instance |
| `GAUSS_URL` | _(empty)_ | Base URL of your Gauss API |
| `GAUSS_API_KEY` | _(empty)_ | Gauss API credential |
| `GAUSS_MODEL` | `gauss-default` | Gauss model name |
| `DEFAULT_WINDOW` | `7d` | Default time window for queries |
| `REQUEST_TIMEOUT` | `30` | Network timeout in seconds |
| `AUDIT_LOG` | `ccops_audit.log` | File where questions are recorded |

---

## How to customize

| You want to... | Edit this file |
|---|---|
| Change the AI's tone or instructions | `prompt_builder.py` — edit `SYSTEM_PROMPT` |
| Add a new `ccops` command | `ccops` (add subparser) + `bridge.py` (add handler) |
| Fix an OpenCost endpoint that does not work | `opencost_client.py` — check `# VERIFY:` comments |
| Adjust the Gauss request format | `gauss_client.py` — check `# VERIFY:` comments |
| Add a new setting | `config.py` + `.env.example` |

---

## Running the tests

```bash
cd bridge
pytest
```

All tests run in mock mode — no real services needed.

---

## Security notes

- Secrets (`GAUSS_API_KEY` etc.) live only in `.env` — never commit it.
  Only `.env.example` belongs in version control.
- OpenCost only needs **read access** to your cluster — it never modifies anything.
- Every question is written to `ccops_audit.log` with a timestamp.
- In production, put the Bridge behind your normal SSO so only authorised
  engineers can use it.
