# 01 — Install OpenCost

OpenCost runs inside your existing Kubernetes cluster.
It is one of the simplest Kubernetes installs — one command.

## What OpenCost does

Once installed, OpenCost automatically reads your cluster's billing data
(AWS, Azure, or GCP) and tracks the cost of every pod, namespace,
deployment, and node. It keeps up to 14 days of history by default.

## Prerequisites

- A running Kubernetes cluster (EKS, AKS, GKE, or self-managed)
- `kubectl` access from your terminal
- Your cloud account must have Cost reporting APIs enabled:
  - **AWS** — enable Cost Explorer in the Billing console (no extra credentials needed; OpenCost reads from the AWS Pricing API)
  - **Azure** — Rate Card API access
  - **GCP** — BigQuery billing export (see https://www.opencost.io/docs/configuration/gcp)

## Step 1 — Create the namespace

```bash
kubectl create namespace opencost
```

## Step 2 — Install OpenCost

```bash
kubectl apply --server-side \
  -f https://raw.githubusercontent.com/opencost/opencost/develop/kubernetes/opencost.yaml
```

This installs OpenCost and a bundled Prometheus instance.

## Step 3 — Verify it is running

```bash
kubectl get pods -n opencost --watch
```

Wait until all pods show `Running`. Usually takes 1–2 minutes.

```
NAME                        READY   STATUS    RESTARTS   AGE
opencost-xxxx               1/1     Running   0          90s
prometheus-server-xxxx      1/1     Running   0          90s
```

## Step 4 — Confirm data is flowing

Port-forward to the OpenCost UI:

```bash
kubectl port-forward -n opencost service/opencost 9090:9090
```

Open http://localhost:9090 in a browser. You should see cost charts
within a few minutes.

Also test the API:
```bash
curl "http://localhost:9090/model/allocation?window=1d&aggregate=namespace&accumulate=true"
```
You should get JSON back with namespace cost data.

Press Ctrl+C to stop the port-forward.

## Step 5 — Expose OpenCost for the Bridge server

The Bridge runs on a separate server, not inside the cluster. You need
a stable address for it to call. The easiest approach:

```bash
kubectl expose deployment opencost \
  --namespace opencost \
  --type NodePort \
  --name opencost-external \
  --port 9090

# Get the assigned port
kubectl get service opencost-external -n opencost
# Look for   9090:XXXXX/TCP   — the XXXXX is your NodePort

# Get a node IP
kubectl get nodes -o wide
# Look at the INTERNAL-IP column
```

Test from your Bridge server:
```bash
curl "http://<node-ip>:<nodeport>/model/allocation?window=1d&aggregate=namespace&accumulate=true"
```

Your `OPENCOST_URL` for `.env` is `http://<node-ip>:<nodeport>`.

## Official documentation

For cloud-specific configuration (custom pricing, spot instances, etc.):
https://www.opencost.io/docs
