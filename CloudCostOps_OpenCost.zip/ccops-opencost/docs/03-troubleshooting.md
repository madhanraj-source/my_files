# 03 — Troubleshooting

Run `./ccops doctor` first — it tells you specifically what is wrong.

---

## Bridge / CLI issues

**`ModuleNotFoundError` or `python-dotenv is not installed`**
Dependencies are not installed, or your virtual environment is not active.
```bash
cd bridge
source venv/bin/activate
pip install -r requirements.txt
```

**`./ccops: Permission denied`**
```bash
chmod +x ccops
# Or run directly: python3 ccops ask "..."
```

**`.env` changes do not take effect**
You may have edited `.env.example` instead of `.env`.
Check: `ls -la bridge/` — `.env` and `.env.example` are different files.

---

## OpenCost issues

**`OpenCost : NOT REACHABLE`**
- Confirm the pod is running: `kubectl get pods -n opencost`
- Test the URL directly from the Bridge server:
  ```bash
  curl "http://<your-opencost-url>/model/allocation?window=1d&aggregate=namespace&accumulate=true"
  ```
- Check `OPENCOST_URL` in `.env` — no trailing slash, no path suffix.
  Correct: `http://10.0.1.50:32145`
  Wrong:   `http://10.0.1.50:32145/model`

**OpenCost returns empty data**
- OpenCost needs a few minutes after install to collect the first data.
- Wait 5 minutes and try again.
- Check AWS/Azure/GCP billing API access — see `docs/01-install-opencost.md`.

**`Connection refused` on the NodePort**
- Confirm the NodePort service exists: `kubectl get service -n opencost`
- Confirm the node IP is reachable from your Bridge server.
- Check any firewall rules between the Bridge server and the K8s nodes.

---

## Gauss issues

**`Gauss : NOT REACHABLE`**
- Check `GAUSS_URL` in `.env`.
- Test from the Bridge server: `curl https://gauss.internal.yourcompany.com`

**Gauss returns unexpected JSON / answer not found**
Real-mode Gauss calls fail but mock mode works? This is almost always
a mismatch in the API shape. Open `bridge/gauss_client.py`, find the
three `# VERIFY:` comments, and compare them to your Gauss API docs.

**`401 Unauthorized`**
Your `GAUSS_API_KEY` is wrong or expired. Get a new one from your Gauss team.

---

## "Works in mock, fails in real mode"

This is the most useful debugging pattern:
1. Set `MOCK_MODE=true` — if it works, the Bridge logic is fine.
2. Set `MOCK_MODE=false` — if it fails, the issue is connectivity or API shape.
3. Run `./ccops doctor` — it tells you which service is unreachable.
4. Check the `# VERIFY:` comments in `opencost_client.py` and `gauss_client.py`.
