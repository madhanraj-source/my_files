# 02 — Configure Gauss

## What you need from your Gauss team

Ask your internal Gauss team for these four things:

| What | Where it goes in .env |
|---|---|
| API endpoint URL | `GAUSS_URL` |
| API key / credential | `GAUSS_API_KEY` |
| Model name to use | `GAUSS_MODEL` |
| Request/response format docs | Used to verify `gauss_client.py` |

## Verifying the API shape

Open `bridge/gauss_client.py` and look for the three `# VERIFY:` comments.
Compare each one against your Gauss API docs and adjust:

1. **VERIFY 1** — the URL path (e.g. `/v1/chat/completions`)
2. **VERIFY 2** — the request body format (messages array vs single prompt string)
3. **VERIFY 3** — where the answer sits in the response JSON

A quick manual test before changing anything:

```bash
curl -X POST https://gauss.internal.yourcompany.com/v1/chat/completions \
  -H "Authorization: Bearer YOUR_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model":"gauss-default","messages":[{"role":"user","content":"say hello"}]}'
```

If you get a response — note the exact field path to the answer text.
That is what VERIFY 3 should return.

## Data retention

Ask your Gauss team: **do they log or store the prompts sent to Gauss?**
Even though Gauss is internal, your prompts will contain Kubernetes cost
data (namespace names, spend amounts). Understand the retention policy
before deploying to production.
