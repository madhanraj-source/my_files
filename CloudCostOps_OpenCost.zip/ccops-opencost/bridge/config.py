"""
config.py
---------
Loads all settings from the .env file into a Config class.

You never edit this file. You edit .env.
Copy .env.example to .env to get started.
"""

import os
import sys

try:
    from dotenv import load_dotenv
except ImportError:
    print("ERROR: python-dotenv is not installed. Run: pip install -r requirements.txt")
    sys.exit(1)

_here = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(_here, ".env"))


def _bool(name: str, default: str = "false") -> bool:
    return os.getenv(name, default).strip().lower() in ("true", "1", "yes")


class Config:
    # ── Mode ──────────────────────────────────────────────────────────
    # true  → use built-in sample data. No real services needed.
    # false → connect to real OpenCost and Gauss.
    MOCK_MODE = _bool("MOCK_MODE", "true")

    # ── OpenCost ──────────────────────────────────────────────────────
    # The base URL of your OpenCost instance.
    # Example: http://10.0.1.50:32145
    OPENCOST_URL = os.getenv("OPENCOST_URL", "").rstrip("/")

    # ── Gauss ─────────────────────────────────────────────────────────
    GAUSS_URL     = os.getenv("GAUSS_URL", "").rstrip("/")
    GAUSS_API_KEY = os.getenv("GAUSS_API_KEY", "")
    GAUSS_MODEL   = os.getenv("GAUSS_MODEL", "gauss-default")

    # ── Behaviour ─────────────────────────────────────────────────────
    DEFAULT_WINDOW  = os.getenv("DEFAULT_WINDOW", "7d")
    REQUEST_TIMEOUT = int(os.getenv("REQUEST_TIMEOUT", "30"))
    AUDIT_LOG       = os.getenv("AUDIT_LOG", "ccops_audit.log")

    # ── Validation ────────────────────────────────────────────────────
    @classmethod
    def validate(cls) -> list:
        """
        Returns a list of problems (strings). Empty list = all good.
        In mock mode nothing is required.
        """
        if cls.MOCK_MODE:
            return []
        problems = []
        if not cls.OPENCOST_URL:
            problems.append("OPENCOST_URL is empty — set it in .env")
        if not cls.GAUSS_URL:
            problems.append("GAUSS_URL is empty — set it in .env")
        if not cls.GAUSS_API_KEY:
            problems.append("GAUSS_API_KEY is empty — set it in .env")
        return problems

    @classmethod
    def describe(cls) -> str:
        if cls.MOCK_MODE:
            return "MODE: mock  (using built-in sample data — no real services contacted)"
        return (
            f"MODE: real  "
            f"(OpenCost: {cls.OPENCOST_URL} | Gauss: {cls.GAUSS_URL})"
        )
