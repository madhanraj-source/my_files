"""
gauss_client.py
---------------
The ONLY file that talks to Gauss (your internal LLM).

REAL MODE — important notes
----------------------------
Every internal LLM deployment has a slightly different API shape.
Before switching MOCK_MODE=false, confirm these three things by
reading your Gauss API documentation:

  VERIFY 1: the URL path  (below uses /v1/chat/completions — adjust if needed)
  VERIFY 2: the request body field names  (below uses the common "messages" format)
  VERIFY 3: where the answer text sits in the response  (below uses choices[0].message.content)

All three spots are marked with # VERIFY: in the code.
"""

import requests
from config import Config


class GaussClient:

    def __init__(self):
        self.url     = Config.GAUSS_URL
        self.api_key = Config.GAUSS_API_KEY
        self.model   = Config.GAUSS_MODEL
        self.mock    = Config.MOCK_MODE
        self.timeout = Config.REQUEST_TIMEOUT

    def ask(self, prompt: dict) -> str:
        """
        Send a prompt to Gauss and return the answer as a plain string.

        prompt is a dict with three keys:
            { "system": "...", "context": "...", "question": "..." }
        It is built by prompt_builder.py — you do not construct it here.
        """
        if self.mock:
            return self._mock_answer(prompt)

        # VERIFY 1: confirm the URL path for your Gauss deployment
        url = f"{self.url}/v1/chat/completions"

        headers = {
            "Content-Type":  "application/json",
            "Authorization": f"Bearer {self.api_key}",
        }

        # VERIFY 2: confirm the request body shape your Gauss API expects.
        # This uses the standard "messages" format.
        # Some models expect a single "prompt" string instead — adjust if needed.
        body = {
            "model": self.model,
            "messages": [
                {
                    "role":    "system",
                    "content": prompt["system"],
                },
                {
                    "role":    "user",
                    "content": (
                        f"COST DATA:\n{prompt['context']}"
                        f"\n\nQUESTION: {prompt['question']}"
                    ),
                },
            ],
        }

        resp = requests.post(url, headers=headers,
                             json=body, timeout=self.timeout)
        resp.raise_for_status()
        data = resp.json()

        # VERIFY 3: confirm where the answer text sits in the response.
        try:
            return data["choices"][0]["message"]["content"].strip()
        except (KeyError, IndexError):
            # If parsing fails, return the raw response so you can see what
            # Gauss actually sent back and adjust the code above.
            return (
                f"[Could not parse Gauss response — check # VERIFY 3 in gauss_client.py]\n"
                f"Raw response: {data}"
            )

    def healthcheck(self) -> bool:
        if self.mock:
            return True
        try:
            requests.get(self.url, timeout=self.timeout)
            return True
        except Exception:
            return False

    # ── Mock answer ───────────────────────────────────────────────────
    # Produces a realistic plain-English answer based on whatever context
    # was passed in. Useful for development and testing.

    def _mock_answer(self, prompt: dict) -> str:
        ctx = prompt.get("context", "").lower()
        q   = prompt.get("question", "").lower()

        # Savings / rightsizing question
        if "saving" in ctx or "saving" in q or "rightsi" in q or "over-provision" in q:
            return (
                "The biggest savings opportunity is checkout-api in the payments "
                "namespace — it is running 9 replicas but utilising only 18% of its "
                "requested CPU. Based on actual usage, 2-3 replicas would be sufficient, "
                "saving an estimated $113/week.\n\n"
                "The dev-api deployment is also a quick win: it runs continuously "
                "including nights and weekends, but is idle outside office hours. "
                "Scheduling it to stop overnight would save ~$60/week at no risk.\n\n"
                "Together these two changes represent ~$173/week (~$750/month) in "
                "recoverable spend with low implementation risk."
            )

        # Trend / week-over-week question
        if "trend" in ctx or "trend" in q or "went up" in q or "spike" in q \
                or "change" in q or "increas" in q:
            return (
                "Overall spend rose 22.6% week-over-week, from $987 to $1,210.\n\n"
                "The main driver is the payments namespace, up 55% ($221 → $342). "
                "Within payments, checkout-api scaled from 3 to 9 replicas — "
                "likely a response to a load event — and has not scaled back down.\n\n"
                "The dev namespace is also up 29%, which is unusual for a "
                "non-production environment. This is worth investigating — dev "
                "workloads should not be growing week-over-week outside of a "
                "deployment.\n\n"
                "The auth and monitoring namespaces are stable."
            )

        # Cost breakdown question
        if "cost" in ctx or "cost" in q or "spend" in q or "expensive" in q \
                or "breakdown" in q:
            return (
                "The three most expensive namespaces this week are:\n\n"
                "  1. data-platform — $518 (43% of total). Efficiency is 71%, "
                "which is reasonable for ML workloads.\n"
                "  2. payments — $342 (28% of total). Efficiency is only 42% — "
                "below the healthy threshold of 60%.\n"
                "  3. dev — $155 (13% of total). Efficiency is critically low at "
                "19%, which means most of what is provisioned is sitting idle.\n\n"
                "The dev namespace is the clearest problem: you are paying for "
                "resources that are almost entirely unused. Rightsizing or "
                "scheduling dev workloads would have an immediate impact."
            )

        # Generic fallback
        return (
            "Based on the Kubernetes cost data provided, total spend this week "
            "is $1,210 across 6 namespaces. The payments namespace is the "
            "highest-priority concern — cost is up 55% week-over-week and "
            "resource efficiency is only 42%.\n\n"
            "Run `ccops savings` to see the specific workloads to rightsize, "
            "or `ccops trend` for the full week-over-week breakdown."
        )
