"""
test_bridge.py  —  run with: pytest
All tests run in mock mode. No real services needed.
"""

import os, sys
os.environ["MOCK_MODE"] = "true"
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from bridge          import Bridge
from opencost_client import OpenCostClient
from prompt_builder  import build_prompt


def test_opencost_allocation():
    c = OpenCostClient()
    r = c.get_allocation()
    assert r["totalCost"] > 0
    assert len(r["items"]) > 0
    assert "efficiency" in r["items"][0]


def test_opencost_savings():
    c = OpenCostClient()
    r = c.get_savings()
    assert "opportunities" in r
    assert len(r["opportunities"]) > 0
    assert "estimatedWeeklySaving" in r["opportunities"][0]


def test_opencost_trend():
    c = OpenCostClient()
    r = c.get_trend()
    assert "currentTotal"  in r
    assert "previousTotal" in r
    assert "byNamespace"   in r


def test_prompt_builder():
    p = build_prompt("why did costs rise?", {"test": 123})
    assert "system"   in p and p["system"]
    assert "context"  in p and "123" in p["context"]
    assert p["question"] == "why did costs rise?"


def test_bridge_cost():
    b = Bridge()
    r = b.handle_cost()
    assert r.answer
    assert r.data["totalCost"] > 0


def test_bridge_savings():
    b = Bridge()
    r = b.handle_savings(top=3)
    assert r.answer
    assert len(r.data["opportunities"]) <= 3


def test_bridge_trend():
    b = Bridge()
    r = b.handle_trend()
    assert r.answer
    assert r.data["changePct"] != 0


def test_bridge_ask():
    b = Bridge()
    r = b.handle_ask("which namespace is most expensive?")
    assert r.answer
    assert len(r.answer) > 20


def test_bridge_health():
    b = Bridge()
    h = b.health()
    assert h["mode"]        == "mock"
    assert h["opencost_ok"] is True
    assert h["gauss_ok"]    is True
