"""
prompt_builder.py
-----------------
Turns OpenCost data into a well-structured prompt for Gauss.

Edit SYSTEM_PROMPT to change the AI's tone and behaviour.
Everything else in this file is plumbing — you rarely need to touch it.
"""

import json

# ── System prompt ──────────────────────────────────────────────────────
# This is the AI's "job description". It affects every answer the tool gives.
# Adjust the tone, focus, or output format here.

SYSTEM_PROMPT = (
    "You are a senior FinOps engineer. You analyse Kubernetes cloud cost data "
    "and explain it in plain English for engineering teams. "
    "Be specific: name the namespace or workload, state the cost and the trend, "
    "and give one concrete recommendation. "
    "Keep your answer under 150 words unless the question requires more detail. "
    "Do not invent numbers that are not in the data you are given."
)


def build_prompt(question: str, data: dict) -> dict:
    """
    Build the three-part prompt that GaussClient.ask() expects.

    Returns:
        {
            "system":   the AI's instructions,
            "context":  the cost data as readable JSON,
            "question": the user's question
        }
    """
    return {
        "system":   SYSTEM_PROMPT,
        "context":  json.dumps(data, indent=2),
        "question": question.strip(),
    }
