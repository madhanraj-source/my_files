"""
opencost_client.py
------------------
The ONLY file that talks to OpenCost.

If OpenCost changes its API, or if you need to fix an endpoint,
this is the only file to touch. Everything else in the Bridge
does not know about OpenCost.

REAL MODE — important notes
----------------------------
OpenCost exposes a REST API (default port 9090). The key endpoint is:

    GET /model/allocation
        ?window=7d          ← time range
        &aggregate=namespace ← grouping (namespace / deployment / pod / label:team)
        &accumulate=true    ← collapse the window into one total (not day-by-day)

The response looks like:
    {
      "code": 200,
      "data": [
        {
          "some-namespace": {
            "name": "some-namespace",
            "cpuCost": 12.5,
            "ramCost": 4.2,
            "pvCost": 0.8,
            "networkCost": 0.1,
            "totalCost": 17.6,
            "cpuEfficiency": 0.38,  ← 0-1, higher is better (1 = using all it requested)
            "ramEfficiency": 0.55,
            "efficiency": 0.46
          }
        }
      ]
    }

# VERIFY: check these paths against your installed OpenCost version.
# API docs: https://www.opencost.io/docs/integrations/api
"""

import requests
from datetime import date, timedelta
from config import Config


class OpenCostClient:

    def __init__(self):
        self.base_url = Config.OPENCOST_URL
        self.mock     = Config.MOCK_MODE
        self.timeout  = Config.REQUEST_TIMEOUT

    # ── Internal helpers ──────────────────────────────────────────────

    def _get(self, path: str, params: dict = None) -> dict:
        """Make a GET request to OpenCost and return the JSON body."""
        url  = f"{self.base_url}{path}"
        resp = requests.get(url, params=params, timeout=self.timeout)
        resp.raise_for_status()
        body = resp.json()
        # OpenCost wraps results in {"code":200,"data":[...]}
        if "data" in body:
            return body["data"]
        return body

    def _window_params(self, window: str, accumulate: bool = True) -> dict:
        return {"window": window, "accumulate": str(accumulate).lower()}

    # ── Public methods ────────────────────────────────────────────────

    def get_allocation(self, window: str = None, aggregate: str = "namespace") -> dict:
        """
        Cost breakdown for the given window, grouped by `aggregate`.

        aggregate options:
          namespace   → per Kubernetes namespace
          deployment  → per Deployment
          pod         → per Pod
          controller  → per controller (Deployment, DaemonSet, Job, etc.)
          label:team  → per value of the "team" label
        """
        window = window or Config.DEFAULT_WINDOW
        if self.mock:
            return self._mock_allocation(window, aggregate)
        # VERIFY: confirm this path against your OpenCost version
        params = {**self._window_params(window), "aggregate": aggregate}
        raw = self._get("/model/allocation", params)
        return self._normalise_allocation(raw, window, aggregate)

    def get_savings(self) -> dict:
        """
        Returns workloads with low efficiency — over-provisioned pods
        that are good rightsizing candidates.

        We fetch allocation by deployment, then rank by lowest efficiency.
        """
        if self.mock:
            return self._mock_savings()
        window = Config.DEFAULT_WINDOW
        params = {**self._window_params(window), "aggregate": "deployment"}
        raw = self._get("/model/allocation", params)
        return self._extract_savings(raw, window)

    def get_trend(self, window: str = None) -> dict:
        """
        Compares the CURRENT window against the PREVIOUS window of the same
        length to show cost changes.
        """
        window = window or Config.DEFAULT_WINDOW
        if self.mock:
            return self._mock_trend(window)
        # Current period
        current = self._get(
            "/model/allocation",
            {**self._window_params(window), "aggregate": "namespace"}
        )
        # Previous period — shift the window back
        prev_params = {
            "aggregate": "namespace",
            "accumulate": "true",
            **self._previous_window(window),
        }
        previous = self._get("/model/allocation", prev_params)
        return self._build_trend(current, previous, window)

    def healthcheck(self) -> tuple:
        """
        Returns (ok: bool, detail: str).
        In mock mode always returns (True, "mock").
        """
        if self.mock:
            return True, "mock"
        try:
            # VERIFY: /version is a lightweight endpoint on OpenCost
            resp = requests.get(
                f"{self.base_url}/version",
                timeout=self.timeout
            )
            resp.raise_for_status()
            # Try fetching one namespace to confirm data access
            data = self._get(
                "/model/allocation",
                {"window": "1d", "aggregate": "namespace", "accumulate": "true"}
            )
            count = len(data[0]) if data else 0
            return True, f"found {count} namespace(s)"
        except Exception as e:
            return False, str(e)

    # ── Response normalisers ──────────────────────────────────────────

    def _normalise_allocation(self, raw: list, window: str, aggregate: str) -> dict:
        """Turn OpenCost's raw response into a clean, flat list."""
        items = []
        if raw and isinstance(raw[0], dict):
            for key, val in raw[0].items():
                if key == "__idle__":
                    continue
                items.append({
                    "name":           val.get("name", key),
                    "totalCost":      round(val.get("totalCost", 0), 2),
                    "cpuCost":        round(val.get("cpuCost", 0), 2),
                    "ramCost":        round(val.get("ramCost", 0), 2),
                    "pvCost":         round(val.get("pvCost", 0), 2),
                    "networkCost":    round(val.get("networkCost", 0), 2),
                    "efficiency":     round(val.get("efficiency", 0), 3),
                    "cpuEfficiency":  round(val.get("cpuEfficiency", 0), 3),
                    "ramEfficiency":  round(val.get("ramEfficiency", 0), 3),
                })
        items.sort(key=lambda x: x["totalCost"], reverse=True)
        total = sum(i["totalCost"] for i in items)
        return {"window": window, "aggregate": aggregate,
                "items": items, "totalCost": round(total, 2), "currency": "USD"}

    def _extract_savings(self, raw: list, window: str) -> dict:
        """Build a savings list from allocation data: sort by lowest efficiency."""
        normalised = self._normalise_allocation(raw, window, "deployment")
        # Only include workloads with meaningful cost and poor efficiency
        candidates = [
            i for i in normalised["items"]
            if i["totalCost"] > 1.0 and i["efficiency"] < 0.7
        ]
        # Estimate potential saving: what we could save if efficiency reached 0.75
        for c in candidates:
            target_eff    = 0.75
            waste_fraction = max(0, target_eff - c["efficiency"])
            c["estimatedWeeklySaving"] = round(c["totalCost"] * waste_fraction, 2)
        candidates.sort(key=lambda x: x["estimatedWeeklySaving"], reverse=True)
        return {"window": window, "opportunities": candidates,
                "currency": "USD"}

    def _build_trend(self, current: list, previous: list, window: str) -> dict:
        """Compare current vs previous period per namespace."""
        def flatten(raw):
            result = {}
            if raw and isinstance(raw[0], dict):
                for k, v in raw[0].items():
                    if k != "__idle__":
                        result[k] = round(v.get("totalCost", 0), 2)
            return result

        curr_map = flatten(current)
        prev_map = flatten(previous)
        all_keys = set(curr_map) | set(prev_map)
        changes  = []
        for k in all_keys:
            c = curr_map.get(k, 0)
            p = prev_map.get(k, 0)
            pct = round(((c - p) / p * 100) if p > 0 else 0, 1)
            changes.append({
                "namespace":   k,
                "current":     c,
                "previous":    p,
                "change":      round(c - p, 2),
                "changePct":   pct,
            })
        changes.sort(key=lambda x: abs(x["change"]), reverse=True)
        curr_total = sum(curr_map.values())
        prev_total = sum(prev_map.values())
        return {
            "window":        window,
            "currentTotal":  round(curr_total, 2),
            "previousTotal": round(prev_total, 2),
            "changePct":     round(((curr_total - prev_total) / prev_total * 100)
                                   if prev_total > 0 else 0, 1),
            "byNamespace":   changes,
            "currency":      "USD",
        }

    def _previous_window(self, window: str) -> dict:
        """
        Build start/end query params for the period BEFORE the given window.
        e.g. if window=7d, returns the 7 days before today.
        """
        days = int(window.replace("d", ""))
        end   = date.today() - timedelta(days=days)
        start = end - timedelta(days=days)
        return {
            "window": f"{start.isoformat()}T00:00:00Z,"
                      f"{end.isoformat()}T23:59:59Z"
        }

    # ── Mock data ─────────────────────────────────────────────────────

    def _mock_allocation(self, window: str, aggregate: str) -> dict:
        items = [
            {"name": "payments",      "totalCost": 342.50, "cpuCost": 210.00,
             "ramCost": 98.50,  "pvCost": 34.00, "networkCost": 0.00,
             "efficiency": 0.42, "cpuEfficiency": 0.38, "ramEfficiency": 0.45},
            {"name": "data-platform", "totalCost": 518.00, "cpuCost": 320.00,
             "ramCost": 160.00, "pvCost": 38.00, "networkCost": 0.00,
             "efficiency": 0.71, "cpuEfficiency": 0.68, "ramEfficiency": 0.73},
            {"name": "auth",          "totalCost": 88.20,  "cpuCost": 55.00,
             "ramCost": 28.20,  "pvCost": 5.00,  "networkCost": 0.00,
             "efficiency": 0.81, "cpuEfficiency": 0.80, "ramEfficiency": 0.82},
            {"name": "notifications", "totalCost": 44.10,  "cpuCost": 28.00,
             "ramCost": 14.10,  "pvCost": 2.00,  "networkCost": 0.00,
             "efficiency": 0.58, "cpuEfficiency": 0.50, "ramEfficiency": 0.65},
            {"name": "dev",           "totalCost": 155.00, "cpuCost": 100.00,
             "ramCost": 50.00,  "pvCost": 5.00,  "networkCost": 0.00,
             "efficiency": 0.19, "cpuEfficiency": 0.15, "ramEfficiency": 0.22},
            {"name": "monitoring",    "totalCost": 62.40,  "cpuCost": 38.00,
             "ramCost": 20.40,  "pvCost": 4.00,  "networkCost": 0.00,
             "efficiency": 0.75, "cpuEfficiency": 0.74, "ramEfficiency": 0.76},
        ]
        if aggregate == "deployment":
            items = [
                {"name": "checkout-api",      "totalCost": 198.00, "cpuCost": 140.00,
                 "ramCost": 58.00,  "pvCost": 0.00, "networkCost": 0.00,
                 "efficiency": 0.18, "cpuEfficiency": 0.15, "ramEfficiency": 0.21},
                {"name": "payment-processor", "totalCost": 144.50, "cpuCost": 90.00,
                 "ramCost": 44.50,  "pvCost": 10.00, "networkCost": 0.00,
                 "efficiency": 0.62, "cpuEfficiency": 0.60, "ramEfficiency": 0.63},
                {"name": "ml-trainer",        "totalCost": 310.00, "cpuCost": 200.00,
                 "ramCost": 100.00, "pvCost": 10.00, "networkCost": 0.00,
                 "efficiency": 0.88, "cpuEfficiency": 0.90, "ramEfficiency": 0.86},
                {"name": "dev-api",           "totalCost": 95.00,  "cpuCost": 65.00,
                 "ramCost": 30.00,  "pvCost": 0.00,  "networkCost": 0.00,
                 "efficiency": 0.12, "cpuEfficiency": 0.10, "ramEfficiency": 0.14},
                {"name": "notification-svc",  "totalCost": 44.10,  "cpuCost": 28.00,
                 "ramCost": 14.10,  "pvCost": 2.00,  "networkCost": 0.00,
                 "efficiency": 0.58, "cpuEfficiency": 0.50, "ramEfficiency": 0.65},
            ]
        items.sort(key=lambda x: x["totalCost"], reverse=True)
        total = sum(i["totalCost"] for i in items)
        return {"window": window, "aggregate": aggregate,
                "items": items, "totalCost": round(total, 2), "currency": "USD"}

    def _mock_savings(self) -> dict:
        return {
            "window": Config.DEFAULT_WINDOW,
            "currency": "USD",
            "opportunities": [
                {"name": "checkout-api", "totalCost": 198.00,
                 "efficiency": 0.18, "cpuEfficiency": 0.15, "ramEfficiency": 0.21,
                 "estimatedWeeklySaving": 112.86,
                 "detail": "9 replicas running, typical load needs 2-3"},
                {"name": "dev-api",      "totalCost": 95.00,
                 "efficiency": 0.12, "cpuEfficiency": 0.10, "ramEfficiency": 0.14,
                 "estimatedWeeklySaving": 59.85,
                 "detail": "dev deployment left running overnight and weekends"},
                {"name": "notifications","totalCost": 44.10,
                 "efficiency": 0.58, "cpuEfficiency": 0.50, "ramEfficiency": 0.65,
                 "estimatedWeeklySaving": 7.52,
                 "detail": "memory requests are double actual usage"},
            ],
        }

    def _mock_trend(self, window: str) -> dict:
        return {
            "window":        window,
            "currentTotal":  1210.20,
            "previousTotal": 987.40,
            "changePct":     22.6,
            "currency":      "USD",
            "byNamespace": [
                {"namespace": "payments",      "current": 342.50, "previous": 221.00,
                 "change": 121.50, "changePct": 55.0},
                {"namespace": "data-platform", "current": 518.00, "previous": 501.00,
                 "change": 17.00,  "changePct": 3.4},
                {"namespace": "dev",           "current": 155.00, "previous": 120.00,
                 "change": 35.00,  "changePct": 29.2},
                {"namespace": "auth",          "current": 88.20,  "previous": 90.00,
                 "change": -1.80,  "changePct": -2.0},
                {"namespace": "monitoring",    "current": 62.40,  "previous": 55.40,
                 "change": 7.00,   "changePct": 12.6},
            ],
        }
