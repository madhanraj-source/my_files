"""
bridge.py
---------
Ties everything together.

  1. Fetch cost data from OpenCost
  2. Build a prompt with prompt_builder
  3. Send it to Gauss
  4. Return the answer

The CLI (ccops) calls the methods on this class.
The Bridge does not know whether it is in mock or real mode —
that decision is handled by the client classes.
"""

import datetime
from config          import Config
from opencost_client import OpenCostClient
from gauss_client    import GaussClient
from prompt_builder  import build_prompt


class BridgeResult:
    """What the Bridge returns to the CLI for every command."""
    def __init__(self, answer: str, data: dict, question: str):
        self.answer   = answer    # plain-English answer from Gauss
        self.data     = data      # raw data from OpenCost (for debugging)
        self.question = question  # the question that was asked


class Bridge:

    def __init__(self):
        self.opencost = OpenCostClient()
        self.gauss    = GaussClient()

    # ── Private helpers ───────────────────────────────────────────────

    def _run(self, question: str, data: dict) -> BridgeResult:
        """
        Core method used by every command:
          1. Build the prompt from the data
          2. Ask Gauss
          3. Write to audit log
          4. Return result
        """
        prompt = build_prompt(question, data)
        answer = self.gauss.ask(prompt)
        self._audit(question)
        return BridgeResult(answer=answer, data=data, question=question)

    def _audit(self, question: str):
        """Append the question + timestamp to the local audit log."""
        try:
            line = f"{datetime.datetime.now().isoformat()}\t{question}\n"
            with open(Config.AUDIT_LOG, "a", encoding="utf-8") as f:
                f.write(line)
        except Exception:
            pass  # Auditing must never crash the tool

    # ── Command handlers ──────────────────────────────────────────────
    # One method per ccops sub-command.

    def handle_cost(self, by: str = "namespace", window: str = None,
                    namespace: str = None) -> BridgeResult:
        """
        ccops cost [--by namespace|deployment] [--window 7d] [--namespace X]
        """
        data = self.opencost.get_allocation(window=window, aggregate=by)
        # If user asked for one namespace, filter the results
        if namespace:
            data["items"] = [
                i for i in data["items"]
                if namespace.lower() in i["name"].lower()
            ]
            question = (
                f"Explain the cost breakdown for the {namespace} namespace "
                f"and whether it is efficient."
            )
        else:
            question = (
                f"Explain the Kubernetes cost breakdown by {by}. "
                f"Highlight the most expensive ones and flag any with low efficiency."
            )
        return self._run(question, data)

    def handle_savings(self, top: int = 5) -> BridgeResult:
        """
        ccops savings [--top N]
        Identifies over-provisioned workloads and estimates potential savings.
        """
        data = self.opencost.get_savings()
        data["opportunities"] = data["opportunities"][:top]
        question = (
            f"Here are the top {top} over-provisioned Kubernetes workloads. "
            f"Explain which to fix first, why, and what the estimated saving is."
        )
        return self._run(question, data)

    def handle_trend(self, window: str = None) -> BridgeResult:
        """
        ccops trend [--window 7d]
        Compares this period vs the previous period of the same length.
        """
        data     = self.opencost.get_trend(window=window)
        question = (
            "Compare Kubernetes costs this period against the previous period. "
            "Explain what changed, which namespaces drove the change, and why."
        )
        return self._run(question, data)

    def handle_ask(self, question: str, window: str = None) -> BridgeResult:
        """
        ccops ask "free text question"
        Pulls a broad context so Gauss can answer anything.
        """
        data = {
            "cost_by_namespace": self.opencost.get_allocation(
                window=window, aggregate="namespace"
            ),
            "savings_opportunities": self.opencost.get_savings(),
            "trend": self.opencost.get_trend(window=window),
        }
        return self._run(question, data)

    # ── Health check ──────────────────────────────────────────────────

    def health(self) -> dict:
        oc_ok, oc_detail = self.opencost.healthcheck()
        return {
            "mode":              "mock" if Config.MOCK_MODE else "real",
            "opencost_ok":       oc_ok,
            "opencost_detail":   oc_detail,
            "gauss_ok":          self.gauss.healthcheck(),
        }
