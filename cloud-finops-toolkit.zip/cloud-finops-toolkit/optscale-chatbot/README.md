# OptScale FinOps Chatbot

A chatbot that answers cloud cost questions by talking to a self-hosted
OptScale instance through its REST API. Bring your own hosted LLM
(Anthropic Claude, OpenAI, or any OpenAI-compatible provider).

## Architecture

```
You ──► chatbot (this repo) ──► hosted LLM API (Anthropic/OpenAI/etc.)
                │
                └──► self-hosted OptScale REST API ──► your billing data
                                                       (stays in your network)
```

- OptScale stores and analyzes your billing data — billing data never leaves your network.
- The LLM only sees JSON snippets that OptScale's API returns, never your raw cloud accounts.
- Tool/function calling means the LLM cannot fabricate numbers — every fact in the
  reply traces back to a tool call against your OptScale.

## Quick start

```bash
# 1. Install
pip install pyyaml

# 2. Configure
cp config.example.yaml config.yaml
$EDITOR config.yaml           # set optscale URL, email, and LLM choice

# 3. Set secrets
export ANTHROPIC_API_KEY=sk-ant-...
export OPTSCALE_PASSWORD='your-optscale-password'

# 4. Run
python main.py --config config.yaml
```

## Examples

Interactive REPL:
```
> what did we spend last week?
> why did costs spike on May 7th?
> show me unused disks larger than 100GB
> what are the top 5 optimization recommendations?
> compare this month vs last month, broken down by service
```

One-shot mode:
```bash
python main.py --config config.yaml --ask "any cost anomalies this month?"
```

Show what the LLM is doing under the hood:
```bash
python main.py --config config.yaml --verbose
```

## Available tools

The LLM gets these tools and chooses when to call them:

| Tool | Purpose |
|---|---|
| `get_cost_summary` | Total cost over a date range |
| `get_costs_breakdown` | Costs grouped by service/region/account/resource_type/pool |
| `compare_periods` | Diff two date ranges — best for "why did costs spike?" |
| `list_resources` | Filtered list of cloud resources |
| `get_resource_details` | Full info on one resource |
| `get_recommendations` | OptScale's optimization recommendations |
| `get_anomalies` | OptScale-flagged anomalies |
| `today` | Current date for resolving "last week" etc. |

Adding a tool = one entry in `chatbot/tools.py::TOOLS` + one dispatch case. The
LLM picks it up automatically.

## Customizing for your OptScale version

OptScale's REST API path layout has evolved across versions. The defaults in
`chatbot/optscale_client.py` match the typical paths (`/restapi/v2/...`,
`/auth/v2/tokens`), but if your instance differs:

1. Open `https://<your-optscale>/` in a browser and open DevTools → Network.
2. Click around the UI; note the paths and query params used.
3. Update the methods in `optscale_client.py` to match.

You can also point at the OpenAPI/Swagger spec your instance exposes (often at
`/api/restapi/swagger/`) for the authoritative shape.

## Secrets

Don't commit `config.yaml` with a real password. Two clean patterns:

**Env var expansion (simple):** put `${OPTSCALE_PASSWORD}` in the YAML and
load it in code — small change in `main.py::load_config`:
```python
text = os.path.expandvars(p.read_text())
return yaml.safe_load(text)
```

**Secret manager (production):** fetch from AWS Secrets Manager, Vault, or
Kubernetes secrets and inject as env vars at runtime. The chatbot never sees
the plaintext on disk.

## How it answers "why did costs spike?"

A real multi-turn trace (verbose mode):
```
> why did costs jump on May 7th?
  → today({})
    ← {"today": "2026-05-12"}
  → get_anomalies({"last_n_days": 14})
    ← {"anomalies": [{"date": "2026-05-07", "service": "AmazonS3", ...}]}
  → compare_periods({"period_a_start":"2026-05-06","period_a_end":"2026-05-07",
                     "period_b_start":"2026-05-07","period_b_end":"2026-05-08",
                     "group_by":"service_name"})
    ← {"period_a": {...$1,240...}, "period_b": {...$3,890...}}
  → list_resources({"service_name":"AmazonS3","active":true,"limit":10})
    ← {"resources": [{"name":"backup-prod-logs", "size_gb": 8200, ...}]}

S3 spend tripled on May 7 ($1,240 → $3,890). The driver is the
backup-prod-logs bucket, which grew from ~200 GB to 8.2 TB overnight…
```

That's eight lines of natural language driven by four real API calls. No
hallucination — every number came from your OptScale.

## Files

```
optscale-chatbot/
├── main.py                       # CLI entrypoint
├── config.example.yaml
├── requirements.txt
└── chatbot/
    ├── __init__.py
    ├── optscale_client.py        # REST API wrapper
    ├── tools.py                  # Tool catalog + dispatcher
    ├── llm.py                    # Anthropic + OpenAI-compatible backends
    └── chat.py                   # Multi-turn tool-use loop
```

About 600 lines total. Read in an hour.

## Safety notes

- Read-only. None of the tools mutate anything in OptScale or your clouds.
- The LLM is told via the system prompt to refuse to invent numbers. Tool
  errors surface to the user as errors, not fabricated answers.
- Conversation history is in-memory only. Add persistence (sqlite, redis)
  in `ChatSession` if you need it.
- The OptScale credentials should belong to a dedicated chatbot user with
  read-only permissions on the org.
