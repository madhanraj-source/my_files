# Cloud Cost Optimization Agent — Comparative Report

**Subject:** A cloud-agnostic, LLM-pluggable, open-source cost optimization agent
**Audience:** FinOps practitioners, platform engineers, CTOs, procurement, infosec
**Purpose:** Honestly position this agent against the 2026 FinOps tool landscape — who should adopt it, who shouldn't, and why.

---

## 1. Executive summary

The cost optimization agent described in this report is a **small, open-source, cloud-agnostic Python tool** that scans AWS, Azure, GCP (or any custom-defined cloud), finds cost waste using a deterministic rules engine, and produces an executive summary using **the LLM of the user's choice — local or hosted**.

It is **not** trying to compete with Cloudability, CloudHealth, Finout, or Cloudchipr on feature breadth. Those platforms are mature, well-staffed, and ship hundreds of features the agent does not have (RI/SP optimization math, anomaly detection, forecasting, polished dashboards, RBAC, SSO).

What this agent offers that **no current tool combines in one package** is:

1. **Multi-cloud, vendor-neutral architecture** — one provider interface, any cloud
2. **Choice of LLM, including a fully local one** — Ollama, vLLM, llama.cpp, Anthropic, OpenAI, or none
3. **Two-stage design that prevents AI hallucinations** — rules find findings, LLM only summarizes
4. **No SaaS, no account, no data leaving your network** — billing data never sees a vendor cloud
5. **A codebase small enough to read in an hour** — ~600 lines, MIT-licensed, every line auditable

The agent is best understood as a **building block and reference implementation**, not a finished SaaS product. The right buyer is a team that values control, privacy, and customizability over polish and out-of-the-box breadth.

---

## 2. What the agent actually does

| Capability | Status |
|---|---|
| Inventory of compute and storage across multiple clouds | ✅ Implemented |
| Rules engine for waste detection (idle VMs, rightsizing, orphan disks, old snapshots, stopped-but-billing VMs) | ✅ Implemented |
| Per-finding monthly saving estimate, prioritized output | ✅ Implemented |
| LLM-generated executive summary, with the LLM constrained to summarize-only | ✅ Implemented |
| Markdown and JSON report output | ✅ Implemented |
| Healthcheck for credential verification | ✅ Implemented |
| Read-only mode (no provider mutation) | ✅ Implemented by design |
| RI/SP/CUD purchasing recommendations | ❌ Not implemented |
| Anomaly detection / forecasting | ❌ Not implemented |
| Kubernetes pod-level allocation | ❌ Not implemented (use OpenCost) |
| Web dashboard | ❌ Not implemented (Markdown/JSON only) |
| RBAC, SSO, audit log | ❌ Not implemented |

---

## 3. The 2026 FinOps tool landscape

The market splits into four categories.

### 3.1 Native cloud tools (free, but single-cloud)
**AWS Cost Explorer + Trusted Advisor + Compute Optimizer · Azure Cost Management + Advisor · GCP Cost Management + Recommender**

Strengths: free, deep integration with their own cloud, accurate billing data.
Weaknesses: single-cloud only, no cross-cloud reporting, limited customization, no LLM narration.

### 3.2 Enterprise commercial platforms (SaaS, paid)
**Apptio Cloudability (IBM) · CloudHealth (Broadcom) · Flexera · Finout · CloudZero · Vantage · Cloudchipr**

Strengths: rich dashboards, multi-cloud roll-up, anomaly detection, forecasting, tagless allocation, chargeback/showback, customer support, SSO, RBAC. Several now ship AI assistants.
Weaknesses: $$$ pricing (often a percentage of cloud spend), data must be sent to vendor cloud, vendor lock-in, slow to customize, AI features locked into their SaaS.

### 3.3 Automation specialists (SaaS, paid)
**ProsperOps · Spot.io · Zesty · Hykell · Densify**

Strengths: automated RI/SP management, GPU/AI workload optimization, automated rightsizing actions.
Weaknesses: narrow focus, requires write access to your accounts, opaque savings math, vendor lock-in.

### 3.4 Open-source projects (free, self-hosted)
**Komiser · Cloud Custodian (c7n) · OpenCost / Kubecost · Infracost · OptScale · Powerpipe**

Strengths: free, self-hosted, transparent, customizable.
Weaknesses: each solves one slice of the problem; combining them takes engineering work; none ship native LLM integration; most lack natural-language reporting.

---

## 4. Head-to-head comparison

The most direct comparisons are with the open-source tools and with the "AI FinOps" features being added to commercial platforms. The table below shows where this agent uniquely sits.

| Dimension | This agent | Komiser | Cloud Custodian | OpenCost | Infracost | Cloudability / CloudHealth / Cloudchipr |
|---|---|---|---|---|---|---|
| **Cost** | Free, MIT | Free | Free | Free (CNCF) | Free / paid SaaS | Paid (typically % of spend) |
| **Self-hosted** | ✅ | ✅ | ✅ | ✅ | ✅ | ❌ SaaS only |
| **Multi-cloud** | ✅ (provider abstraction) | ✅ | ✅ | ✅ (K8s-focused) | ✅ (Terraform) | ✅ |
| **Cloud-agnostic by design** | ✅ One interface, any cloud | Partial | Partial | Partial | Partial | Cloud-specific connectors |
| **Local LLM support** | ✅ Ollama, vLLM, llama.cpp | ❌ | ❌ | ❌ | ❌ | ❌ |
| **Hosted LLM support** | ✅ Claude, OpenAI, OpenAI-compat | ❌ | ❌ | ❌ | ❌ | Some (locked to vendor) |
| **LLM narrative summary** | ✅ Hallucination-proof design | ❌ | ❌ | ❌ | ❌ | ✅ (vendor-managed) |
| **Pluggable rules engine** | ✅ One Python function per rule | ❌ Hard-coded | ✅ YAML DSL | ❌ | ❌ | ❌ |
| **Codebase size** | ~600 lines | ~50k+ | ~100k+ | ~50k+ | ~30k+ | Closed source |
| **Data leaves your network** | ❌ Never (with local LLM) | ❌ | ❌ | ❌ | Optional | ✅ Always |
| **Web dashboard** | ❌ (Markdown/JSON) | ✅ | ❌ | ✅ | ✅ | ✅ |
| **Anomaly detection / forecasting** | ❌ | ❌ | ❌ | Partial | ❌ | ✅ |
| **RI/SP/CUD optimization** | ❌ | ❌ | ❌ | ❌ | Partial | ✅ |
| **Kubernetes pod allocation** | ❌ | Partial | ❌ | ✅ Best in class | ❌ | ✅ |
| **Write/remediation actions** | ❌ Read-only by design | ❌ | ✅ | ❌ | ❌ | Some |
| **Time to first useful run** | Minutes (mock provider) | Hours | Hours–days | Hours | Minutes | Days–weeks |
| **Customer support / SLA** | ❌ Community / self | ❌ Community | ❌ Community | ❌ Community | ✅ (paid tier) | ✅ |

The pattern is clear: **the agent is not the broadest or the deepest tool** in any single category. Its differentiation is in the **combination**: cloud-neutral architecture + local-LLM option + small auditable codebase + hallucination-proof report generation.

---

## 5. Why this agent — five concrete reasons

### 5.1 Your billing data never leaves your network
Every commercial FinOps SaaS requires you to send cost-and-usage exports to vendor-hosted infrastructure. For most teams that is acceptable. For some — defense, government, regulated finance, healthcare, sovereign-cloud customers, organizations under data-residency mandates — it is a non-starter.

Even open-source tools like Komiser and OpenCost don't help if you want LLM-generated reports, because the LLM call typically goes to OpenAI or another hosted provider. **This agent is the only option in the comparison that can produce LLM-narrated FinOps reports entirely on-premises** by pairing the rules engine with a local Ollama or vLLM instance.

### 5.2 The LLM cannot fabricate savings
Commercial "AI FinOps" features often blur the line between deterministic analysis and LLM generation. When the LLM both finds and describes the issue, it is hard to know what is real and what is hallucinated.

This agent splits the two stages explicitly:

```
Rules engine → structured Findings (with IDs, costs, evidence) → LLM → prose summary
```

The LLM's system prompt forbids inventing resources, IDs, or numbers it wasn't given. Every recommendation in the final report is traceable to a specific finding produced by a specific rule on a specific resource. This is auditable in a way that "ask the AI about your bill" tools are not.

### 5.3 Cloud-agnostic in the architectural sense, not just the marketing sense
Most "multi-cloud" tools have separate connectors with separate quirks per cloud. This agent has one abstract base class — `CloudProvider` — with three methods. AWS, Azure, GCP, a mock provider, and any future cloud (OCI, Alibaba, IBM, on-prem OpenStack, even a CSV importer) implement the same interface.

The analyzer and narrator never know which cloud they are looking at. Adding support for a new cloud is one file; you do not need to fork or patch the agent's core.

### 5.4 The codebase is small enough to fully audit
Roughly 600 lines of Python across a clean package layout. A senior engineer can read all of it in under an hour and know exactly what it does. For comparison, Komiser and Cloud Custodian are tens of thousands of lines; commercial platforms are closed-source.

This matters for two reasons:
- **Security review** is fast — your infosec team can sign off in a single sitting.
- **Customization** is direct — adding a rule means writing one Python function, not learning a vendor DSL or filing a feature request.

### 5.5 Zero recurring cost
- No subscription
- No per-account fee
- No percentage-of-spend pricing (commercial tools commonly charge 2–5% of cloud spend)
- No data egress to a vendor

For an organization spending $10M/year on cloud, a 3% FinOps platform fee is $300k/year. The agent costs you the engineering hours to deploy and maintain it — typically a fraction of that, especially if you would have wanted custom rules anyway.

---

## 6. Where this agent is not the right answer

Honesty matters more than marketing in a buying decision. The agent should **not** be chosen if:

- **You need RI/SP/CUD purchasing automation.** Use ProsperOps, Zesty, Spot.io, or Cloudability.
- **Your cost problem is mostly Kubernetes.** Use OpenCost or Kubecost. K8s pod-level allocation is hard and they do it well.
- **You need pre-deployment IaC cost estimates in pull requests.** Use Infracost.
- **You want a polished web UI for finance and exec stakeholders.** Use a commercial platform.
- **You need anomaly detection, daily spend alerts, or forecasting.** Use CloudZero, Finout, or Cloudability.
- **You don't have Python engineers and don't want to maintain code.** Use a managed SaaS.
- **You need chargeback/showback for many business units with complex allocation rules.** Use Apptio Cloudability or Finout.
- **You need formal vendor support with an SLA.** This is community-maintained code.

---

## 7. Who should use this — by persona

### 7.1 Platform engineers and SREs at mid-sized companies
You already maintain Terraform, Ansible, observability stacks. Adding another Python tool with one config file is trivial. You don't want a SaaS that bills you a percentage of your AWS spend just for showing you charts you could build yourself.

**Use case:** Run weekly via cron. Email the Markdown report to engineering leads. Implement the top three findings each sprint. Add custom rules as you encounter new waste patterns.

### 7.2 FinOps practitioners at privacy-sensitive organizations
Government, defense contractors, healthcare, regulated finance, sovereign-cloud customers. Your data-handling rules forbid sending billing data outside controlled networks. Commercial FinOps is off the table.

**Use case:** Pair the agent with a local Ollama instance on a hardened workstation. The entire cost analysis happens inside your perimeter. Reports are generated as Markdown for internal distribution.

### 7.3 Consultants and MSPs doing one-off cost audits
You're hired for a two-week engagement to find waste in a client's cloud. You don't want to onboard them to a SaaS, sign contracts, or wait for procurement. You want to run something in their environment, generate a report, and leave the tool behind for them to keep using.

**Use case:** Clone the repo, point it at the client's accounts (read-only credentials), generate the report. Hand it over with the codebase so the client can rerun it themselves.

### 7.4 Internal platform teams building custom FinOps tooling
You have idiosyncratic infrastructure — a private cloud, an unusual mix of providers, an internal billing system — and commercial tools don't model your environment well. You want a starting point, not a finished product.

**Use case:** Treat the agent as a reference implementation. Fork it, write a `CloudProvider` for your internal billing system, add company-specific rules (e.g. "any GPU instance not tagged with a project ID and idle for 7 days is a finding"), wire it into your internal dashboards.

### 7.5 Small startups and indie developers
You're spending $2k–$50k/month on cloud. You can't justify $1000/month for a FinOps SaaS, and you don't have time to combine five open-source tools. You want one script that finds the obvious waste.

**Use case:** Run on-demand before each monthly billing cycle. Free, no signup, no data leaving your account.

### 7.6 Educators, researchers, FinOps Foundation course authors
You want to teach the two-stage rules-plus-LLM pattern, the FinOps lifecycle, or cloud abstraction design. A 600-line readable codebase is a far better teaching artifact than a 100k-line product.

**Use case:** Use as the basis for a workshop, course module, or research project on AI-assisted infrastructure analysis.

### 7.7 Build-vs-buy evaluators inside larger orgs
Before signing a $500k/year FinOps contract, you want to understand what you'd be buying. Running this agent against a single account for a week gives you a realistic floor: what's the savings opportunity I can find with a free tool? If it's already 80% of what a vendor demo found, you have leverage.

**Use case:** Internal proof of value to inform a commercial procurement decision.

---

## 8. When the agent is a complement, not a replacement

For many organizations, the right answer is **both**.

- **Commercial FinOps SaaS + this agent.** Use the SaaS for dashboards, allocation, and RI/SP. Use the agent inside restricted environments where SaaS access isn't allowed, or to enforce custom rules the vendor doesn't support.
- **OpenCost + this agent.** OpenCost handles Kubernetes-internal allocation; the agent handles VMs, disks, snapshots, and cross-cloud cost waste outside the cluster.
- **Cloud Custodian + this agent.** Cloud Custodian executes remediation policies; the agent provides the human-readable narrative and prioritization layer on top of inventory data.
- **Infracost + this agent.** Infracost catches cost issues pre-deployment in pull requests; the agent catches issues that already exist in production.

The agent's small footprint and clean interfaces make it easy to drop into an existing stack rather than replace one.

---

## 9. Total cost of ownership — a realistic look

| Cost line | Commercial SaaS | This agent |
|---|---|---|
| License / subscription | $50k–$1M+/yr (often % of spend) | $0 |
| Onboarding effort | Days to weeks (data exports, IAM, tagging) | Hours (read-only IAM role + config file) |
| Ongoing maintenance | Vendor handles | Eng team patches dependencies, adds rules |
| LLM API spend | Bundled (opaque) | $0 with local LLM, or pay-per-token if hosted |
| Audit / security review | Vendor questionnaire + DPA | Read 600 lines of code |
| Lock-in / exit cost | High (data, dashboards, custom allocations) | None |

For a team that values flexibility and is willing to invest a small amount of engineering time, the agent's TCO is dramatically lower. For a team that values turnkey delivery, the commercial TCO is more honest.

---

## 10. Adoption checklist

If you're considering deploying this agent:

1. **Confirm a real problem.** If your cloud bill is below ~$20k/month and you have no obvious waste, the agent will not pay for itself in effort.
2. **Confirm Python is acceptable.** The team needs at least one engineer comfortable maintaining Python and reading SDK docs.
3. **Decide on LLM strategy.** Local (Ollama on a workstation) for privacy; hosted (Claude, OpenAI) for higher-quality narration; none (`echo` backend) if you only want deterministic findings.
4. **Start with read-only credentials.** The agent is designed to be read-only; enforce that with IAM scope so it cannot be misused.
5. **Run against one account first.** Validate the findings manually before trusting the report.
6. **Add your own rules.** Out-of-the-box rules cover the universal waste patterns; the biggest savings usually come from rules specific to your environment.
7. **Schedule it.** Weekly cron + email or Slack post is enough for most teams.

---

## 11. Limitations and honest caveats

- **Rule coverage is intentionally narrow.** Five rules at launch (idle compute, rightsizing, orphan disks, old snapshots, stopped VMs). Commercial tools have hundreds. You will write your own.
- **Pricing data is approximate.** The agent uses cloud billing APIs where available and falls back to resource-based estimates; it does not currently model spot pricing, savings plans, or enterprise discount agreements.
- **No state.** Each run is independent. There is no historical trend storage; that's deliberate — pipe the JSON output to your own data warehouse if you want trends.
- **LLM output is non-deterministic.** Even with constraints, the prose summary varies between runs. The structured findings underneath are deterministic; treat the prose as a convenience.
- **Read-only by design is a constraint, not a feature gap.** If you need automated remediation, pair with Cloud Custodian or build a separate, carefully-gated executor.

---

## 12. Conclusion

The 2026 FinOps tool market is mature and crowded. Commercial platforms do far more than this agent. Open-source projects each cover a specific slice.

This agent's argument for existence is not "we do everything better." It is:

> **The smallest amount of code that can read multiple clouds, find waste, and produce an LLM-narrated report — using an LLM you control, on infrastructure you control, with a codebase you can fully audit.**

For organizations that value privacy, customizability, and zero vendor lock-in over polish and feature breadth, that combination is hard to find elsewhere. For organizations that want a turnkey FinOps platform with a UI, customer support, and dashboards out of the box, a commercial tool is the right choice — and this agent can sit alongside it in places where the commercial tool cannot reach.

The agent is best understood as a **deployable reference implementation**: small enough to read, flexible enough to extend, honest about what it does and what it doesn't. That is its competitive position.

---

*Report prepared on cost-optimization agent v0.1. Market comparisons based on 2026 vendor materials and public documentation.*
