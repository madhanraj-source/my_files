"""
LLM narrator.

Takes the Findings produced by the deterministic analyzer and asks the LLM
to write a concise executive summary + prioritized plan.

CRITICAL: the LLM is constrained by the system prompt to ONLY summarize the
findings it's given — it cannot invent new resources or fabricate savings.
This is how we keep an LLM-in-the-loop without losing auditability.
"""
from __future__ import annotations

import json
from .analyzer import Finding
from .llm import LLMClient


SYSTEM_PROMPT = """You are a FinOps assistant. You receive a JSON list of
findings produced by a deterministic cost-analysis engine, plus a summary
object. Your job is to:

1. Write a short executive summary (3-5 sentences) of the savings opportunity.
2. Group findings into a prioritized action plan (top 5 actions max),
   each with: action, affected resources, estimated monthly saving,
   risk level, and a one-line rollback note.
3. Call out any cross-cloud patterns (e.g. "orphaned storage is the biggest
   class of waste across both AWS and Azure").

HARD RULES:
- Do NOT invent resources, IDs, costs, or savings. Use ONLY the data given.
- Do NOT recommend actions that aren't supported by a finding.
- If the findings list is empty, say so honestly.
- Output in Markdown. No preamble like "Sure, here is...".
"""


def narrate(llm: LLMClient, findings: list[Finding], summary: dict) -> str:
    payload = {
        "summary": summary,
        "findings": [f.to_dict() for f in findings[:50]],  # cap context
    }
    user = (
        "Findings JSON follows. Produce the executive summary and action plan.\n\n"
        f"```json\n{json.dumps(payload, indent=2, default=str)}\n```"
    )
    return llm.complete(SYSTEM_PROMPT, user, temperature=0.2, max_tokens=1500)
