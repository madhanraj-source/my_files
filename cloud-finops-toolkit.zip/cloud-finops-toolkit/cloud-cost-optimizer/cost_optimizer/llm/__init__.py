"""
LLM abstraction.

The agent never imports an LLM SDK directly — it talks to LLMClient.
Supported backends:
  - "ollama"     : local, http://localhost:11434 (free, private, offline)
  - "openai_compatible" : any OpenAI-style /v1/chat/completions endpoint
                          (vLLM, LM Studio, llama.cpp server, Together, Groq…)
  - "anthropic"  : Claude API
  - "openai"     : OpenAI API
  - "echo"       : no LLM at all, returns deterministic stub (for testing)
"""
from __future__ import annotations

import json
import os
import urllib.request
import urllib.error
from abc import ABC, abstractmethod


class LLMClient(ABC):
    @abstractmethod
    def complete(self, system: str, user: str, *, temperature: float = 0.2,
                 max_tokens: int = 1500) -> str: ...


# --- Ollama (local) -----------------------------------------------------------

class OllamaClient(LLMClient):
    def __init__(self, model: str = "llama3.1:8b",
                 base_url: str = "http://localhost:11434"):
        self.model = model
        self.base_url = base_url.rstrip("/")

    def complete(self, system, user, *, temperature=0.2, max_tokens=1500):
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "stream": False,
            "options": {"temperature": temperature, "num_predict": max_tokens},
        }
        req = urllib.request.Request(
            f"{self.base_url}/api/chat",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=600) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return data["message"]["content"]


# --- OpenAI-compatible (vLLM, LM Studio, llama.cpp, Together, Groq) ----------

class OpenAICompatibleClient(LLMClient):
    """Any server speaking the OpenAI Chat Completions API."""

    def __init__(self, model: str, base_url: str, api_key: str = "not-needed"):
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key

    def complete(self, system, user, *, temperature=0.2, max_tokens=1500):
        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        req = urllib.request.Request(
            f"{self.base_url}/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
            },
        )
        with urllib.request.urlopen(req, timeout=600) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return data["choices"][0]["message"]["content"]


# --- Anthropic ---------------------------------------------------------------

class AnthropicClient(LLMClient):
    def __init__(self, model: str = "claude-sonnet-4-6",
                 api_key: str | None = None):
        self.model = model
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not self.api_key:
            raise RuntimeError("ANTHROPIC_API_KEY not set")

    def complete(self, system, user, *, temperature=0.2, max_tokens=1500):
        payload = {
            "model": self.model,
            "max_tokens": max_tokens,
            "temperature": temperature,
            "system": system,
            "messages": [{"role": "user", "content": user}],
        }
        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "x-api-key": self.api_key,
                "anthropic-version": "2023-06-01",
            },
        )
        with urllib.request.urlopen(req, timeout=600) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return "".join(b.get("text", "") for b in data.get("content", []))


# --- Echo (test) -------------------------------------------------------------

class EchoClient(LLMClient):
    def complete(self, system, user, *, temperature=0.2, max_tokens=1500):
        return (
            "## Executive summary (echo backend — no real LLM)\n"
            "Findings reviewed; see structured recommendations above.\n"
        )


# --- Factory -----------------------------------------------------------------

def build_llm(cfg: dict) -> LLMClient:
    """cfg = {'backend': 'ollama'|'openai_compatible'|'anthropic'|'openai'|'echo', ...}"""
    backend = (cfg.get("backend") or "echo").lower()
    if backend == "ollama":
        return OllamaClient(
            model=cfg.get("model", "llama3.1:8b"),
            base_url=cfg.get("base_url", "http://localhost:11434"),
        )
    if backend == "openai_compatible":
        return OpenAICompatibleClient(
            model=cfg["model"],
            base_url=cfg["base_url"],
            api_key=cfg.get("api_key", os.environ.get("LLM_API_KEY", "not-needed")),
        )
    if backend == "anthropic":
        return AnthropicClient(
            model=cfg.get("model", "claude-sonnet-4-6"),
            api_key=cfg.get("api_key"),
        )
    if backend == "openai":
        return OpenAICompatibleClient(
            model=cfg.get("model", "gpt-4o-mini"),
            base_url=cfg.get("base_url", "https://api.openai.com/v1"),
            api_key=cfg.get("api_key", os.environ.get("OPENAI_API_KEY", "")),
        )
    if backend == "echo":
        return EchoClient()
    raise ValueError(f"unknown LLM backend: {backend}")
