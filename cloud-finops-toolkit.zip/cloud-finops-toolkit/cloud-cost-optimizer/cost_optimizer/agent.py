"""Agent orchestration: collect → analyze → narrate → render."""
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Iterable

from .analyzer import Finding, analyze, summarize
from .llm import LLMClient
from .narrator import narrate
from .providers.base import CloudProvider, Resource


@dataclass
class Report:
    resources: list[Resource]
    findings: list[Finding]
    summary: dict
    narrative: str

    def to_json(self) -> str:
        return json.dumps({
            "summary": self.summary,
            "findings": [f.to_dict() for f in self.findings],
            "narrative": self.narrative,
            "resource_count": len(self.resources),
        }, indent=2, default=str)

    def to_markdown(self) -> str:
        lines = ["# Cloud Cost Optimization Report", ""]
        s = self.summary
        lines += [
            f"- **Resources scanned:** {len(self.resources)}",
            f"- **Findings:** {s['finding_count']}",
            f"- **Estimated monthly savings:** ${s['total_monthly_saving_usd']:.2f}",
            f"- **Annualized:** ${s['annualized_saving_usd']:.2f}",
            "",
            "## Executive Summary",
            "",
            self.narrative,
            "",
            "## All Findings",
            "",
        ]
        for f in self.findings:
            lines += [
                f"### [{f.severity.upper()}] {f.title}",
                f"- Provider/Resource: `{f.provider}` / `{f.resource_id}` ({f.resource_name})",
                f"- Saving: **${f.estimated_monthly_saving_usd:.2f}/mo**",
                f"- Detail: {f.detail}",
                f"- Recommendation: {f.recommendation}",
                "",
            ]
        return "\n".join(lines)


class CostOptimizationAgent:
    def __init__(self, providers: Iterable[CloudProvider], llm: LLMClient):
        self.providers = list(providers)
        self.llm = llm

    def run(self, *, narrate_with_llm: bool = True) -> Report:
        resources: list[Resource] = []
        for p in self.providers:
            try:
                resources.extend(p.list_resources())
            except Exception as e:
                print(f"[warn] {p.name} list_resources failed: {e}")

        findings = analyze(resources)
        summary = summarize(findings)

        narrative = ""
        if narrate_with_llm and findings:
            try:
                narrative = narrate(self.llm, findings, summary)
            except Exception as e:
                narrative = f"_(LLM narration failed: {e})_"
        elif not findings:
            narrative = "_No findings — environment looks clean._"

        return Report(resources=resources, findings=findings,
                      summary=summary, narrative=narrative)

    def healthcheck(self) -> list[tuple[str, bool, str]]:
        out = []
        for p in self.providers:
            ok, msg = p.healthcheck()
            out.append((p.name, ok, msg))
        return out
