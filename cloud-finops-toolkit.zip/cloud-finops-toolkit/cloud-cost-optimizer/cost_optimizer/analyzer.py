"""
Deterministic rules engine.

Two-stage design (this is the important architectural choice):
  Stage 1: rules engine here scans resources and emits structured Findings.
           Deterministic, auditable, cheap, doesn't hallucinate.
  Stage 2: LLM (see narrator.py) turns Findings into prose, prioritization,
           and Q&A. The LLM never invents recommendations — it only summarizes.

Each Finding includes an estimated monthly saving so the executive summary
can rank by impact.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Iterable

from .providers.base import Resource


@dataclass
class Finding:
    rule_id: str
    severity: str            # "low" | "medium" | "high"
    provider: str
    resource_id: str
    resource_name: str
    title: str
    detail: str
    estimated_monthly_saving_usd: float
    recommendation: str

    def to_dict(self) -> dict:
        return asdict(self)


# Tunable thresholds — easy to tweak per environment ---------------------------
THRESHOLDS = {
    "idle_cpu_pct": 5.0,            # below this avg CPU = idle
    "underutilized_cpu_pct": 20.0,  # below this avg CPU = downsize candidate
    "orphan_disk_age_days": 14,     # unattached longer than this = remove
    "old_snapshot_days": 180,       # snapshots older than this = review
    "stopped_vm_age_days": 30,      # stopped VMs lingering this long = terminate
}


# --- individual rules --------------------------------------------------------

def _rule_idle_compute(r: Resource) -> Finding | None:
    if r.resource_type != "compute":
        return None
    cpu = r.utilization.get("cpu_avg")
    if cpu is None or cpu >= THRESHOLDS["idle_cpu_pct"]:
        return None
    return Finding(
        rule_id="idle-compute",
        severity="high",
        provider=r.provider, resource_id=r.resource_id, resource_name=r.name,
        title=f"Idle VM (avg CPU {cpu:.1f}%)",
        detail=(f"{r.name} in {r.region} is averaging {cpu:.1f}% CPU over 14d. "
                f"Estimated monthly cost ${r.monthly_cost_usd:.2f}."),
        estimated_monthly_saving_usd=r.monthly_cost_usd,
        recommendation="Stop or terminate. If needed occasionally, move to "
                       "spot/preemptible or schedule on/off.",
    )


def _rule_underutilized_compute(r: Resource) -> Finding | None:
    if r.resource_type != "compute":
        return None
    cpu = r.utilization.get("cpu_avg")
    if cpu is None:
        return None
    if cpu >= THRESHOLDS["underutilized_cpu_pct"] or cpu < THRESHOLDS["idle_cpu_pct"]:
        return None  # idle case handled by other rule
    saving = r.monthly_cost_usd * 0.5  # rightsizing one step down ~ 50%
    return Finding(
        rule_id="rightsize-compute",
        severity="medium",
        provider=r.provider, resource_id=r.resource_id, resource_name=r.name,
        title=f"Underutilized VM (avg CPU {cpu:.1f}%)",
        detail=(f"{r.name} averages {cpu:.1f}% CPU. Likely oversized."),
        estimated_monthly_saving_usd=saving,
        recommendation="Downsize one instance class, or move to a burstable / "
                       "shared-core family.",
    )


def _rule_orphan_disk(r: Resource) -> Finding | None:
    if r.resource_type != "storage":
        return None
    md = r.metadata
    if md.get("attached") is not False:    # only act on explicit False
        return None
    age = md.get("age_days", 0)
    if age < THRESHOLDS["orphan_disk_age_days"]:
        return None
    return Finding(
        rule_id="orphan-disk",
        severity="high",
        provider=r.provider, resource_id=r.resource_id, resource_name=r.name,
        title=f"Unattached disk ({md.get('size_gb','?')} GB, {age}d old)",
        detail=f"{r.name} has been unattached for {age} days.",
        estimated_monthly_saving_usd=r.monthly_cost_usd,
        recommendation="Snapshot for safety, then delete the volume.",
    )


def _rule_old_snapshot(r: Resource) -> Finding | None:
    md = r.metadata
    if md.get("type") != "snapshot":
        return None
    age = md.get("age_days", 0)
    if age < THRESHOLDS["old_snapshot_days"]:
        return None
    return Finding(
        rule_id="old-snapshot",
        severity="low",
        provider=r.provider, resource_id=r.resource_id, resource_name=r.name,
        title=f"Old snapshot ({age}d)",
        detail=f"{r.name} is {age} days old.",
        estimated_monthly_saving_usd=r.monthly_cost_usd,
        recommendation="Verify retention policy. Delete if no longer required.",
    )


def _rule_stopped_vm(r: Resource) -> Finding | None:
    if r.resource_type != "compute":
        return None
    md = r.metadata
    if md.get("state") != "stopped":
        return None
    # AWS charges for attached EBS even when VM is stopped — flag it.
    return Finding(
        rule_id="stopped-vm",
        severity="medium",
        provider=r.provider, resource_id=r.resource_id, resource_name=r.name,
        title="Stopped VM still incurring storage cost",
        detail=f"{r.name} is stopped but attached disks still bill.",
        estimated_monthly_saving_usd=r.monthly_cost_usd * 0.15,
        recommendation="Terminate if not needed, or snapshot + delete to "
                       "preserve state cheaply.",
    )


RULES = [
    _rule_idle_compute,
    _rule_underutilized_compute,
    _rule_orphan_disk,
    _rule_old_snapshot,
    _rule_stopped_vm,
]


def analyze(resources: Iterable[Resource]) -> list[Finding]:
    findings: list[Finding] = []
    for r in resources:
        for rule in RULES:
            f = rule(r)
            if f is not None:
                findings.append(f)
    findings.sort(key=lambda f: f.estimated_monthly_saving_usd, reverse=True)
    return findings


def summarize(findings: list[Finding]) -> dict:
    total = sum(f.estimated_monthly_saving_usd for f in findings)
    by_severity: dict[str, int] = {}
    by_rule: dict[str, int] = {}
    by_provider: dict[str, float] = {}
    for f in findings:
        by_severity[f.severity] = by_severity.get(f.severity, 0) + 1
        by_rule[f.rule_id] = by_rule.get(f.rule_id, 0) + 1
        by_provider[f.provider] = by_provider.get(f.provider, 0) + f.estimated_monthly_saving_usd
    return {
        "total_monthly_saving_usd": round(total, 2),
        "annualized_saving_usd": round(total * 12, 2),
        "finding_count": len(findings),
        "by_severity": by_severity,
        "by_rule": by_rule,
        "saving_by_provider": {k: round(v, 2) for k, v in by_provider.items()},
    }
