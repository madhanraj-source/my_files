"""
Azure provider. Uses azure-identity + azure-mgmt-* SDKs.
Auth: DefaultAzureCredential (env vars, managed identity, az CLI, etc.).
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from .base import CloudProvider, CostRecord, Resource


class AzureProvider(CloudProvider):
    name = "azure"

    def __init__(self, subscription_id: str):
        if not subscription_id:
            raise ValueError("Azure subscription_id is required")
        self.subscription_id = subscription_id
        self._cred = None

    def _credential(self):
        if self._cred is not None:
            return self._cred
        try:
            from azure.identity import DefaultAzureCredential  # type: ignore
        except ImportError as e:
            raise RuntimeError("azure-identity not installed") from e
        self._cred = DefaultAzureCredential()
        return self._cred

    def healthcheck(self) -> tuple[bool, str]:
        try:
            from azure.mgmt.resource import ResourceManagementClient  # type: ignore
            client = ResourceManagementClient(self._credential(), self.subscription_id)
            # forces a real auth call
            next(iter(client.resource_groups.list()), None)
            return True, f"azure ok, sub={self.subscription_id[:8]}…"
        except Exception as e:
            return False, f"azure auth failed: {e}"

    def get_cost_records(self, days: int = 30) -> list[CostRecord]:
        try:
            from azure.mgmt.costmanagement import CostManagementClient  # type: ignore
        except ImportError:
            return []

        try:
            client = CostManagementClient(self._credential())
            scope = f"/subscriptions/{self.subscription_id}"
            end = datetime.now(timezone.utc)
            start = end - timedelta(days=days)
            query = {
                "type": "Usage", "timeframe": "Custom",
                "time_period": {"from": start.isoformat(), "to": end.isoformat()},
                "dataset": {
                    "granularity": "Daily",
                    "aggregation": {"totalCost": {"name": "Cost", "function": "Sum"}},
                    "grouping": [
                        {"type": "Dimension", "name": "ServiceName"},
                        {"type": "Dimension", "name": "ResourceLocation"},
                    ],
                },
            }
            result = client.query.usage(scope=scope, parameters=query)
        except Exception:
            return []

        records: list[CostRecord] = []
        cols = [c.name for c in (result.columns or [])]
        for row in result.rows or []:
            d = dict(zip(cols, row))
            cost = float(d.get("Cost", 0))
            if cost <= 0:
                continue
            records.append(CostRecord(
                provider="azure",
                service=str(d.get("ServiceName", "unknown")),
                region=str(d.get("ResourceLocation", "global")),
                cost_usd=cost,
                period_start=start, period_end=end,
            ))
        return records

    def list_resources(self) -> list[Resource]:
        resources: list[Resource] = []
        try:
            from azure.mgmt.compute import ComputeManagementClient  # type: ignore
            from azure.mgmt.monitor import MonitorManagementClient  # type: ignore
        except ImportError:
            return resources

        try:
            compute = ComputeManagementClient(self._credential(), self.subscription_id)
            monitor = MonitorManagementClient(self._credential(), self.subscription_id)
        except Exception:
            return resources

        try:
            for vm in compute.virtual_machines.list_all():
                util = self._vm_cpu(monitor, vm.id)
                resources.append(Resource(
                    provider="azure",
                    resource_id=vm.id,
                    resource_type="compute",
                    name=vm.name,
                    region=vm.location,
                    tags=vm.tags or {},
                    utilization=util,
                    metadata={
                        "vm_size": vm.hardware_profile.vm_size if vm.hardware_profile else None,
                        "os": vm.storage_profile.os_disk.os_type.name if vm.storage_profile else None,
                    },
                ))
        except Exception:
            pass

        # Unattached managed disks
        try:
            for disk in compute.disks.list():
                resources.append(Resource(
                    provider="azure",
                    resource_id=disk.id,
                    resource_type="storage",
                    name=disk.name,
                    region=disk.location,
                    tags=disk.tags or {},
                    metadata={
                        "size_gb": disk.disk_size_gb,
                        "sku": disk.sku.name if disk.sku else None,
                        "attached": disk.disk_state == "Attached",
                    },
                ))
        except Exception:
            pass

        return resources

    def _vm_cpu(self, monitor, vm_id: str) -> dict[str, float]:
        try:
            end = datetime.now(timezone.utc)
            start = end - timedelta(days=14)
            metrics = monitor.metrics.list(
                resource_uri=vm_id,
                timespan=f"{start.isoformat()}/{end.isoformat()}",
                interval="PT1H",
                metricnames="Percentage CPU",
                aggregation="Average,Maximum",
            )
            avgs, maxes = [], []
            for m in metrics.value:
                for ts in m.timeseries:
                    for pt in ts.data:
                        if pt.average is not None: avgs.append(pt.average)
                        if pt.maximum is not None: maxes.append(pt.maximum)
            if not avgs:
                return {}
            return {"cpu_avg": sum(avgs) / len(avgs), "cpu_max": max(maxes) if maxes else 0}
        except Exception:
            return {}
