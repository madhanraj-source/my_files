"""
Mock provider — generates realistic-looking inventory + billing.
Lets users run the agent end-to-end without any real cloud credentials.
"""
from __future__ import annotations

import random
from datetime import datetime, timedelta, timezone

from .base import CloudProvider, CostRecord, Resource


class MockProvider(CloudProvider):
    name = "mock"

    def __init__(self, seed: int = 42, label: str = "mock-cloud"):
        self.seed = seed
        self.label = label

    def list_resources(self) -> list[Resource]:
        rng = random.Random(self.seed)
        resources: list[Resource] = []

        sizes = [("small", 30), ("medium", 90), ("large", 250), ("xlarge", 600)]
        regions = ["us-east-1", "eu-west-1", "ap-south-1"]

        for i in range(12):
            size, cost = rng.choice(sizes)
            cpu_avg = rng.choice([2, 4, 7, 12, 35, 55, 78])  # bias toward low
            resources.append(Resource(
                provider=self.label,
                resource_id=f"vm-{1000+i}",
                resource_type="compute",
                name=f"app-server-{i:02d}",
                region=rng.choice(regions),
                tags={"env": rng.choice(["prod", "dev", "staging"])},
                monthly_cost_usd=cost,
                utilization={"cpu_avg": cpu_avg, "cpu_max": cpu_avg + rng.randint(5, 30)},
                metadata={"size": size, "age_days": rng.randint(10, 800)},
            ))

        # Some orphaned disks
        for i in range(5):
            size_gb = rng.choice([50, 100, 200, 500])
            resources.append(Resource(
                provider=self.label,
                resource_id=f"disk-{2000+i}",
                resource_type="storage",
                name=f"orphan-vol-{i}",
                region=rng.choice(regions),
                monthly_cost_usd=size_gb * 0.10,
                metadata={"size_gb": size_gb, "attached": False,
                          "age_days": rng.randint(60, 500)},
            ))

        # Snapshots
        for i in range(3):
            resources.append(Resource(
                provider=self.label,
                resource_id=f"snap-{3000+i}",
                resource_type="storage",
                name=f"old-snapshot-{i}",
                region=rng.choice(regions),
                monthly_cost_usd=rng.uniform(5, 25),
                metadata={"type": "snapshot", "age_days": rng.randint(200, 900)},
            ))

        return resources

    def get_cost_records(self, days: int = 30) -> list[CostRecord]:
        rng = random.Random(self.seed + 1)
        services = ["Compute", "Storage", "Network", "Database", "Logging"]
        out: list[CostRecord] = []
        end = datetime.now(timezone.utc)
        for d in range(days):
            day_end = end - timedelta(days=d)
            day_start = day_end - timedelta(days=1)
            for s in services:
                out.append(CostRecord(
                    provider=self.label, service=s, region="us-east-1",
                    cost_usd=round(rng.uniform(15, 220), 2),
                    period_start=day_start, period_end=day_end,
                ))
        return out
