"""
AWS provider. Uses boto3 (Cost Explorer + EC2 + CloudWatch).
Falls back gracefully if boto3 isn't installed or credentials are missing.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from typing import Any

from .base import CloudProvider, CostRecord, Resource


class AWSProvider(CloudProvider):
    name = "aws"

    def __init__(self, region: str = "us-east-1", profile: str | None = None):
        self.region = region
        self.profile = profile
        self._session = None

    # --- internal helpers -------------------------------------------------

    def _get_session(self):
        if self._session is not None:
            return self._session
        try:
            import boto3  # type: ignore
        except ImportError as e:
            raise RuntimeError("boto3 not installed. `pip install boto3`") from e
        self._session = (
            boto3.Session(profile_name=self.profile) if self.profile else boto3.Session()
        )
        return self._session

    def healthcheck(self) -> tuple[bool, str]:
        try:
            sts = self._get_session().client("sts", region_name=self.region)
            ident = sts.get_caller_identity()
            return True, f"aws ok, account={ident['Account']}"
        except Exception as e:
            return False, f"aws auth failed: {e}"

    # --- public API -------------------------------------------------------

    def get_cost_records(self, days: int = 30) -> list[CostRecord]:
        try:
            ce = self._get_session().client("ce", region_name="us-east-1")
            end = datetime.now(timezone.utc).date()
            start = end - timedelta(days=days)
            resp = ce.get_cost_and_usage(
                TimePeriod={"Start": str(start), "End": str(end)},
                Granularity="DAILY",
                Metrics=["UnblendedCost"],
                GroupBy=[
                    {"Type": "DIMENSION", "Key": "SERVICE"},
                    {"Type": "DIMENSION", "Key": "REGION"},
                ],
            )
        except Exception:
            return []  # fail silently — analyzer will still work on resources

        records: list[CostRecord] = []
        for day in resp.get("ResultsByTime", []):
            t0 = datetime.fromisoformat(day["TimePeriod"]["Start"])
            t1 = datetime.fromisoformat(day["TimePeriod"]["End"])
            for grp in day.get("Groups", []):
                service, region = grp["Keys"]
                amount = float(grp["Metrics"]["UnblendedCost"]["Amount"])
                if amount <= 0:
                    continue
                records.append(CostRecord(
                    provider="aws", service=service, region=region,
                    cost_usd=amount, period_start=t0, period_end=t1,
                ))
        return records

    def list_resources(self) -> list[Resource]:
        resources: list[Resource] = []
        try:
            ec2 = self._get_session().client("ec2", region_name=self.region)
            cw = self._get_session().client("cloudwatch", region_name=self.region)
        except Exception:
            return resources

        # --- EC2 instances ---
        try:
            for page in ec2.get_paginator("describe_instances").paginate():
                for rsv in page.get("Reservations", []):
                    for inst in rsv.get("Instances", []):
                        if inst["State"]["Name"] not in ("running", "stopped"):
                            continue
                        tags = {t["Key"]: t["Value"] for t in inst.get("Tags", [])}
                        util = self._ec2_cpu(cw, inst["InstanceId"])
                        resources.append(Resource(
                            provider="aws",
                            resource_id=inst["InstanceId"],
                            resource_type="compute",
                            name=tags.get("Name", inst["InstanceId"]),
                            region=self.region,
                            tags=tags,
                            utilization=util,
                            metadata={
                                "instance_type": inst.get("InstanceType"),
                                "state": inst["State"]["Name"],
                                "launch_time": str(inst.get("LaunchTime")),
                            },
                        ))
        except Exception:
            pass

        # --- EBS volumes (look for orphans) ---
        try:
            for page in ec2.get_paginator("describe_volumes").paginate():
                for vol in page.get("Volumes", []):
                    attached = bool(vol.get("Attachments"))
                    tags = {t["Key"]: t["Value"] for t in vol.get("Tags", [])}
                    resources.append(Resource(
                        provider="aws",
                        resource_id=vol["VolumeId"],
                        resource_type="storage",
                        name=tags.get("Name", vol["VolumeId"]),
                        region=self.region,
                        tags=tags,
                        metadata={
                            "size_gb": vol["Size"],
                            "volume_type": vol["VolumeType"],
                            "attached": attached,
                            "created": str(vol.get("CreateTime")),
                        },
                    ))
        except Exception:
            pass

        return resources

    def _ec2_cpu(self, cw: Any, instance_id: str) -> dict[str, float]:
        try:
            end = datetime.now(timezone.utc)
            start = end - timedelta(days=14)
            resp = cw.get_metric_statistics(
                Namespace="AWS/EC2", MetricName="CPUUtilization",
                Dimensions=[{"Name": "InstanceId", "Value": instance_id}],
                StartTime=start, EndTime=end,
                Period=3600, Statistics=["Average", "Maximum"],
            )
            pts = resp.get("Datapoints", [])
            if not pts:
                return {}
            return {
                "cpu_avg": sum(p["Average"] for p in pts) / len(pts),
                "cpu_max": max(p["Maximum"] for p in pts),
            }
        except Exception:
            return {}
