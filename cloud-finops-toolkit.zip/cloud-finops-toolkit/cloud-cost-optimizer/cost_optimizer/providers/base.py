"""
Cloud provider abstraction.

Every cloud (AWS, Azure, GCP, OCI, on-prem, etc.) implements this interface.
The rest of the agent never imports a specific cloud SDK directly — it only
talks to CloudProvider. This is what makes the agent cloud-agnostic.
"""
from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


@dataclass
class Resource:
    """A single cloud resource (VM, disk, bucket, DB, load balancer, etc.)."""
    provider: str          # "aws" | "azure" | "gcp" | ...
    resource_id: str       # cloud-native ID
    resource_type: str     # normalized: "compute", "storage", "database", "network", "other"
    name: str
    region: str
    tags: dict[str, str] = field(default_factory=dict)
    monthly_cost_usd: float = 0.0
    utilization: dict[str, float] = field(default_factory=dict)   # cpu_avg, mem_avg, iops, ...
    metadata: dict[str, Any] = field(default_factory=dict)        # size, sku, attached state, age_days


@dataclass
class CostRecord:
    """A single line of billing data."""
    provider: str
    service: str           # e.g. "EC2", "S3", "Cosmos DB"
    region: str
    cost_usd: float
    period_start: datetime
    period_end: datetime
    tags: dict[str, str] = field(default_factory=dict)


class CloudProvider(ABC):
    """Implement this once per cloud."""

    name: str = "abstract"

    @abstractmethod
    def list_resources(self) -> list[Resource]:
        """Inventory of resources with cost + utilization populated."""

    @abstractmethod
    def get_cost_records(self, days: int = 30) -> list[CostRecord]:
        """Billing records for the last N days."""

    def healthcheck(self) -> tuple[bool, str]:
        """Return (ok, message). Override to verify credentials."""
        return True, f"{self.name}: no healthcheck implemented"
