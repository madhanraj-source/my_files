"""Provider registry — instantiate by name from config."""
from __future__ import annotations

from .base import CloudProvider, CostRecord, Resource


def build_provider(kind: str, **kwargs) -> CloudProvider:
    kind = kind.lower()
    if kind == "aws":
        from .aws import AWSProvider
        return AWSProvider(**kwargs)
    if kind == "azure":
        from .azure import AzureProvider
        return AzureProvider(**kwargs)
    if kind == "gcp":
        from .gcp import GCPProvider
        return GCPProvider(**kwargs)
    if kind == "mock":
        from .mock import MockProvider
        return MockProvider(**kwargs)
    raise ValueError(f"unknown provider: {kind}")


__all__ = ["CloudProvider", "Resource", "CostRecord", "build_provider"]
