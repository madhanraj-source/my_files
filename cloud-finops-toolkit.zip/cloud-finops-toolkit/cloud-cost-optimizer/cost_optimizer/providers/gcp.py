"""
GCP provider. Uses google-cloud-billing-budgets, google-cloud-compute,
google-cloud-monitoring. Auth: ADC (gcloud auth application-default login).

NOTE: GCP cost data lives in BigQuery (billing export). For simplicity this
file reads from a BigQuery dataset if configured, otherwise returns [].
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone

from .base import CloudProvider, CostRecord, Resource


class GCPProvider(CloudProvider):
    name = "gcp"

    def __init__(self, project_id: str, billing_bq_table: str | None = None):
        if not project_id:
            raise ValueError("GCP project_id is required")
        self.project_id = project_id
        # e.g. "my-project.billing_export.gcp_billing_export_v1_XXXXXX"
        self.billing_bq_table = billing_bq_table

    def healthcheck(self) -> tuple[bool, str]:
        try:
            from google.cloud import compute_v1  # type: ignore
            client = compute_v1.ZonesClient()
            next(iter(client.list(project=self.project_id)), None)
            return True, f"gcp ok, project={self.project_id}"
        except Exception as e:
            return False, f"gcp auth failed: {e}"

    def get_cost_records(self, days: int = 30) -> list[CostRecord]:
        if not self.billing_bq_table:
            return []
        try:
            from google.cloud import bigquery  # type: ignore
        except ImportError:
            return []
        try:
            client = bigquery.Client(project=self.project_id)
            sql = f"""
              SELECT service.description AS service, location.region AS region,
                     SUM(cost) AS cost,
                     MIN(usage_start_time) AS t0, MAX(usage_end_time) AS t1
              FROM `{self.billing_bq_table}`
              WHERE usage_start_time >=
                    TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL {days} DAY)
              GROUP BY service, region
              HAVING cost > 0
            """
            records: list[CostRecord] = []
            for row in client.query(sql).result():
                records.append(CostRecord(
                    provider="gcp",
                    service=row.service or "unknown",
                    region=row.region or "global",
                    cost_usd=float(row.cost),
                    period_start=row.t0 or datetime.now(timezone.utc),
                    period_end=row.t1 or datetime.now(timezone.utc),
                ))
            return records
        except Exception:
            return []

    def list_resources(self) -> list[Resource]:
        resources: list[Resource] = []
        try:
            from google.cloud import compute_v1  # type: ignore
        except ImportError:
            return resources

        try:
            instances = compute_v1.InstancesClient()
            agg = instances.aggregated_list(project=self.project_id)
            for zone, scoped in agg:
                if not scoped.instances:
                    continue
                for vm in scoped.instances:
                    resources.append(Resource(
                        provider="gcp",
                        resource_id=str(vm.id),
                        resource_type="compute",
                        name=vm.name,
                        region=zone.replace("zones/", ""),
                        tags={l.key: l.value for l in (vm.labels.items() if vm.labels else [])}
                              if isinstance(vm.labels, dict) else dict(vm.labels or {}),
                        metadata={
                            "machine_type": (vm.machine_type or "").split("/")[-1],
                            "status": vm.status,
                        },
                    ))
        except Exception:
            pass

        # Unattached persistent disks
        try:
            disks = compute_v1.DisksClient()
            for zone, scoped in disks.aggregated_list(project=self.project_id):
                if not scoped.disks:
                    continue
                for d in scoped.disks:
                    resources.append(Resource(
                        provider="gcp",
                        resource_id=str(d.id),
                        resource_type="storage",
                        name=d.name,
                        region=zone.replace("zones/", ""),
                        metadata={
                            "size_gb": d.size_gb,
                            "type": (d.type_ or "").split("/")[-1],
                            "attached": bool(d.users),
                        },
                    ))
        except Exception:
            pass

        return resources
