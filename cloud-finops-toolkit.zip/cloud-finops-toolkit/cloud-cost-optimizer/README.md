# Cloud Cost Optimization Agent

A cloud-agnostic FinOps agent that finds waste (idle VMs, oversized
instances, orphaned disks, old snapshots, stopped-but-billing resources) and
writes an executive summary with the LLM of your choice — **local or hosted**.

## Why this design

Two-stage architecture so the LLM never hallucinates savings:

1. **Deterministic analyzer** (`analyzer.py`) — pure Python rules over a
   normalized `Resource` model. Auditable, reproducible, cheap.
2. **LLM narrator** (`narrator.py`) — only summarizes and prioritizes the
   findings the rules engine produced. It cannot invent resources or numbers.

Everything is pluggable:

```
┌───────────────┐    ┌──────────────────┐    ┌────────────────┐
│ CloudProvider │───▶│  Analyzer (rules)│───▶│  LLM narrator  │
│  AWS / Azure  │    │   Finding objects│    │ Ollama / vLLM /│
│  GCP / mock / │    │   + savings est. │    │ Claude / OpenAI│
│  your own     │    └──────────────────┘    └────────────────┘
└───────────────┘
```

## Quick start (no cloud creds needed)

```bash
git clone <this repo>
cd cloud-cost-optimizer
pip install pyyaml
cp config.example.yaml config.yaml          # already set to mock + ollama

# Easiest LLM path — switch to echo backend if you don't have Ollama:
#   in config.yaml set:
#     llm: { backend: echo }

python main.py --config config.yaml
```

## Running against real clouds

```bash
# AWS
pip install boto3
aws configure         # or set AWS_PROFILE / IAM role

# Azure
pip install azure-identity azure-mgmt-resource azure-mgmt-compute \
            azure-mgmt-monitor azure-mgmt-costmanagement
az login

# GCP
pip install google-cloud-compute google-cloud-bigquery
gcloud auth application-default login
```

Uncomment the corresponding section in `config.yaml`, then:

```bash
python main.py --healthcheck                       # verify credentials
python main.py --config config.yaml --format markdown --output report.md
python main.py --config config.yaml --format json  --output report.json
python main.py --config config.yaml --no-llm       # rules-only, no LLM
```

## LLM backends

| backend | use when | requires |
|---|---|---|
| `ollama` | local, private, offline | `ollama pull llama3.1:8b` |
| `openai_compatible` | vLLM, LM Studio, llama.cpp, Together, Groq, OpenRouter | base_url + model |
| `anthropic` | hosted Claude | `ANTHROPIC_API_KEY` |
| `openai` | hosted OpenAI | `OPENAI_API_KEY` |
| `echo` | testing, no LLM | — |

All four share the same `LLMClient.complete(system, user)` contract — adding
a new backend is ~15 lines.

## Adding a new cloud

Implement `cost_optimizer/providers/base.py::CloudProvider`:

```python
class MyCloudProvider(CloudProvider):
    name = "mycloud"
    def list_resources(self) -> list[Resource]: ...
    def get_cost_records(self, days=30) -> list[CostRecord]: ...
```

Register it in `providers/__init__.py::build_provider`. The analyzer and
narrator pick it up with no changes — that's the whole point of the
abstraction.

## Adding a new rule

In `analyzer.py`, add a function `_rule_xxx(r: Resource) -> Finding | None`
and append it to `RULES`. Examples in the file cover idle VMs, rightsizing,
orphan disks, old snapshots, and stopped-but-billing VMs.

## File map

```
cloud-cost-optimizer/
├── main.py                    # CLI
├── config.example.yaml
├── requirements.txt
└── cost_optimizer/
    ├── agent.py               # orchestration + report rendering
    ├── analyzer.py            # deterministic rules engine
    ├── narrator.py            # LLM summarization (constrained)
    ├── llm/__init__.py        # Ollama / OpenAI-compat / Anthropic / OpenAI / echo
    └── providers/
        ├── base.py            # CloudProvider abstract base + Resource model
        ├── aws.py             # boto3
        ├── azure.py           # azure-mgmt-*
        ├── gcp.py             # google-cloud-*
        └── mock.py            # for demos / tests
```

## Safety

- LLM is told to summarize only; it doesn't see write credentials.
- Agent is **read-only** — no provider call ever mutates resources.
- Every recommendation has an explicit rollback note in the rendered report.

## License

MIT — do what you like.
