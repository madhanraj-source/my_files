#!/usr/bin/env python3
"""
Usage:
  python main.py --config config.yaml --format markdown
  python main.py --config config.yaml --format json --output report.json
  python main.py --healthcheck

The config file (YAML) defines which providers and which LLM backend to use.
See config.example.yaml.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from cost_optimizer import CostOptimizationAgent, build_llm, build_provider


def load_config(path: str) -> dict:
    p = Path(path)
    if not p.exists():
        sys.exit(f"config not found: {path}")
    text = p.read_text()
    # Tiny dependency-free YAML-ish loader (only handles our limited schema)
    # — but prefer real YAML if available.
    try:
        import yaml  # type: ignore
        return yaml.safe_load(text)
    except ImportError:
        try:
            return json.loads(text)
        except json.JSONDecodeError:
            sys.exit("Install pyyaml (`pip install pyyaml`) or use JSON config.")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--format", choices=["markdown", "json"], default="markdown")
    ap.add_argument("--output", help="Write to file instead of stdout")
    ap.add_argument("--healthcheck", action="store_true",
                    help="Verify provider credentials and exit")
    ap.add_argument("--no-llm", action="store_true",
                    help="Skip LLM narration (faster, deterministic only)")
    args = ap.parse_args()

    cfg = load_config(args.config)

    providers = [build_provider(p.pop("kind"), **p) for p in cfg.get("providers", [])]
    llm = build_llm(cfg.get("llm", {"backend": "echo"}))
    agent = CostOptimizationAgent(providers, llm)

    if args.healthcheck:
        for name, ok, msg in agent.healthcheck():
            status = "OK " if ok else "FAIL"
            print(f"[{status}] {name}: {msg}")
        return

    report = agent.run(narrate_with_llm=not args.no_llm)
    rendered = report.to_json() if args.format == "json" else report.to_markdown()

    if args.output:
        Path(args.output).write_text(rendered)
        print(f"wrote {args.output}")
    else:
        print(rendered)


if __name__ == "__main__":
    main()
