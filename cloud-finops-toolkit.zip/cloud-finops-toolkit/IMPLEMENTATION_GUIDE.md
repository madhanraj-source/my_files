# Implementation Guide

End-to-end walkthrough for deploying the Cloud FinOps Toolkit, from zero to a
working chatbot you can ask "why did our cloud bill spike last week?"

> **Read first:** the `COMPARISON_REPORT.md` in this folder explains which tool
> (this toolkit, OptScale, commercial SaaS) fits which organization. If you
> haven't decided yet, start there.

---

## Table of contents

1. [Architecture overview](#1-architecture-overview)
2. [Prerequisites](#2-prerequisites)
3. [Path A — standalone agent only](#3-path-a--standalone-agent-only)
4. [Path B — OptScale + chatbot (recommended for most teams)](#4-path-b--optscale--chatbot-recommended-for-most-teams)
5. [Detailed setup: OptScale](#5-detailed-setup-optscale)
6. [Detailed setup: the chatbot](#6-detailed-setup-the-chatbot)
7. [LLM API keys — Anthropic, OpenAI, others](#7-llm-api-keys--anthropic-openai-others)
8. [Verifying everything works](#8-verifying-everything-works)
9. [Production deployment patterns](#9-production-deployment-patterns)
10. [Customizing for your environment](#10-customizing-for-your-environment)
11. [Security and secrets management](#11-security-and-secrets-management)
12. [Troubleshooting](#12-troubleshooting)
13. [Extending the chatbot — adding tools and capabilities](#13-extending-the-chatbot--adding-tools-and-capabilities)
14. [Cost expectations](#14-cost-expectations)
15. [What this toolkit will NOT do for you](#15-what-this-toolkit-will-not-do-for-you)

---

## 1. Architecture overview

The recommended deployment combines three layers:

```
┌──────────────────────────────────────────────────────────────────────┐
│  USER                                                                │
│   ▲                                                                  │
│   │  natural-language questions and answers                          │
│   ▼                                                                  │
│  CHATBOT  (optscale-chatbot, this repo)                              │
│   │                                                                  │
│   ├──► HOSTED LLM API  (Anthropic Claude, OpenAI, or compatible)     │
│   │       returns: which tool to call, with what arguments,          │
│   │       and—after tool results come back—a natural-language reply  │
│   │                                                                  │
│   └──► OPTSCALE REST API  (self-hosted)                              │
│           returns: cost data, recommendations, anomalies, resources  │
│                                                                      │
│  OPTSCALE  (self-hosted on your K8s cluster)                         │
│   │                                                                  │
│   └──► CLOUD PROVIDER APIs  (AWS, Azure, GCP, Alibaba)               │
│           AWS Cost Explorer, Azure Cost Management, GCP Billing,     │
│           plus discovery/monitoring for resource state and metrics   │
└──────────────────────────────────────────────────────────────────────┘
```

**What flows where:**

- Your **billing data** stays in OptScale's databases (MariaDB, MongoDB, ClickHouse). It never reaches the LLM provider.
- The **LLM** sees only JSON snippets that tool calls return — enough to answer the question, no more.
- The **chatbot** is stateless between sessions (you can add persistence if you want).

**Why this design:**

- Privacy: billing data stays in your network.
- Trustworthy answers: the LLM can't fabricate numbers because it has no numbers of its own. Every fact in the reply traces to a specific tool call.
- Replaceable parts: swap LLM provider, swap OptScale for another FinOps backend, add new tools — none of those changes ripple through the rest.

---

## 2. Prerequisites

### For Path A (standalone agent)
- A workstation with Python 3.10+ installed
- Optional: cloud SDK credentials (AWS/Azure/GCP) if you want to scan real clouds
- Optional: Ollama or another LLM source

### For Path B (OptScale + chatbot)
- **OptScale deployment target:** an Ubuntu 22.04 or 24.04 host (or Kubernetes cluster) with **8+ CPU cores, 16+ GB RAM, 150+ GB SSD**.
- **Cloud read-only credentials** for each cloud account you want to analyze.
- **An LLM API key** — Anthropic, OpenAI, or any OpenAI-compatible provider (Together, Groq, OpenRouter, Fireworks, DeepInfra, Azure OpenAI).
- **A Python 3.10+ environment** to run the chatbot. Can be the same host as OptScale, a Docker container, or your laptop.
- **Network reachability:** the host running the chatbot must be able to reach (a) your OptScale instance and (b) your chosen LLM provider's API.

---

## 3. Path A — standalone agent only

Use this path if you want a single small tool with no other dependencies. Good for: small startups, consultants doing one-off audits, learning.

```bash
cd cloud-cost-optimizer
pip install pyyaml

# Optional: install the SDK(s) for the cloud(s) you want to scan
# pip install boto3                              # AWS
# pip install azure-identity azure-mgmt-compute  # Azure
# pip install google-cloud-compute               # GCP

cp config.example.yaml config.yaml
# Edit config.yaml: pick provider(s), pick LLM backend
python main.py --config config.yaml
```

Out of the box, the config uses a **mock cloud** so the agent runs end-to-end without any credentials. To scan real clouds, uncomment the relevant `kind: aws` / `kind: azure` / `kind: gcp` blocks in `config.yaml`.

The agent's full README is at `cloud-cost-optimizer/README.md`. The rest of this guide focuses on Path B.

---

## 4. Path B — OptScale + chatbot (recommended for most teams)

The high-level sequence:

1. Deploy OptScale on infrastructure you own.
2. Connect your cloud accounts (read-only IAM) to OptScale.
3. Wait an hour or two while OptScale pulls billing data and builds inventory.
4. Verify OptScale's web UI shows your cost data correctly.
5. Configure the chatbot: point it at OptScale, pick an LLM, supply API keys.
6. Run `test_setup.py` to verify connectivity.
7. Run `main.py` and start asking questions.

Sections 5 through 8 cover each step in detail.

---

## 5. Detailed setup: OptScale

OptScale is an open-source FinOps platform by Hystax. It's a Kubernetes-based application — non-trivial to deploy, but well-documented.

**This toolkit does not include OptScale.** Follow Hystax's official installation guide. Below is a summary; the canonical reference is https://github.com/hystax/optscale.

### 5.1 Provision a host

Minimum spec:
- Ubuntu 24.04 (22.04 also works)
- 8 CPU cores, 16 GB RAM, 150 GB NVMe SSD
- Private IP that the chatbot host can reach

### 5.2 Install prerequisites and clone OptScale

```bash
sudo apt update
sudo apt install -y python3-pip sshpass git python3-virtualenv python3-venv python3-dev
git clone https://github.com/hystax/optscale.git
cd optscale
```

### 5.3 Run the installer

OptScale uses Ansible + Helm + a single-node Kubernetes cluster. The repo has a `runkube.py` script that orchestrates this. Follow the latest README on the OptScale GitHub for exact commands — they evolve between versions.

A typical command looks like:

```bash
./runkube.py -o overlay/user_template.yml -- <deployment_name> <version>
```

Wait until all pods report `Running`:

```bash
kubectl get pods --watch
```

This takes 10–20 minutes the first time as images are pulled.

### 5.4 First login and create a user

Browse to `https://<your-host-ip>/`. Accept the self-signed certificate warning (you'll want to install a real cert via Let's Encrypt or your internal CA before production).

Create the first user account. This becomes the organization owner. **Save the password somewhere safe** — you'll need it for the chatbot config.

### 5.5 Connect cloud accounts

In the UI: **Settings → Data Sources → Add**. For each cloud:

- **AWS:** Create an IAM role/user with read-only policies (`ViewOnlyAccess` plus `AWSBillingReadOnlyAccess`). OptScale provides a CloudFormation template — use it.
- **Azure:** Register an app in Entra ID, give it Reader role on the subscription, and enter the credentials.
- **GCP:** Create a service account with billing-data-viewer and viewer roles, generate a key, upload the JSON.
- **Kubernetes:** Install the OptScale k8s-collector Helm chart in your cluster.

For each, OptScale takes 1–2 hours to pull historical billing and build inventory. Check **Resources** and **Recommendations** pages — once they show data, you're ready for the chatbot.

### 5.6 Create a dedicated chatbot user

Best practice: don't reuse your admin login for the chatbot.

In OptScale: **Settings → Employees → Invite**. Create `chatbot@your-domain.com` with **Member** role (read-only is enough). Set a strong password. This is what the chatbot will use.

### 5.7 Grab the organization ID (optional)

If your user belongs to multiple OptScale organizations, you'll need to specify which one the chatbot should query. Find it in the URL when you're viewing the org in the UI, e.g. `.../organization/12345678-aaaa-bbbb-cccc-ffffffffffff`.

If you only have one organization, the chatbot will auto-detect it.

---

## 6. Detailed setup: the chatbot

### 6.1 Get the code onto a machine

The chatbot can run anywhere with Python 3.10+ and network access to OptScale and the LLM provider:

- Your laptop (for personal use)
- A small VM (for shared team use)
- A Docker container on your platform (for production)

```bash
cd optscale-chatbot
pip install -r requirements.txt
```

That installs `pyyaml`. Everything else uses Python's standard library — no additional dependencies for HTTP or JSON.

### 6.2 Create your config

```bash
cp config.example.yaml config.yaml
```

Edit `config.yaml`. Here's an annotated example:

```yaml
optscale:
  base_url: https://optscale.your-company.internal     # no trailing slash
  email: chatbot@your-company.com                       # the dedicated user from §5.6
  password: ${OPTSCALE_PASSWORD}                        # read from env var
  # organization_id: 12345678-... (only if multi-org)
  verify_tls: true                                      # false ONLY for dev with self-signed certs

llm:
  backend: anthropic
  model: claude-sonnet-4-6
  # api_key picked up from $ANTHROPIC_API_KEY
```

### 6.3 Tell the config to read passwords from env vars

By default the `${OPTSCALE_PASSWORD}` placeholder won't be expanded. The simplest fix is to teach `main.py` to expand environment variables when reading config. Edit `main.py::load_config`:

```python
def load_config(path: str) -> dict:
    import os
    text = Path(path).read_text()
    text = os.path.expandvars(text)        # <- add this line
    try:
        import yaml
        return yaml.safe_load(text)
    except ImportError:
        return json.loads(text)
```

(In production, prefer fetching secrets from a real secret manager — see §11.)

### 6.4 Set your environment variables

```bash
export OPTSCALE_PASSWORD='the-password-you-set-in-step-5.6'
export ANTHROPIC_API_KEY=sk-ant-...     # or OPENAI_API_KEY=sk-...
```

For persistence across shell sessions, add these to your `~/.bashrc`, `~/.zshrc`, or a `.env` file you source.

---

## 7. LLM API keys — Anthropic, OpenAI, others

Pick one. All work the same from the chatbot's point of view.

### 7.1 Anthropic Claude (recommended)
- Sign up at https://console.anthropic.com
- Create an API key, set `ANTHROPIC_API_KEY=sk-ant-...`
- In config: `backend: anthropic`, `model: claude-sonnet-4-6` (or other current model)
- Claude has excellent tool-use accuracy, which matters for chained queries like "why did costs spike?"

### 7.2 OpenAI
- Sign up at https://platform.openai.com
- Create an API key, set `OPENAI_API_KEY=sk-...`
- In config: `backend: openai`, `model: gpt-4o-mini` (cheap, good enough) or `gpt-4o`

### 7.3 Any OpenAI-compatible provider

If you want to use Together, Groq, OpenRouter, Fireworks, DeepInfra, Azure OpenAI, or a self-hosted vLLM with tool-calling enabled:

```yaml
llm:
  backend: openai_compatible
  model: meta-llama/Llama-3.3-70B-Instruct-Turbo
  base_url: https://api.together.xyz/v1
  # api_key from $LLM_API_KEY or $OPENAI_API_KEY
```

**Heads up:** not every open-weight model handles function calling well. Llama 3.3, Qwen 2.5, and DeepSeek tend to work; smaller or older models often don't. Test with `--verbose` to see whether tool calls are firing correctly.

---

## 8. Verifying everything works

Always run the pre-flight check before going live:

```bash
python test_setup.py --config config.yaml
```

Expected output:

```
== OptScale ==
  [auth] ... OK  token acquired
  [list_orgs] ... OK  1 org(s)
  [today tool] ... OK  2026-05-12

== LLM ==
  [chat] ... OK  backend=anthropic, reply='PONG'

All checks passed. You're ready: `python main.py --config config.yaml`
```

If any line says **FAIL**, fix it before running the chatbot. Common failures:

- `auth → 401`: wrong email/password
- `auth → network error`: wrong URL, firewall, or TLS issue (try `verify_tls: false` in dev)
- `chat → 401`: bad LLM API key
- `chat → 429`: rate-limited; wait or check quota

### First real run

```bash
python main.py --config config.yaml
```

Try these questions:
```
> what did we spend last month?
> show me our top 10 most expensive resources
> any cost anomalies in the last 14 days?
> what would save us the most money if we acted on it?
> compare this week vs last week, by service
```

Add `--verbose` to watch the tool calls. Very useful when something looks off in an answer.

---

## 9. Production deployment patterns

The chatbot is a single Python process. Pick the pattern that fits your team.

### 9.1 Personal use — just run it on your laptop

Nothing wrong with this. `python main.py --config config.yaml` is fine for a FinOps analyst doing daily investigation.

### 9.2 Shared — Docker on a small VM

```bash
cd optscale-chatbot
docker build -t optscale-chatbot .
docker run --rm -it \
  -v $PWD/config.yaml:/config/config.yaml:ro \
  -e ANTHROPIC_API_KEY=$ANTHROPIC_API_KEY \
  -e OPTSCALE_PASSWORD=$OPTSCALE_PASSWORD \
  optscale-chatbot
```

For one-shot/scheduled use:

```bash
docker run --rm \
  -v $PWD/config.yaml:/config/config.yaml:ro \
  -e ANTHROPIC_API_KEY=$ANTHROPIC_API_KEY \
  -e OPTSCALE_PASSWORD=$OPTSCALE_PASSWORD \
  optscale-chatbot --ask "what are this week's anomalies?"
```

### 9.3 Scheduled — cron / systemd timer

A daily anomaly report mailed to the FinOps Slack channel:

```cron
# /etc/cron.d/finops-report
0 9 * * MON-FRI chatbot cd /opt/chatbot && \
  python main.py --config config.yaml \
  --ask "summarize cost anomalies and top 5 savings recommendations" \
  | mail -s "Daily FinOps brief" finops@your-company.com
```

### 9.4 Slack/Teams bot

Wrap `ChatSession.ask()` with a Slack Bolt or Teams Bot adapter. About 50 extra lines. Worth doing if your team lives in Slack — questions and answers stay where the team already is.

A minimal Slack Bolt sketch:

```python
from slack_bolt import App
from chatbot import ChatSession, OptScaleClient, build_backend

# Initialize once
optscale = OptScaleClient(...)
llm = build_backend(...)
sessions: dict[str, ChatSession] = {}     # one per Slack channel

app = App(token=SLACK_BOT_TOKEN)

@app.event("app_mention")
def handle(event, say):
    channel = event["channel"]
    session = sessions.setdefault(channel, ChatSession(llm, optscale))
    text = event["text"].split(">", 1)[-1].strip()    # strip the mention
    say(session.ask(text))

app.start(3000)
```

### 9.5 Web UI

Add a single-page web frontend talking to a Flask/FastAPI wrapper around `ChatSession`. About 200 extra lines including HTML. Useful if your finance team needs access but won't touch a terminal.

---

## 10. Customizing for your environment

### 10.1 Adjusting OptScale endpoint paths

The chatbot's `chatbot/optscale_client.py` assumes the typical OptScale REST layout (`/restapi/v2/...`, `/auth/v2/tokens`). If your version is different:

1. Open `https://<your-optscale>/` in a browser.
2. Open DevTools → Network.
3. Click around — note the actual API paths and query params.
4. Update the methods in `optscale_client.py` to match.

Or check `https://<your-optscale>/api/restapi/swagger/` if your instance exposes Swagger (most versions do).

### 10.2 Adding new tools

To add a new capability — say, a "show me cost trend" chart description — three edits:

1. **Add a method to `OptScaleClient`** in `optscale_client.py` that calls the right REST endpoint.
2. **Add a tool entry to `TOOLS`** in `tools.py` with a clear description (this is the prompt-engineering surface — the LLM uses it to decide when to call your tool).
3. **Add a dispatch case** in `tools.py::dispatch`.

That's it. Both Anthropic and OpenAI schemas regenerate automatically from `TOOLS`.

### 10.3 Editing the system prompt

The system prompt in `chatbot/chat.py::SYSTEM_PROMPT` controls behavior:
- How concise to be
- What workflow to follow for common question types
- Hard rules (don't fabricate numbers, never assume the answer)

If the chatbot's tone or workflow doesn't match your team, edit this string. No code changes required.

### 10.4 Persisting conversation history

By default, history lives in memory and resets when the process exits. For a long-running Slack bot, you might want to:
- Save messages to SQLite keyed by Slack channel
- Trim history when it gets too long (LLMs charge per token)
- Add a `--session-id` argument to resume conversations

Add this in `ChatSession.__init__` / `ask` / `reset`. Small change, ~30 lines.

---

## 11. Security and secrets management

### 11.1 Network posture

- The chatbot makes outbound calls to (a) your OptScale and (b) the LLM provider. Lock down inbound — it doesn't need any.
- If your LLM is hosted by a vendor (Anthropic, OpenAI), your firewall must allow egress to `api.anthropic.com` or `api.openai.com`. For more locked-down envs, use a private network endpoint or proxy.
- For sovereign / classified environments where no traffic can leave: use a self-hosted LLM via vLLM with the `openai_compatible` backend. No code changes — just point `base_url` at your vLLM server.

### 11.2 Credentials

Never commit `config.yaml` with real credentials to source control. Three good patterns:

**Pattern 1 — env vars (simplest).** Use `${VAR}` placeholders in config.yaml; expand them in `load_config` (§6.3). Inject env vars at runtime via your platform.

**Pattern 2 — secret manager (best).** Fetch secrets from AWS Secrets Manager / Hashicorp Vault / GCP Secret Manager / Azure Key Vault at startup. Five lines of code per provider.

**Pattern 3 — file with restricted permissions (acceptable on single-user hosts).** `chmod 600 config.yaml`, owned by the chatbot user. Fine if no other user accounts can read the host.

### 11.3 OptScale user permissions

The chatbot user should be **read-only on the relevant organization**. None of the tools the chatbot exposes are write tools — but defense in depth.

### 11.4 LLM provider data retention

Be aware of your LLM provider's data retention policy. Anthropic, OpenAI, and most enterprise providers offer zero-retention API tiers. If your billing data is sensitive, opt into a no-retention plan, sign a DPA, or use a self-hosted model.

### 11.5 Audit logging

Production tip: log every question, every tool call, every answer to an append-only audit log. Useful for:
- Reproducing what someone was told ("was the recommendation to delete that bucket the chatbot's idea?")
- Compliance review
- Improving the system prompt by spotting common failure modes

Add a `logging` call in `ChatSession.ask` and `chat.py`'s tool-call loop.

---

## 12. Troubleshooting

### "Auth failed: 401"
- Wrong email/password. Try logging into OptScale's UI with the same credentials.
- Confirm the `chatbot@` user actually exists and has access to the organization.

### "Network error" / connection refused
- Wrong `base_url`. Test with `curl -k https://<your-optscale>/api/restapi/v2/organizations` (with an auth header).
- DNS or firewall — is the chatbot host able to reach OptScale at all?

### "SSL: certificate verify failed"
- OptScale defaults to a self-signed cert. For development: set `verify_tls: false` in config. For production: install a real cert via Let's Encrypt or your internal CA.

### "Tool returned: unknown tool: X"
- The LLM hallucinated a tool name that doesn't exist. Usually means the model is weak at tool use. Try a stronger model (Claude Sonnet, GPT-4o). Verify with `--verbose`.

### LLM says "I don't have access to that data" when it does
- Check the tool descriptions in `tools.py` — the LLM uses them to decide whether to call. Make descriptions more specific. Re-run.

### Answers are slow
- Multi-turn tool use can take 5–15 seconds. Normal.
- If responses take 30+ seconds, you may be hitting a slow LLM. Try a smaller model or a faster provider.

### "rate limited / 429"
- LLM provider quota. Slow down, check your plan tier.

### Chatbot uses old data
- OptScale refreshes billing data hourly to daily depending on the cloud. If "yesterday's cost" isn't showing yet, give it time. Check OptScale's data-source sync status in the UI.

---

## 13. Extending the chatbot — adding tools and capabilities

The chatbot is small on purpose. You'll want to add things. Here are the most useful extensions, ordered roughly by value-per-effort:

### 13.1 Trend description
A `get_cost_trend(service, last_n_days)` tool that returns a list of daily costs. The LLM can then say "S3 has been climbing 12%/day for two weeks." ~30 lines.

### 13.2 Tag-based filtering
If your cloud uses tags for cost allocation (team, env, project), add filters to `list_resources` and a `get_costs_by_tag` tool. ~50 lines.

### 13.3 Action recommendations as JSON
Instead of (or in addition to) natural-language replies, return a structured list of recommended actions:
```json
{"actions": [{"resource_id": "...", "action": "stop", "saving_usd": 240, "risk": "low"}]}
```
Easy to feed into ticketing systems. Have the LLM produce both a prose answer AND a JSON block. ~20 lines + system-prompt edits.

### 13.4 Approval / write-action workflow
Currently read-only. To actually stop/terminate resources:
1. Add write tools that produce an approval token, not an immediate action.
2. Have a separate operator approve the token (UI or CLI).
3. Execute the action against the cloud provider directly (or via Cloud Custodian).
**Recommendation:** keep this in a separate service. Mixing read and write tools in one chatbot widens the blast radius if something goes wrong.

### 13.5 Multi-organization support
The current client uses one organization. To handle multiple, accept an `organization_id` argument on every tool. The LLM can ask the user which one. ~30 lines.

### 13.6 Caching tool results
Some OptScale endpoints are slow on first call. Cache results for 5–15 minutes in a dict keyed by (tool_name, args). ~20 lines. Speeds up follow-up questions in the same session.

### 13.7 RAG over your runbooks
For "what should I do about this anomaly?" questions, augment the system prompt with retrieval from your internal runbooks (Notion, Confluence, etc.). Maps to standard RAG patterns — use any embedding model + vector store. ~150 lines.

---

## 14. Cost expectations

### One-time
- Engineering time to deploy: ~1 day for OptScale + chatbot, assuming familiarity with Kubernetes
- Hardware for OptScale: ~$80/month for a suitable cloud VM, or $0 if you have spare capacity

### Recurring (per month, rough)

| Item | Cost |
|---|---|
| OptScale infra (8 CPU / 16 GB / 150 GB VM) | $50–$150 |
| LLM API usage (small team, ~200 questions/month, Claude Sonnet) | $5–$30 |
| LLM API usage (busy Slack bot, ~5,000 questions/month, gpt-4o-mini) | $20–$80 |
| LLM API usage (self-hosted on existing GPU) | $0 (electricity) |

Compare with commercial FinOps SaaS: typically **2–5% of your cloud spend**, often with a $10k–$50k/year minimum. For a $1M/year cloud bill that's $20k–$50k/year. The toolkit is a fraction of that.

The break-even point is roughly when your cloud bill exceeds **~$20k/month** — below that, the engineering time to maintain the toolkit may exceed what a SaaS would cost you.

---

## 15. What this toolkit will NOT do for you

Being honest about limits matters for your planning:

- **It won't automate RI/SP/CUD purchases.** Use ProsperOps, Zesty, Spot.io, or buy direct.
- **It won't replace OptScale's UI for finance stakeholders.** Keep the UI for them; use the chatbot for engineers and analysts.
- **It won't write to clouds.** Read-only by design (see §13.4 for safe write-action patterns).
- **It won't catch costs OptScale doesn't see.** If a cloud account isn't connected to OptScale, the chatbot won't know about it. Connect all accounts.
- **It won't replace anomaly detection.** OptScale does that; the chatbot just helps you investigate. If you don't want OptScale, use Path A and add anomaly detection to its rules engine.
- **It won't make decisions for you.** The chatbot surfaces facts. Humans decide whether to act on them.

---

## Appendix A — minimum viable deployment

If you just want the smallest possible thing that works:

```bash
# On any laptop:
git clone <this repo>
cd cloud-finops-toolkit/optscale-chatbot

pip install pyyaml

cat > config.yaml <<EOF
optscale:
  base_url: https://demo.optscale.com   # or your instance
  email: demo@hystax.com                 # use a real account
  password: $OPTSCALE_PASSWORD
llm:
  backend: anthropic
  model: claude-sonnet-4-6
EOF

export OPTSCALE_PASSWORD=...
export ANTHROPIC_API_KEY=...

python main.py --config config.yaml
```

That's it. Ten minutes start to finish, assuming OptScale credentials and an Anthropic key in hand.

---

## Appendix B — file map

```
cloud-finops-toolkit/
├── README.md
├── IMPLEMENTATION_GUIDE.md            (this file)
├── COMPARISON_REPORT.md               positioning vs OptScale, commercial tools
│
├── cloud-cost-optimizer/              standalone agent (Path A)
│   ├── README.md
│   ├── main.py
│   ├── config.example.yaml
│   ├── requirements.txt
│   └── cost_optimizer/
│       ├── agent.py
│       ├── analyzer.py
│       ├── narrator.py
│       ├── llm/__init__.py
│       └── providers/
│           ├── base.py
│           ├── aws.py
│           ├── azure.py
│           ├── gcp.py
│           └── mock.py
│
└── optscale-chatbot/                  OptScale + LLM chatbot (Path B)
    ├── README.md
    ├── main.py                        CLI entrypoint
    ├── test_setup.py                  pre-flight verification
    ├── Dockerfile
    ├── config.example.yaml
    ├── requirements.txt
    └── chatbot/
        ├── __init__.py
        ├── optscale_client.py         REST API wrapper
        ├── tools.py                   tool catalog + dispatcher
        ├── llm.py                     Anthropic + OpenAI-compatible
        └── chat.py                    multi-turn tool-use loop
```

---

*Questions, problems, suggestions — open an issue or send a PR.*
