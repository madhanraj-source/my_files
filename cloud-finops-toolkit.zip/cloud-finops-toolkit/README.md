# Cloud FinOps Toolkit

Two complementary cloud cost optimization projects plus a comparison report
that explains where each fits in the 2026 FinOps tool landscape.

## What's in the box

```
cloud-finops-toolkit/
├── IMPLEMENTATION_GUIDE.md       ← read this first
├── COMPARISON_REPORT.md          ← positioning vs OptScale, Cloudability, etc.
├── README.md                     ← you are here
├── cloud-cost-optimizer/         ← standalone agent (read-only, multi-cloud, pluggable LLM)
└── optscale-chatbot/             ← chatbot on top of self-hosted OptScale
```

## Which project do I use?

| If you have… | …use |
|---|---|
| No FinOps stack yet, want one small tool you fully own | `cloud-cost-optimizer` |
| OptScale (or plan to deploy it) and want a Q&A chatbot on top | `optscale-chatbot` |
| Both — want auditable rules-based reports AND a chat interface | Run both side-by-side |

## TL;DR — Fastest path to value

**Option A — just want a cost report.** Use `cloud-cost-optimizer`:
```bash
cd cloud-cost-optimizer
pip install pyyaml
cp config.example.yaml config.yaml
python main.py --config config.yaml
```
Works against a mock cloud out of the box. Swap to AWS/Azure/GCP by editing config.

**Option B — already running OptScale, want a chatbot.** Use `optscale-chatbot`:
```bash
cd optscale-chatbot
pip install pyyaml
cp config.example.yaml config.yaml
$EDITOR config.yaml                 # point at your OptScale and pick an LLM
export ANTHROPIC_API_KEY=sk-ant-...
export OPTSCALE_PASSWORD='...'
python test_setup.py --config config.yaml    # verify connectivity
python main.py --config config.yaml          # chat!
```

Full step-by-step is in **IMPLEMENTATION_GUIDE.md**.

## What each project demonstrates

**cloud-cost-optimizer** is the **reference implementation**:
- Two-stage architecture (deterministic rules + LLM narrator)
- Cloud-agnostic provider abstraction
- Local-LLM-capable (Ollama, vLLM) or hosted LLM
- ~600 lines, fully auditable

**optscale-chatbot** is the **production-pattern**:
- LLM with tool/function calling against OptScale's REST API
- Hosted LLM (Anthropic Claude or any OpenAI-compatible)
- Multi-turn tool use for complex questions ("why did costs spike?")
- Hallucination-proof (LLM has no cost data of its own — only sees tool output)

Both share the same core idea: **the LLM never invents numbers — it can only describe data
returned by deterministic code.**

## License

MIT. Use freely.
