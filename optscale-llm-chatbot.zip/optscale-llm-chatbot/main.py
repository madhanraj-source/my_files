#!/usr/bin/env python3
"""
OptScale FinOps chatbot.

Usage:
  python main.py --config config.yaml
  python main.py --config config.yaml --ask "why did our AWS costs spike last week?"
  python main.py --config config.yaml --verbose       # show tool calls
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from chatbot import ChatSession, OptScaleClient, build_backend


def load_config(path: str) -> dict:
    p = Path(path)
    if not p.exists():
        sys.exit(f"config not found: {path}")
    try:
        import yaml
        return yaml.safe_load(p.read_text())
    except ImportError:
        return json.loads(p.read_text())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--ask", help="One-shot question; otherwise opens a REPL")
    ap.add_argument("--verbose", action="store_true", help="Show tool calls")
    args = ap.parse_args()

    cfg = load_config(args.config)

    os_cfg = cfg["optscale"]
    optscale = OptScaleClient(
        base_url=os_cfg["base_url"],
        email=os_cfg["email"],
        password=os_cfg["password"],
        organization_id=os_cfg.get("organization_id"),
        verify_tls=os_cfg.get("verify_tls", True),
    )

    llm = build_backend(cfg["llm"])
    session = ChatSession(llm, optscale, verbose=args.verbose)

    if args.ask:
        print(session.ask(args.ask))
        return

    # REPL
    print("OptScale FinOps chatbot. Type 'exit' to quit, 'reset' to clear history.")
    while True:
        try:
            user = input("\n> ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not user:
            continue
        if user.lower() in ("exit", "quit"):
            break
        if user.lower() == "reset":
            session.reset()
            print("(history cleared)")
            continue
        try:
            answer = session.ask(user)
            print(f"\n{answer}")
        except Exception as e:
            print(f"\n[error] {e}")


if __name__ == "__main__":
    main()
