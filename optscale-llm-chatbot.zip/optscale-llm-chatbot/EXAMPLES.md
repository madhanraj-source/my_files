# Example questions to try

Once the chatbot is running, here are real questions across categories.
Add `--verbose` to `main.py` to see which tools fire for each one.

## Headline numbers
```
> what did we spend last month?
> total cloud cost yesterday?
> how much did AWS cost this week?
> what's our cost run-rate this month vs last month?
```

## Breakdowns
```
> show me cost by service for the last 30 days
> break down spend by region this month
> which cloud account spent the most this week?
> cost by resource type for last week
```

## Anomaly investigation
```
> any cost anomalies in the last 14 days?
> why did costs spike on May 7th?
> what changed between last week and this week?
> investigate the jump in S3 spend
```

## Resource inventory
```
> list all running EC2 instances in us-east-1
> show me unused disks larger than 100GB
> find resources tagged env=prod
> what GPU instances are running right now?
```

## Optimization
```
> what are the top 5 optimization recommendations?
> show me all idle VMs
> what would save us the most money?
> any rightsizing recommendations for production?
> show me orphaned disks and old snapshots
```

## Drill-downs (multi-turn — follow up after a previous answer)
```
> tell me more about that biggest cost driver
> which specific resources contributed to that spike?
> what's the age of those orphaned disks?
> are any of those idle VMs tagged production?
```

## Complex chained queries
```
> compare AWS and Azure spend this month, then tell me which is growing faster
> find the most expensive resource per region and tell me if any look underutilized
> what would our annual savings be if we acted on every recommendation?
```

## Tips for getting better answers

- **Be specific.** "Cost this week" → the bot has to guess the date range. "Cost from May 5 to May 12" → unambiguous.
- **Follow up.** The chatbot remembers the conversation. "Show me top 5 services" then "what about top 10?" works.
- **Ask 'why'.** The chatbot is good at multi-tool investigations. "Why did our bill go up?" will trigger `get_anomalies` → `compare_periods` → `list_resources` automatically.
- **Use --verbose during setup.** Confirms tool calls are firing and shows what data the LLM is working with.
- **Reset history.** Type `reset` in the REPL to clear conversation context. Useful when switching topics.
