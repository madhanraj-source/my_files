# Install & Usage Guide — OptScale LLM Chatbot

End-to-end walkthrough: from zero to a working chatbot answering "why did our cloud bill spike last week?"

---

## Contents

1. [Architecture](#1-architecture)
2. [Prerequisites](#2-prerequisites)
3. [Step 1 — Deploy OptScale](#3-step-1--deploy-optscale)
4. [Step 2 — Connect cloud accounts](#4-step-2--connect-cloud-accounts)
5. [Step 3 — Create a chatbot user](#5-step-3--create-a-chatbot-user)
6. [Step 4 — Get an LLM API key](#6-step-4--get-an-llm-api-key)
7. [Step 5 — Install the chatbot](#7-step-5--install-the-chatbot)
8. [Step 6 — Configure](#8-step-6--configure)
9. [Step 7 — Verify with the pre-flight check](#9-step-7--verify-with-the-pre-flight-check)
10. [Step 8 — Chat](#10-step-8--chat)
11. [Production deployment](#11-production-deployment)
12. [Customization](#12-customization)
13. [Security checklist](#13-security-checklist)
14. [Troubleshooting](#14-troubleshooting)
15. [Cost expectations](#15-cost-expectations)

---

## 1. Architecture

```
┌──────────────────────────────────────────────────────────────────────┐
│  USER                                                                │
│   ▲                                                                  │
│   │  natural-language questions and answers                          │
│   ▼                                                                  │
│  CHATBOT  (this repo)                                                │
│   │                                                                  │
│   ├──► HOSTED LLM API  (Anthropic Claude / OpenAI / compatible)      │
│   │       returns: tool to call → with args → then prose reply       │
│   │                                                                  │
│   └──► OPTSCALE REST API  (self-hosted, in your network)             │
│           returns: cost data, recommendations, anomalies, resources  │
│                                                                      │
│  OPTSCALE  (self-hosted)                                             │
│   │                                                                  │
│   └──► CLOUD PROVIDER APIs  (AWS / Azure / GCP / Alibaba)            │
└──────────────────────────────────────────────────────────────────────┘
```

**Data path:**
- Billing data lives in OptScale's databases. It never reaches the LLM provider.
- The LLM sees only the JSON snippets that tool calls return.
- The chatbot is stateless between sessions by default.

**Why this is hallucination-proof:** the LLM has no cost data of its own — every fact in its reply comes from a tool call against your OptScale.

---

## 2. Prerequisites

- **OptScale-capable host:** Ubuntu 22.04 / 24.04 with 8+ CPU, 16+ GB RAM, 150+ GB SSD. Can be a cloud VM or on-prem.
- **Cloud read-only credentials** for each account you want to analyze.
- **An LLM API key:** Anthropic, OpenAI, or any OpenAI-compatible provider (Together, Groq, OpenRouter, Fireworks, DeepInfra, Azure OpenAI).
- **Python 3.10+** on the machine that runs the chatbot. Can be the OptScale host, a separate VM, a Docker container, or your laptop.
- **Network:** the chatbot host must reach (a) OptScale and (b) the LLM provider's API.

---

## 3. Step 1 — Deploy OptScale

This project is the chatbot **on top of** OptScale. Install OptScale separately from https://github.com/hystax/optscale.

Summary (always check the latest README on their repo for current commands):

```bash
sudo apt update
sudo apt install -y python3-pip sshpass git python3-virtualenv python3-venv python3-dev
git clone https://github.com/hystax/optscale.git
cd optscale
./runkube.py -o overlay/user_template.yml -- <deployment_name> <version>
kubectl get pods --watch        # wait until all pods say Running
```

First boot is 10–20 minutes. Browse `https://<your-host>/` and create the first user account.

---

## 4. Step 2 — Connect cloud accounts

In the OptScale UI: **Settings → Data Sources → Add**.

- **AWS:** create an IAM role/user with `ViewOnlyAccess` + `AWSBillingReadOnlyAccess`. OptScale provides a CloudFormation template.
- **Azure:** register an Entra ID app, give Reader role on the subscription.
- **GCP:** service account with billing-data-viewer and viewer roles, upload the JSON key.
- **Kubernetes:** install OptScale's k8s-collector Helm chart in your cluster.

OptScale takes 1–2 hours to pull historical data and build inventory. Don't move on until the **Resources** and **Recommendations** pages show data.

---

## 5. Step 3 — Create a chatbot user

**Don't reuse your admin login.** In OptScale: **Settings → Employees → Invite**.

- Email: `chatbot@your-domain.com`
- Role: **Member** (read-only is enough)
- Set a strong password — save it to your secret manager.

Optional: copy the **organization ID** from the URL (`.../organization/<uuid>`). Only needed if the user belongs to multiple organizations.

---

## 6. Step 4 — Get an LLM API key

Pick one. All work the same way from the chatbot's perspective.

### Anthropic Claude (recommended)
- Sign up: https://console.anthropic.com
- Create API key, set `export ANTHROPIC_API_KEY=sk-ant-...`
- Best tool-use accuracy for chained queries like "why did costs spike?"

### OpenAI
- Sign up: https://platform.openai.com
- Set `export OPENAI_API_KEY=sk-...`
- Models: `gpt-4o-mini` (cheap) or `gpt-4o` (best)

### Any OpenAI-compatible provider
- Together, Groq, OpenRouter, Fireworks, DeepInfra, self-hosted vLLM
- Use the `openai_compatible` backend, set the `base_url`

> Heads up: not every open-weight model handles function calling well. Llama 3.3, Qwen 2.5, DeepSeek tend to work; smaller models often don't. Test with `--verbose` to confirm tool calls fire.

---

## 7. Step 5 — Install the chatbot

The chatbot is a single Python process. Run it anywhere with Python 3.10+ and network access to OptScale and the LLM provider.

```bash
unzip optscale-llm-chatbot.zip
cd optscale-llm-chatbot
pip install -r requirements.txt
```

Only one dependency: `pyyaml`. Everything else uses Python's standard library.

---

## 8. Step 6 — Configure

```bash
cp config.example.yaml config.yaml
```

Edit `config.yaml`:

```yaml
optscale:
  base_url: https://optscale.your-company.internal     # no trailing slash
  email: chatbot@your-company.com                       # from step 5.3
  password: ${OPTSCALE_PASSWORD}                        # read from env var
  # organization_id: 12345-...                          # only if multi-org
  verify_tls: true                                      # false ONLY for self-signed dev certs

llm:
  backend: anthropic
  model: claude-sonnet-4-6
  # api_key picked up from $ANTHROPIC_API_KEY
```

### Enable env-var expansion

So `${OPTSCALE_PASSWORD}` actually gets expanded, edit `main.py::load_config` and add one line:

```python
def load_config(path: str) -> dict:
    import os
    text = Path(path).read_text()
    text = os.path.expandvars(text)        # <- add this
    ...
```

### Set the env vars

```bash
export OPTSCALE_PASSWORD='the-password-from-step-5'
export ANTHROPIC_API_KEY=sk-ant-...
```

For permanence add to `~/.bashrc` / `~/.zshrc`, or use a secret manager (§13).

---

## 9. Step 7 — Verify with the pre-flight check

Always run this before chatting:

```bash
python test_setup.py --config config.yaml
```

Expected output:

```
== OptScale ==
  [auth] ... OK  token acquired
  [list_orgs] ... OK  1 org(s)
  [today tool] ... OK  2026-05-12

== LLM ==
  [chat] ... OK  backend=anthropic, reply='PONG'

All checks passed.
```

If anything says **FAIL**, fix it (see [Troubleshooting](#14-troubleshooting)) before continuing.

---

## 10. Step 8 — Chat

```bash
python main.py --config config.yaml
```

Try these:

```
> what did we spend last month?
> show me our top 10 most expensive resources
> any cost anomalies in the last 14 days?
> what would save us the most money if we acted on it?
> compare this week vs last week, by service
> why did costs jump on May 7th?
> list all running EC2 instances in us-east-1
> which AWS account is spending the most this month?
```

One-shot for scripting:

```bash
python main.py --config config.yaml --ask "any anomalies this week?"
```

Watch tool calls happen (useful for debugging):

```bash
python main.py --config config.yaml --verbose
```

A real multi-turn trace looks like:

```
> why did costs jump on May 7th?
  → today({})
    ← {"today": "2026-05-12"}
  → get_anomalies({"last_n_days": 14})
    ← {"anomalies": [{"date": "2026-05-07", "service": "AmazonS3", ...}]}
  → compare_periods({"period_a_start":"2026-05-06","period_a_end":"2026-05-07",
                     "period_b_start":"2026-05-07","period_b_end":"2026-05-08",
                     "group_by":"service_name"})
    ← {"period_a": {...$1,240...}, "period_b": {...$3,890...}}
  → list_resources({"service_name":"AmazonS3","active":true,"limit":10})
    ← {"resources": [{"name":"backup-prod-logs","size_gb":8200,...}]}

S3 spend tripled on May 7 ($1,240 → $3,890). The driver is the
backup-prod-logs bucket, which grew from ~200 GB to 8.2 TB overnight…
```

Four tool calls. Real data. No hallucination.

---

## 11. Production deployment

### Personal / analyst use
Just run `python main.py --config config.yaml` on your laptop. Done.

### Shared — Docker on a small VM
```bash
docker build -t optscale-chatbot .
docker run --rm -it \
  -v $PWD/config.yaml:/config/config.yaml:ro \
  -e ANTHROPIC_API_KEY=$ANTHROPIC_API_KEY \
  -e OPTSCALE_PASSWORD=$OPTSCALE_PASSWORD \
  optscale-chatbot
```

### Scheduled — cron daily brief
```cron
0 9 * * MON-FRI chatbot cd /opt/chatbot && \
  python main.py --config config.yaml \
  --ask "summarize cost anomalies and top 5 savings recommendations" \
  | mail -s "Daily FinOps brief" finops@your-company.com
```

### Slack bot
Wrap `ChatSession.ask()` with Slack Bolt — about 50 extra lines:

```python
from slack_bolt import App
from chatbot import ChatSession, OptScaleClient, build_backend

optscale = OptScaleClient(...)
llm = build_backend(...)
sessions: dict[str, ChatSession] = {}

app = App(token=SLACK_BOT_TOKEN)

@app.event("app_mention")
def handle(event, say):
    s = sessions.setdefault(event["channel"], ChatSession(llm, optscale))
    text = event["text"].split(">", 1)[-1].strip()
    say(s.ask(text))

app.start(3000)
```

### Web UI
Wrap `ChatSession` with FastAPI/Flask + a single-page frontend. About 200 lines. Useful if non-technical stakeholders need access.

---

## 12. Customization

### Adjust endpoint paths for your OptScale version
OptScale's REST paths have evolved. The defaults in `chatbot/optscale_client.py` match the typical layout (`/restapi/v2/...`, `/auth/v2/tokens`). If yours differs:

1. Open OptScale UI in browser → DevTools → Network
2. Click around, observe actual API paths
3. Update the methods in `optscale_client.py` to match

Or check `https://<your-optscale>/api/restapi/swagger/` for the authoritative spec.

### Add a new tool
Three edits, one place each:

1. **Method on `OptScaleClient`** (`optscale_client.py`) — wraps the REST call
2. **Entry in `TOOLS`** (`tools.py`) — name, description, parameter schema
3. **Dispatch case** (`tools.py::dispatch`) — maps tool name to client method

Schemas auto-regenerate for both Anthropic and OpenAI.

### Tune the system prompt
`chatbot/chat.py::SYSTEM_PROMPT`. Edit to change tone, default workflows, hard rules.

### Persist conversation history
Default is in-memory only. For a long-running Slack bot:
- Save messages to SQLite keyed by Slack channel ID
- Trim when history exceeds a token budget
- Add `--session-id` for resumption

About 30 lines in `ChatSession`.

---

## 13. Security checklist

- [ ] **Network:** chatbot host can reach OptScale + LLM provider. No inbound required.
- [ ] **TLS:** real cert on OptScale (Let's Encrypt or internal CA). `verify_tls: true` in config.
- [ ] **Chatbot OptScale user:** dedicated, read-only role, strong password.
- [ ] **Secrets:** in env vars or secret manager — never committed to git. `chmod 600 config.yaml` on shared hosts.
- [ ] **LLM provider DPA:** sign a Data Processing Agreement if billing data leaving your network for inference is a concern. Or use a self-hosted LLM.
- [ ] **Audit log:** log every question + tool call + answer to an append-only store. Useful for compliance and improving the system prompt.
- [ ] **Read-only enforcement:** the tools the chatbot exposes are all read. Don't add write tools without a separate approval workflow (see §12).

---

## 14. Troubleshooting

### `auth → 401`
Wrong email/password. Test by logging into OptScale UI with the same credentials.

### `auth → network error`
Wrong base_url, DNS, firewall, or TLS. Test with:
```bash
curl -k -X POST https://<your-optscale>/auth/v2/tokens \
  -H "Content-Type: application/json" \
  -d '{"email":"chatbot@x.com","password":"..."}'
```

### `SSL: certificate verify failed`
Self-signed cert. Dev: set `verify_tls: false`. Production: install a real cert.

### Tool returned `unknown tool: X`
LLM hallucinated a tool name. Usually means the model is weak at tool use — try a stronger one (Claude Sonnet, GPT-4o).

### LLM says "I don't have access" when it does
Tool descriptions in `tools.py` aren't specific enough. Make them clearer about what each tool returns and when to use it.

### Answers are slow (5–15s)
Normal for multi-turn tool use. 30+ seconds = slow LLM, try a faster provider or smaller model.

### `rate limited / 429`
LLM provider quota. Wait or upgrade plan.

### Old data in answers
OptScale refreshes billing hourly to daily depending on the cloud. Check data-source sync status in OptScale UI.

### Endpoint returns 404
Your OptScale version has a different REST path. See [Customization](#12-customization) §"Adjust endpoint paths".

---

## 15. Cost expectations

| Item | Monthly cost |
|---|---|
| OptScale infra (8 CPU / 16 GB / 150 GB VM) | $50–$150 |
| LLM API (small team, ~200 questions/mo, Claude Sonnet) | $5–$30 |
| LLM API (busy Slack bot, ~5,000 questions/mo, gpt-4o-mini) | $20–$80 |
| LLM API (self-hosted vLLM on existing GPU) | $0 (electricity) |

For comparison, commercial FinOps SaaS is typically **2–5% of cloud spend**. For a $1M/year cloud bill that's $20k–$50k/year — orders of magnitude more than this toolkit.

Break-even is roughly when your cloud bill exceeds **~$20k/month** — below that the engineering time to maintain the toolkit may exceed what a SaaS would cost.

---

## What this chatbot will NOT do

Honest limits:

- **No RI/SP/CUD purchasing.** Use ProsperOps, Zesty, Spot.io, or buy directly.
- **No write actions.** Read-only by design. If you want remediation, add a separate, gated approval workflow.
- **No coverage for accounts not connected to OptScale.** Connect every account.
- **No replacement for anomaly detection.** OptScale does that; this chatbot helps you investigate.
- **No decision-making.** It surfaces facts. Humans decide whether to act.

---

## File map

```
optscale-llm-chatbot/
├── README.md                        quick orientation
├── INSTALL_GUIDE.md                 this file
├── main.py                          CLI entrypoint
├── test_setup.py                    pre-flight check
├── Dockerfile                       container build
├── config.example.yaml              annotated config template
├── requirements.txt                 just pyyaml
└── chatbot/
    ├── __init__.py
    ├── optscale_client.py           REST API wrapper
    ├── tools.py                     tool catalog + dispatcher
    ├── llm.py                       Anthropic + OpenAI-compatible
    └── chat.py                      multi-turn tool-use loop
```

Total: ~600 lines of Python. Read in an hour.

---

*MIT licensed. Use freely.*
