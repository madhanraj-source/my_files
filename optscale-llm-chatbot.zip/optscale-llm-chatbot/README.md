# OptScale LLM Chatbot

A chatbot that answers cloud cost questions by talking to a self-hosted
OptScale instance through its REST API. Bring your own hosted LLM
(Anthropic Claude, OpenAI, or any OpenAI-compatible provider).

## Documentation

- **[INSTALL_GUIDE.md](INSTALL_GUIDE.md)** — full step-by-step setup (15 sections)
- **[EXAMPLES.md](EXAMPLES.md)** — sample questions to try
- This file — quick orientation

## Architecture

```
You ──► chatbot (this repo) ──► hosted LLM API (Anthropic/OpenAI/etc.)
                │
                └──► self-hosted OptScale REST API ──► your billing data
                                                       (stays in your network)
```

- OptScale stores and analyzes your billing data — billing data never leaves your network.
- The LLM only sees JSON snippets that OptScale's API returns, never your raw cloud accounts.
- Tool/function calling means the LLM cannot fabricate numbers — every fact in the
  reply traces back to a tool call against your OptScale.

## Quick start

```bash
# 1. Install
pip install -r requirements.txt

# 2. Configure
cp config.example.yaml config.yaml
$EDITOR config.yaml           # set OptScale URL, email, and LLM choice

# 3. Set secrets
export ANTHROPIC_API_KEY=sk-ant-...
export OPTSCALE_PASSWORD='your-optscale-password'

# 4. Verify
python test_setup.py --config config.yaml

# 5. Chat
python main.py --config config.yaml
```

If you don't have OptScale running yet — see `INSTALL_GUIDE.md` §3.

## Examples

Interactive REPL:
```
> what did we spend last week?
> why did costs spike on May 7th?
> show me unused disks larger than 100GB
> what are the top 5 optimization recommendations?
> compare this month vs last month, broken down by service
```

One-shot mode:
```bash
python main.py --config config.yaml --ask "any cost anomalies this month?"
```

Watch tool calls happen:
```bash
python main.py --config config.yaml --verbose
```

More examples in `EXAMPLES.md`.

## Available tools

The LLM gets these tools and chooses when to call them:

| Tool | Purpose |
|---|---|
| `get_cost_summary` | Total cost over a date range |
| `get_costs_breakdown` | Costs grouped by service/region/account/resource_type/pool |
| `compare_periods` | Diff two date ranges — best for "why did costs spike?" |
| `list_resources` | Filtered list of cloud resources |
| `get_resource_details` | Full info on one resource |
| `get_recommendations` | OptScale's optimization recommendations |
| `get_anomalies` | OptScale-flagged anomalies |
| `today` | Current date for resolving "last week" etc. |

Adding a tool = one entry in `chatbot/tools.py::TOOLS` + one dispatch case + one OptScale client method. See `INSTALL_GUIDE.md` §12.

## Customizing OptScale endpoint paths

OptScale's REST API path layout has evolved across versions. The defaults match
the typical paths (`/restapi/v2/...`, `/auth/v2/tokens`). If your instance differs:

1. Open `https://<your-optscale>/` in a browser, open DevTools → Network
2. Click around the UI; observe the actual paths used
3. Update the methods in `chatbot/optscale_client.py` to match

Or check `https://<your-optscale>/api/restapi/swagger/` if your version exposes it.

## Files

```
optscale-llm-chatbot/
├── README.md                          this file
├── INSTALL_GUIDE.md                   full setup walkthrough
├── EXAMPLES.md                        sample questions
├── main.py                            CLI entrypoint
├── test_setup.py                      pre-flight verification
├── Dockerfile
├── config.example.yaml
├── requirements.txt
└── chatbot/
    ├── __init__.py
    ├── optscale_client.py             REST API wrapper
    ├── tools.py                       tool catalog + dispatcher
    ├── llm.py                         Anthropic + OpenAI-compatible
    └── chat.py                        multi-turn tool-use loop
```

~600 lines of Python. Readable in an hour.

## Safety

- Read-only. None of the tools mutate anything in OptScale or your clouds.
- The LLM is told via the system prompt to refuse to invent numbers. Tool errors surface as errors, not fabricated answers.
- Conversation history is in-memory only by default. Add persistence in `ChatSession` if you need it.
- The OptScale credentials should belong to a dedicated chatbot user with read-only permissions on the org.

## License

MIT.
