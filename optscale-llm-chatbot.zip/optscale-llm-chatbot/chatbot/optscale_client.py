"""
Thin OptScale REST API client.

OptScale's REST API is exposed by its `restapi` microservice. Auth is via
bearer token obtained from the `auth` service.

The endpoint paths below match OptScale's typical layout. If your version
differs, adjust the paths in the methods — the rest of the chatbot stays
the same. Check your instance's OpenAPI spec at:
   https://<your-optscale>/api/restapi/swagger/
or look at the network tab while clicking around the UI.
"""
from __future__ import annotations

import json
import urllib.parse
import urllib.request
import urllib.error
from datetime import datetime, timedelta, timezone
from typing import Any


class OptScaleError(RuntimeError):
    pass


class OptScaleClient:
    def __init__(self, base_url: str, email: str, password: str,
                 organization_id: str | None = None, verify_tls: bool = True):
        self.base_url = base_url.rstrip("/")
        self.email = email
        self.password = password
        self.organization_id = organization_id
        self.verify_tls = verify_tls
        self._token: str | None = None

    # ---- low-level HTTP ------------------------------------------------------

    def _request(self, method: str, path: str, *, params: dict | None = None,
                 body: dict | None = None, authed: bool = True) -> Any:
        url = f"{self.base_url}{path}"
        if params:
            url += "?" + urllib.parse.urlencode(params, doseq=True)
        headers = {"Content-Type": "application/json"}
        if authed:
            headers["Authorization"] = f"Bearer {self._get_token()}"
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(url, data=data, method=method, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                raw = resp.read().decode()
                return json.loads(raw) if raw else {}
        except urllib.error.HTTPError as e:
            raise OptScaleError(f"{method} {path} → {e.code}: {e.read().decode()[:200]}")
        except urllib.error.URLError as e:
            raise OptScaleError(f"{method} {path} → network error: {e}")

    def _get_token(self) -> str:
        if self._token:
            return self._token
        resp = self._request(
            "POST", "/auth/v2/tokens",
            body={"email": self.email, "password": self.password},
            authed=False,
        )
        token = resp.get("token") or resp.get("access_token")
        if not token:
            raise OptScaleError(f"login failed, no token in response: {resp}")
        self._token = token
        return token

    # ---- tool-facing methods (these are what the LLM will call) -------------

    def list_organizations(self) -> list[dict]:
        """All organizations this user can see."""
        resp = self._request("GET", "/restapi/v2/organizations")
        return resp.get("organizations", resp if isinstance(resp, list) else [])

    def _org(self) -> str:
        if not self.organization_id:
            orgs = self.list_organizations()
            if not orgs:
                raise OptScaleError("no organization found for this user")
            self.organization_id = orgs[0]["id"]
        return self.organization_id

    def get_cost_summary(self, start_date: str, end_date: str) -> dict:
        """Total expenses across the org between two ISO dates (YYYY-MM-DD)."""
        return self._request(
            "GET", f"/restapi/v2/organizations/{self._org()}/summary_expenses",
            params={"start_date": _ts(start_date), "end_date": _ts(end_date)},
        )

    def get_costs_breakdown(self, start_date: str, end_date: str,
                            group_by: str = "service_name") -> dict:
        """Cost breakdown grouped by service_name | cloud_account_id | region | resource_type | pool_id."""
        return self._request(
            "GET", f"/restapi/v2/organizations/{self._org()}/breakdown_expenses",
            params={
                "start_date": _ts(start_date),
                "end_date": _ts(end_date),
                "breakdown_by": group_by,
            },
        )

    def get_resources(self, *, active: bool | None = None, cloud_type: str | None = None,
                      service_name: str | None = None, region: str | None = None,
                      limit: int = 50) -> dict:
        """List resources with optional filters."""
        params: dict[str, Any] = {"limit": limit}
        if active is not None: params["active"] = str(active).lower()
        if cloud_type: params["cloud_type"] = cloud_type
        if service_name: params["service_name"] = service_name
        if region: params["region"] = region
        return self._request(
            "GET", f"/restapi/v2/organizations/{self._org()}/cloud_resources",
            params=params,
        )

    def get_resource_details(self, resource_id: str) -> dict:
        return self._request("GET", f"/restapi/v2/cloud_resources/{resource_id}")

    def get_recommendations(self, *, type_filter: str | None = None) -> dict:
        """All optimization recommendations (idle, rightsizing, orphan disks, etc.)."""
        params = {"type": type_filter} if type_filter else None
        return self._request(
            "GET", f"/restapi/v2/organizations/{self._org()}/optimizations",
            params=params,
        )

    def get_anomalies(self, *, last_n_days: int = 30) -> dict:
        """Cost anomalies the OptScale anomaly detector has flagged."""
        end = datetime.now(timezone.utc)
        start = end - timedelta(days=last_n_days)
        return self._request(
            "GET", f"/restapi/v2/organizations/{self._org()}/anomalies",
            params={"start_date": _ts(start), "end_date": _ts(end)},
        )

    def compare_periods(self, period_a: tuple[str, str], period_b: tuple[str, str],
                        group_by: str = "service_name") -> dict:
        """Diff costs between two periods. Useful for 'why did costs spike?'."""
        a = self.get_costs_breakdown(period_a[0], period_a[1], group_by)
        b = self.get_costs_breakdown(period_b[0], period_b[1], group_by)
        return {"period_a": a, "period_b": b}


def _ts(d) -> int:
    """OptScale uses Unix timestamps in seconds for date params."""
    if isinstance(d, datetime):
        return int(d.timestamp())
    if isinstance(d, str):
        try:
            return int(datetime.fromisoformat(d).replace(tzinfo=timezone.utc).timestamp())
        except ValueError:
            return int(datetime.strptime(d, "%Y-%m-%d").replace(tzinfo=timezone.utc).timestamp())
    raise TypeError(f"bad date: {d!r}")
