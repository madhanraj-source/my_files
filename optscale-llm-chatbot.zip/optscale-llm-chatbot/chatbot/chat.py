"""
Chat session with multi-turn tool use.

Loop:
  1. Send messages + tool catalog to the LLM
  2. If LLM returns tool_calls, execute them via tools.dispatch, append results, loop
  3. If LLM returns final text, return it to the user
  4. Persist the full conversation between user turns so follow-ups work

The system prompt is the most important piece of prompt engineering here:
it tells the LLM how to be a good FinOps assistant and — crucially — that
it must not invent numbers.
"""
from __future__ import annotations

from datetime import datetime, timezone

from . import tools as tool_module
from .llm import LLMBackend
from .optscale_client import OptScaleClient


SYSTEM_PROMPT = """You are a FinOps assistant connected to a self-hosted
OptScale instance via tools. The user will ask questions about cloud cost,
waste, anomalies, and resources. Your job is to answer accurately by calling
the right tools and summarizing what they return.

RULES:
- Never fabricate numbers, resource IDs, dates, or services. Use ONLY tool output.
- If a question needs data you don't have, call a tool to fetch it — don't guess.
- Resolve relative dates ("last week", "yesterday", "this month") yourself.
  Call the `today` tool if you need the current date.
- For "why did costs spike?" type questions, use `get_anomalies` first, then
  `compare_periods` to diff the suspect window against a baseline, then
  `list_resources` or `get_resource_details` to drill in.
- Keep answers concise. Lead with the headline number or finding, then 2-3
  bullets of detail. If a chart would help, describe it briefly in words.
- If a tool returns an error, tell the user plainly — don't pretend it worked.
- USD unless told otherwise.
"""

MAX_TOOL_ITERATIONS = 8   # safety cap so the LLM can't loop forever


class ChatSession:
    def __init__(self, llm: LLMBackend, optscale: OptScaleClient,
                 system_prompt: str = SYSTEM_PROMPT, verbose: bool = False):
        self.llm = llm
        self.optscale = optscale
        self.system_prompt = system_prompt
        self.verbose = verbose
        self.messages: list[dict] = []

    def ask(self, user_message: str) -> str:
        self.messages.append({"role": "user", "content": user_message})

        for iteration in range(MAX_TOOL_ITERATIONS):
            resp = self.llm.chat(self.system_prompt, self.messages)
            self.llm.append_assistant_turn(self.messages, resp)

            if not resp.tool_calls:
                # Final answer.
                return resp.text or "(no response)"

            results = []
            for call in resp.tool_calls:
                if self.verbose:
                    print(f"  → {call.name}({_short(call.arguments)})")
                result = tool_module.dispatch(self.optscale, call.name, call.arguments)
                if self.verbose:
                    print(f"    ← {_short(result)}")
                results.append((call, result))

            self.llm.append_tool_results(self.messages, results)

        return ("Reached the tool-call iteration limit without a final answer. "
                "Try rephrasing the question.")

    def reset(self) -> None:
        self.messages.clear()


def _short(obj) -> str:
    s = str(obj)
    return s if len(s) <= 120 else s[:117] + "..."
