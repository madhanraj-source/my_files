"""
LLM clients with tool/function calling. Hosted APIs only — pluggable.

Backends:
  - Anthropic Claude (Messages API + tool_use blocks)
  - OpenAI / OpenAI-compatible (Together, Groq, OpenRouter, Fireworks, DeepInfra,
    OpenAI itself, self-hosted vLLM with --enable-tool-call-parser)

Each backend exposes the same call surface so chat.py is backend-agnostic.
"""
from __future__ import annotations

import json
import os
import urllib.request
import urllib.error
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any

from . import tools as tool_module


@dataclass
class ToolCall:
    id: str
    name: str
    arguments: dict


@dataclass
class LLMResponse:
    text: str                # any natural-language text the model produced
    tool_calls: list[ToolCall]
    raw: dict                # full response (needed to round-trip tool results)


class LLMBackend(ABC):
    @abstractmethod
    def chat(self, system: str, messages: list[dict], *,
             temperature: float = 0.2, max_tokens: int = 2000) -> LLMResponse: ...

    @abstractmethod
    def append_assistant_turn(self, messages: list[dict], resp: LLMResponse) -> None:
        """Add the model's reply to the message history in the right shape."""

    @abstractmethod
    def append_tool_results(self, messages: list[dict],
                            results: list[tuple[ToolCall, Any]]) -> None:
        """Add tool results to the message history in the right shape."""


# ---- Anthropic --------------------------------------------------------------

class AnthropicBackend(LLMBackend):
    def __init__(self, model: str = "claude-sonnet-4-6", api_key: str | None = None):
        self.model = model
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not self.api_key:
            raise RuntimeError("ANTHROPIC_API_KEY not set")
        self.tools = tool_module.for_anthropic()

    def chat(self, system, messages, *, temperature=0.2, max_tokens=2000):
        payload = {
            "model": self.model, "system": system, "messages": messages,
            "tools": self.tools, "max_tokens": max_tokens, "temperature": temperature,
        }
        req = urllib.request.Request(
            "https://api.anthropic.com/v1/messages",
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json",
                     "x-api-key": self.api_key,
                     "anthropic-version": "2023-06-01"},
        )
        with urllib.request.urlopen(req, timeout=300) as r:
            data = json.loads(r.read().decode())

        text_parts, calls = [], []
        for block in data.get("content", []):
            if block.get("type") == "text":
                text_parts.append(block["text"])
            elif block.get("type") == "tool_use":
                calls.append(ToolCall(id=block["id"], name=block["name"],
                                      arguments=block.get("input", {})))
        return LLMResponse(text="\n".join(text_parts), tool_calls=calls, raw=data)

    def append_assistant_turn(self, messages, resp):
        # Anthropic wants the full assistant content (text + tool_use) preserved.
        messages.append({"role": "assistant", "content": resp.raw.get("content", [])})

    def append_tool_results(self, messages, results):
        content = [
            {"type": "tool_result", "tool_use_id": call.id,
             "content": tool_module.truncate_for_llm(result)}
            for call, result in results
        ]
        messages.append({"role": "user", "content": content})


# ---- OpenAI / OpenAI-compatible --------------------------------------------

class OpenAICompatBackend(LLMBackend):
    def __init__(self, model: str, base_url: str = "https://api.openai.com/v1",
                 api_key: str | None = None):
        self.model = model
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key or os.environ.get("OPENAI_API_KEY") or os.environ.get("LLM_API_KEY")
        if not self.api_key:
            raise RuntimeError("OPENAI_API_KEY (or LLM_API_KEY) not set")
        self.tools = tool_module.for_openai()

    def chat(self, system, messages, *, temperature=0.2, max_tokens=2000):
        # OpenAI puts the system message in the messages array
        full = [{"role": "system", "content": system}] + messages
        payload = {
            "model": self.model, "messages": full, "tools": self.tools,
            "temperature": temperature, "max_tokens": max_tokens,
        }
        req = urllib.request.Request(
            f"{self.base_url}/chat/completions",
            data=json.dumps(payload).encode(),
            headers={"Content-Type": "application/json",
                     "Authorization": f"Bearer {self.api_key}"},
        )
        with urllib.request.urlopen(req, timeout=300) as r:
            data = json.loads(r.read().decode())

        msg = data["choices"][0]["message"]
        calls = []
        for tc in msg.get("tool_calls") or []:
            calls.append(ToolCall(
                id=tc["id"], name=tc["function"]["name"],
                arguments=json.loads(tc["function"]["arguments"] or "{}"),
            ))
        return LLMResponse(text=msg.get("content") or "", tool_calls=calls, raw=msg)

    def append_assistant_turn(self, messages, resp):
        turn: dict = {"role": "assistant", "content": resp.text or None}
        if resp.tool_calls:
            turn["tool_calls"] = [
                {"id": c.id, "type": "function",
                 "function": {"name": c.name, "arguments": json.dumps(c.arguments)}}
                for c in resp.tool_calls
            ]
        messages.append(turn)

    def append_tool_results(self, messages, results):
        for call, result in results:
            messages.append({
                "role": "tool", "tool_call_id": call.id,
                "content": tool_module.truncate_for_llm(result),
            })


# ---- factory ----------------------------------------------------------------

def build_backend(cfg: dict) -> LLMBackend:
    """
    cfg examples:
      {'backend': 'anthropic', 'model': 'claude-sonnet-4-6'}
      {'backend': 'openai',    'model': 'gpt-4o-mini'}
      {'backend': 'openai_compatible', 'model': '...', 'base_url': '...', 'api_key': '...'}
    """
    kind = (cfg.get("backend") or "anthropic").lower()
    if kind == "anthropic":
        return AnthropicBackend(model=cfg.get("model", "claude-sonnet-4-6"),
                                api_key=cfg.get("api_key"))
    if kind in ("openai", "openai_compatible"):
        return OpenAICompatBackend(
            model=cfg["model"],
            base_url=cfg.get("base_url", "https://api.openai.com/v1"),
            api_key=cfg.get("api_key"),
        )
    raise ValueError(f"unknown LLM backend: {kind}")
