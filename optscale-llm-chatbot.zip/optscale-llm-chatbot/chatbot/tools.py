"""
Tool catalog for LLM function calling.

Each tool has:
  - A canonical schema (works for both Anthropic and OpenAI shapes)
  - A handler that dispatches to OptScaleClient

The LLM sees descriptions like a human would — that's how it knows when to call
which tool. Be descriptive in the `description` fields; that's the prompt
engineering surface for tool use.
"""
from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from typing import Any

from .optscale_client import OptScaleClient, OptScaleError


# ---- canonical tool catalog -------------------------------------------------

TOOLS = [
    {
        "name": "get_cost_summary",
        "description": (
            "Get the total cloud cost (in USD) for the organization over a date range. "
            "Use this when the user asks 'what did we spend last week/month' or wants a headline figure. "
            "Dates are YYYY-MM-DD. If the user says 'last 7 days', compute the dates yourself."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "start_date": {"type": "string", "description": "Start date, YYYY-MM-DD"},
                "end_date": {"type": "string", "description": "End date, YYYY-MM-DD"},
            },
            "required": ["start_date", "end_date"],
        },
    },
    {
        "name": "get_costs_breakdown",
        "description": (
            "Break costs down by a dimension over a date range. Use this for "
            "'cost by service', 'cost by region', 'where is the money going'. "
            "group_by must be one of: service_name, cloud_account_id, region, resource_type, pool_id."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "start_date": {"type": "string"},
                "end_date": {"type": "string"},
                "group_by": {
                    "type": "string",
                    "enum": ["service_name", "cloud_account_id", "region", "resource_type", "pool_id"],
                },
            },
            "required": ["start_date", "end_date", "group_by"],
        },
    },
    {
        "name": "compare_periods",
        "description": (
            "Compare costs between two date ranges, grouped by a dimension. "
            "ESSENTIAL for 'why did costs spike?' / 'what changed?' questions. "
            "Returns both periods so you can compute the diff."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "period_a_start": {"type": "string"},
                "period_a_end": {"type": "string"},
                "period_b_start": {"type": "string"},
                "period_b_end": {"type": "string"},
                "group_by": {
                    "type": "string",
                    "enum": ["service_name", "cloud_account_id", "region", "resource_type", "pool_id"],
                },
            },
            "required": ["period_a_start", "period_a_end", "period_b_start", "period_b_end", "group_by"],
        },
    },
    {
        "name": "list_resources",
        "description": (
            "List cloud resources, optionally filtered. Use this when the user asks "
            "'what's running in region X', 'show me all S3 buckets', or wants to see "
            "specific resources after spotting a spike. limit defaults to 50."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "active": {"type": "boolean", "description": "Only active (running) resources"},
                "cloud_type": {"type": "string", "description": "aws|azure|gcp|alibaba|kubernetes"},
                "service_name": {"type": "string", "description": "e.g. 'AmazonEC2', 'AmazonS3'"},
                "region": {"type": "string"},
                "limit": {"type": "integer", "default": 50},
            },
        },
    },
    {
        "name": "get_resource_details",
        "description": "Get full detail for one specific resource by ID. Use after list_resources spots something interesting.",
        "parameters": {
            "type": "object",
            "properties": {"resource_id": {"type": "string"}},
            "required": ["resource_id"],
        },
    },
    {
        "name": "get_recommendations",
        "description": (
            "Get OptScale's optimization recommendations (idle VMs, rightsizing, orphan disks, "
            "old snapshots, etc.). Use when the user asks 'how can we save', 'what should we cut', "
            "'where are we wasting money'."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "type_filter": {
                    "type": "string",
                    "description": "Optional filter, e.g. 'rightsizing', 'idle', 'abandoned'",
                },
            },
        },
    },
    {
        "name": "get_anomalies",
        "description": (
            "Get the cost anomalies OptScale's detector has flagged. Use this FIRST when the user "
            "says 'why is my bill high', 'something looks wrong', 'investigate spike'."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "last_n_days": {"type": "integer", "default": 30},
            },
        },
    },
    {
        "name": "today",
        "description": "Get today's date in YYYY-MM-DD (UTC). Use to resolve 'last week', 'this month', etc.",
        "parameters": {"type": "object", "properties": {}},
    },
]


# ---- dispatcher -------------------------------------------------------------

def dispatch(client: OptScaleClient, name: str, args: dict) -> Any:
    try:
        if name == "get_cost_summary":
            return client.get_cost_summary(args["start_date"], args["end_date"])
        if name == "get_costs_breakdown":
            return client.get_costs_breakdown(args["start_date"], args["end_date"],
                                              args.get("group_by", "service_name"))
        if name == "compare_periods":
            return client.compare_periods(
                (args["period_a_start"], args["period_a_end"]),
                (args["period_b_start"], args["period_b_end"]),
                args.get("group_by", "service_name"),
            )
        if name == "list_resources":
            return client.get_resources(**{k: v for k, v in args.items() if v is not None})
        if name == "get_resource_details":
            return client.get_resource_details(args["resource_id"])
        if name == "get_recommendations":
            return client.get_recommendations(type_filter=args.get("type_filter"))
        if name == "get_anomalies":
            return client.get_anomalies(last_n_days=args.get("last_n_days", 30))
        if name == "today":
            return {"today": datetime.now(timezone.utc).strftime("%Y-%m-%d")}
        return {"error": f"unknown tool: {name}"}
    except OptScaleError as e:
        return {"error": str(e)}


# ---- backend-specific schema converters -------------------------------------

def for_anthropic() -> list[dict]:
    """Anthropic Messages API tool format."""
    return [
        {"name": t["name"], "description": t["description"], "input_schema": t["parameters"]}
        for t in TOOLS
    ]


def for_openai() -> list[dict]:
    """OpenAI / OpenAI-compatible function calling format."""
    return [
        {"type": "function", "function": {
            "name": t["name"], "description": t["description"], "parameters": t["parameters"]
        }}
        for t in TOOLS
    ]


def truncate_for_llm(data: Any, max_chars: int = 8000) -> str:
    """Serialize tool output and clip if huge — protects context window."""
    s = json.dumps(data, default=str)
    if len(s) <= max_chars:
        return s
    return s[:max_chars] + f"\n…[truncated, total {len(s)} chars]"
