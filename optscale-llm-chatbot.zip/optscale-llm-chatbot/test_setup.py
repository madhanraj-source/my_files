#!/usr/bin/env python3
"""
Pre-flight check: verify that OptScale is reachable and the LLM API works
BEFORE you start chatting. Run this after editing config.yaml.

  python test_setup.py --config config.yaml
"""
from __future__ import annotations

import argparse
import sys
from pathlib import Path

from chatbot import OptScaleClient, build_backend
from chatbot.tools import dispatch


def load_config(path: str) -> dict:
    import json
    text = Path(path).read_text()
    try:
        import yaml
        return yaml.safe_load(text)
    except ImportError:
        return json.loads(text)


def check(name: str, fn):
    print(f"  [{name}] ... ", end="", flush=True)
    try:
        msg = fn()
        print(f"OK  {msg or ''}")
        return True
    except Exception as e:
        print(f"FAIL\n        → {e}")
        return False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yaml")
    args = ap.parse_args()

    cfg = load_config(args.config)
    all_ok = True

    print("\n== OptScale ==")
    os_cfg = cfg["optscale"]
    client = OptScaleClient(
        base_url=os_cfg["base_url"],
        email=os_cfg["email"],
        password=os_cfg["password"],
        organization_id=os_cfg.get("organization_id"),
    )
    all_ok &= check("auth", lambda: f"token acquired" if client._get_token() else "no token")
    all_ok &= check("list_orgs", lambda: f"{len(client.list_organizations())} org(s)")
    all_ok &= check("today tool", lambda: dispatch(client, "today", {})["today"])

    print("\n== LLM ==")
    llm = build_backend(cfg["llm"])
    def llm_ping():
        resp = llm.chat(
            "You are a test assistant. Reply with one word only.",
            [{"role": "user", "content": "say PONG"}],
            max_tokens=20,
        )
        return f"backend={cfg['llm']['backend']}, reply={(resp.text or '').strip()[:40]!r}"
    all_ok &= check("chat", llm_ping)

    print()
    if all_ok:
        print("All checks passed. You're ready: `python main.py --config config.yaml`")
        sys.exit(0)
    else:
        print("Some checks failed. Fix the errors above before running the chatbot.")
        sys.exit(1)


if __name__ == "__main__":
    main()
