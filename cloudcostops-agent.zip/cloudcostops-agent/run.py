#!/usr/bin/env python3
# run.py — Quick start script for CloudCostOps Agent
# Usage: python run.py [--clouds aws azure] [--days 7] [--no-llm]

import argparse
import json
import sys
import os
from dotenv import load_dotenv

load_dotenv()


def main():
    parser = argparse.ArgumentParser(description="CloudCostOps Agent — AI-powered cloud cost optimization")
    parser.add_argument("--clouds", nargs="+", choices=["aws", "azure", "gcp"],
                        help="Clouds to scan (default: auto-detect from .env)")
    parser.add_argument("--days", type=int, default=7,
                        help="Days of historical data to analyze (default: 7)")
    parser.add_argument("--idle-only", action="store_true",
                        help="Only detect idle resources (faster, no LLM)")
    parser.add_argument("--no-slack", action="store_true",
                        help="Skip Slack notifications")

    args = parser.parse_args()

    if args.no_slack:
        os.environ["SLACK_WEBHOOK_URL"] = ""

    print("\n" + "="*60)
    print("  ☁️  CloudCostOps Agent v1.0")
    print("  AI-Powered Multi-Cloud Cost Optimization")
    print("="*60 + "\n")

    if args.idle_only:
        _run_idle_only(args.clouds)
    else:
        _run_full_agent(args.clouds, args.days)


def _run_idle_only(clouds):
    """Quick idle resource detection without full agent"""
    from collector.aws_collector import detect_idle_ec2_instances, detect_unattached_volumes
    from collector.azure_collector import detect_idle_azure_vms, detect_unattached_azure_disks

    print("🔍 Running idle resource detection...\n")
    all_idle = []
    all_storage = []

    clouds = clouds or _detect_clouds()

    if "aws" in clouds:
        all_idle.extend(detect_idle_ec2_instances())
        all_storage.extend(detect_unattached_volumes())

    if "azure" in clouds:
        all_idle.extend(detect_idle_azure_vms())
        all_storage.extend(detect_unattached_azure_disks())

    total_saving = sum(r.get("estimated_monthly_saving_usd", 0) for r in all_idle + all_storage)

    print(f"\n{'='*50}")
    print(f"  Results: {len(all_idle)} idle compute + {len(all_storage)} unattached storage")
    print(f"  Estimated monthly saving: ${total_saving:,.2f}")
    print(f"{'='*50}\n")

    if all_idle:
        print("IDLE COMPUTE RESOURCES:")
        for r in all_idle[:10]:
            print(f"  ⚠️  [{r['cloud'].upper()}] {r['resource_name']} — {r.get('avg_cpu_percent', 0):.1f}% CPU avg — ${r.get('estimated_monthly_saving_usd', 0):.0f}/mo saving")

    if all_storage:
        print("\nUNATTACHED STORAGE:")
        for r in all_storage[:10]:
            print(f"  💾 [{r['cloud'].upper()}] {r['resource_name']} — {r.get('size_gb', 0)}GB — ${r.get('estimated_monthly_saving_usd', 0):.0f}/mo saving")


def _run_full_agent(clouds, days):
    """Run full LangGraph agent"""
    from agent.graph import run_agent

    result = run_agent(clouds=clouds, days=days)

    # Print summary
    cost_summary = result.get("cost_summary", {})
    recommendations = result.get("llm_recommendations", {})
    errors = result.get("errors", [])

    print(f"\n{'='*60}")
    print("  CLOUDCOSTOPS AGENT — RESULTS SUMMARY")
    print(f"{'='*60}")
    print(f"  Total Cloud Spend:     ${cost_summary.get('total_cost_usd', 0):,.2f}")
    print(f"  Idle Resources Found:  {len(result.get('idle_resources', []))}")
    print(f"  Storage Waste Found:   {len(result.get('unattached_storage', []))}")
    print(f"  Saving Potential:      ${recommendations.get('total_potential_saving_usd', 0):,.2f}/month")
    print(f"  Auto-actions Logged:   {len(result.get('actions_taken', []))}")
    print(f"  Slack Notified:        {result.get('notifications_sent', False)}")

    if errors:
        print(f"\n  ⚠️  Errors ({len(errors)}):")
        for e in errors:
            print(f"    - {e}")

    summary = recommendations.get("summary")
    if summary:
        print(f"\n  🤖 AI Summary: {summary}")

    quick_wins = recommendations.get("quick_wins", [])
    if quick_wins:
        print(f"\n  ⚡ Quick Wins:")
        for w in quick_wins[:3]:
            print(f"    • {w}")

    print(f"\n{'='*60}\n")


def _detect_clouds():
    clouds = []
    if os.getenv("AWS_ACCESS_KEY_ID"):
        clouds.append("aws")
    if os.getenv("AZURE_SUBSCRIPTION_ID"):
        clouds.append("azure")
    if os.getenv("GCP_PROJECT_ID"):
        clouds.append("gcp")
    return clouds or ["aws"]


if __name__ == "__main__":
    main()
