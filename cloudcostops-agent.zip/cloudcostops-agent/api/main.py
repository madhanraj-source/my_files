# api/main.py
# FastAPI application — REST API for CloudCostOps Agent

import os
import json
from datetime import datetime
from typing import List, Optional
from fastapi import FastAPI, BackgroundTasks, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dotenv import load_dotenv

load_dotenv()

app = FastAPI(
    title="CloudCostOps Agent API",
    description="AI-powered cloud cost optimization agent — AWS, Azure, GCP",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"]
)

# ─── In-memory run history (replace with DB in production) ────────────────────
run_history = []


# ─── Request/Response Models ──────────────────────────────────────────────────

class ScanRequest(BaseModel):
    clouds: Optional[List[str]] = None   # ["aws", "azure", "gcp"]
    days: Optional[int] = 7
    notify_slack: Optional[bool] = True


class ScanResponse(BaseModel):
    run_id: str
    status: str
    message: str
    started_at: str


# ─── Background Task ─────────────────────────────────────────────────────────

def run_agent_background(request: ScanRequest, run_id: str):
    """Execute agent in background"""
    from agent.graph import run_agent

    try:
        result = run_agent(
            clouds=request.clouds,
            days=request.days
        )

        run_history.append({
            "run_id": run_id,
            "status": "completed",
            "clouds": request.clouds or result.get("clouds"),
            "total_cost_usd": result.get("cost_summary", {}).get("total_cost_usd", 0),
            "saving_potential_usd": result.get("llm_recommendations", {}).get("total_potential_saving_usd", 0),
            "idle_resources": len(result.get("idle_resources", [])),
            "actions_taken": len(result.get("actions_taken", [])),
            "errors": result.get("errors", []),
            "completed_at": datetime.utcnow().isoformat()
        })

    except Exception as e:
        print(f"[API] Agent run failed: {e}")
        run_history.append({
            "run_id": run_id,
            "status": "failed",
            "error": str(e),
            "completed_at": datetime.utcnow().isoformat()
        })


# ─── API Endpoints ────────────────────────────────────────────────────────────

@app.get("/")
def root():
    return {
        "service": "CloudCostOps Agent",
        "version": "1.0.0",
        "status": "running",
        "docs": "/docs"
    }


@app.get("/health")
def health():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "timestamp": datetime.utcnow().isoformat(),
        "llm_mode": "local" if os.getenv("USE_LOCAL_LLM", "true") == "true" else "hosted",
        "llm_provider": os.getenv("LLM_PROVIDER", "anthropic"),
        "configured_clouds": _get_configured_clouds()
    }


@app.post("/scan", response_model=ScanResponse)
def trigger_scan(request: ScanRequest, background_tasks: BackgroundTasks):
    """
    Trigger a cost optimization scan.
    Runs asynchronously — check /runs/{run_id} for results.
    """
    import uuid
    run_id = str(uuid.uuid4())[:8]

    background_tasks.add_task(run_agent_background, request, run_id)

    return ScanResponse(
        run_id=run_id,
        status="started",
        message=f"Scan started for clouds: {request.clouds or _get_configured_clouds()}",
        started_at=datetime.utcnow().isoformat()
    )


@app.post("/scan/sync")
def trigger_scan_sync(request: ScanRequest):
    """
    Trigger a synchronous cost optimization scan.
    Waits for completion — use for testing or small scans.
    """
    from agent.graph import run_agent
    import uuid

    run_id = str(uuid.uuid4())[:8]

    try:
        result = run_agent(
            clouds=request.clouds,
            days=request.days
        )

        return {
            "run_id": run_id,
            "status": "completed",
            "clouds": result.get("clouds"),
            "cost_summary": result.get("cost_summary"),
            "idle_resources_count": len(result.get("idle_resources", [])),
            "recommendations": result.get("llm_recommendations"),
            "actions_taken": result.get("actions_taken"),
            "errors": result.get("errors", [])
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/runs")
def list_runs():
    """List all agent run history"""
    return {
        "runs": sorted(run_history, key=lambda x: x.get("completed_at", ""), reverse=True),
        "total": len(run_history)
    }


@app.get("/runs/{run_id}")
def get_run(run_id: str):
    """Get results of a specific run"""
    for run in run_history:
        if run.get("run_id") == run_id:
            return run
    raise HTTPException(status_code=404, detail=f"Run {run_id} not found")


@app.get("/idle-resources")
def get_idle_resources(cloud: Optional[str] = Query(None, description="Filter by cloud: aws|azure|gcp")):
    """
    Run idle resource detection only (faster than full scan)
    """
    idle = []
    storage = []

    if not cloud or cloud == "aws":
        try:
            from collector.aws_collector import detect_idle_ec2_instances, detect_unattached_volumes
            idle.extend(detect_idle_ec2_instances())
            storage.extend(detect_unattached_volumes())
        except Exception as e:
            print(f"[API] AWS idle detection error: {e}")

    if not cloud or cloud == "azure":
        try:
            from collector.azure_collector import detect_idle_azure_vms, detect_unattached_azure_disks
            idle.extend(detect_idle_azure_vms())
            storage.extend(detect_unattached_azure_disks())
        except Exception as e:
            print(f"[API] Azure idle detection error: {e}")

    total_saving = sum(r.get("estimated_monthly_saving_usd", 0) for r in idle + storage)

    return {
        "idle_compute": idle,
        "unattached_storage": storage,
        "total_resources": len(idle) + len(storage),
        "estimated_monthly_saving_usd": round(total_saving, 2)
    }


@app.get("/recommendations/history")
def get_recommendation_history(days: int = Query(30)):
    """Get recommendation history from vector memory"""
    try:
        from agent.memory import get_recommendation_history
        history = get_recommendation_history(days)
        return {"history": history, "days": days}
    except Exception as e:
        return {"history": [], "error": str(e)}


# ─── Helpers ──────────────────────────────────────────────────────────────────

def _get_configured_clouds() -> List[str]:
    clouds = []
    if os.getenv("AWS_ACCESS_KEY_ID"):
        clouds.append("aws")
    if os.getenv("AZURE_SUBSCRIPTION_ID"):
        clouds.append("azure")
    if os.getenv("GCP_PROJECT_ID"):
        clouds.append("gcp")
    return clouds or ["aws"]


# ─── Entry Point ──────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("api.main:app", host="0.0.0.0", port=8000, reload=True)
