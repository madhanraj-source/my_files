# collector/azure_collector.py
# Collects cost and usage data from Azure Cost Management API

import os
from datetime import datetime, timedelta
from typing import List
from collector.normalizer import NormalizedCostRecord, normalize_azure


def get_azure_credentials():
    """Get Azure credentials from environment"""
    try:
        from azure.identity import ClientSecretCredential
        return ClientSecretCredential(
            tenant_id=os.getenv("AZURE_TENANT_ID"),
            client_id=os.getenv("AZURE_CLIENT_ID"),
            client_secret=os.getenv("AZURE_CLIENT_SECRET")
        )
    except Exception as e:
        print(f"[Azure] Credential error: {e}")
        return None


def collect_azure_costs(days: int = 7) -> List[NormalizedCostRecord]:
    """
    Collect Azure costs for the last N days via Cost Management API
    Returns normalized cost records
    """
    try:
        from azure.mgmt.costmanagement import CostManagementClient
        from azure.mgmt.costmanagement.models import (
            QueryDefinition, QueryTimePeriod,
            QueryDataset, QueryAggregation,
            QueryGrouping, TimeframeType
        )

        credential = get_azure_credentials()
        if not credential:
            return []

        subscription_id = os.getenv("AZURE_SUBSCRIPTION_ID")
        client = CostManagementClient(credential)

        end_date = datetime.utcnow()
        start_date = end_date - timedelta(days=days)

        scope = f"/subscriptions/{subscription_id}"

        query = QueryDefinition(
            type="ActualCost",
            timeframe=TimeframeType.CUSTOM,
            time_period=QueryTimePeriod(
                from_property=start_date,
                to=end_date
            ),
            dataset=QueryDataset(
                granularity="Daily",
                aggregation={
                    "totalCost": QueryAggregation(
                        name="PreTaxCost",
                        function="Sum"
                    )
                },
                grouping=[
                    QueryGrouping(type="Dimension", name="ServiceName"),
                    QueryGrouping(type="Dimension", name="ResourceLocation"),
                    QueryGrouping(type="Dimension", name="ResourceId")
                ]
            )
        )

        result = client.query.usage(scope, query)
        records = []

        if result and result.rows:
            for row in result.rows:
                raw = {
                    "pretaxCost": row[0] if len(row) > 0 else 0,
                    "date": str(row[1]) if len(row) > 1 else "",
                    "serviceName": row[2] if len(row) > 2 else "Unknown",
                    "resourceLocation": row[3] if len(row) > 3 else "unknown",
                    "resourceId": row[4] if len(row) > 4 else "unknown",
                    "subscriptionId": subscription_id
                }
                records.append(normalize_azure(raw))

        print(f"[Azure] Collected {len(records)} cost records")
        return records

    except Exception as e:
        print(f"[Azure] Cost collection failed: {e}")
        return []


def detect_idle_azure_vms(threshold_cpu: float = 5.0, days: int = 7) -> List[dict]:
    """Find Azure VMs with low average CPU utilization"""
    try:
        from azure.mgmt.compute import ComputeManagementClient
        from azure.mgmt.monitor import MonitorManagementClient

        credential = get_azure_credentials()
        if not credential:
            return []

        subscription_id = os.getenv("AZURE_SUBSCRIPTION_ID")
        compute_client = ComputeManagementClient(credential, subscription_id)
        monitor_client = MonitorManagementClient(credential, subscription_id)

        idle = []
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(days=days)

        for vm in compute_client.virtual_machines.list_all():
            if vm.provisioning_state != "Succeeded":
                continue

            try:
                metrics = monitor_client.metrics.list(
                    resource_uri=vm.id,
                    timespan=f"{start_time.isoformat()}/{end_time.isoformat()}",
                    interval="P1D",
                    metricnames="Percentage CPU",
                    aggregation="Average"
                )

                cpu_values = []
                for metric in metrics.value:
                    for ts in metric.timeseries:
                        for dp in ts.data:
                            if dp.average is not None:
                                cpu_values.append(dp.average)

                avg_cpu = sum(cpu_values) / len(cpu_values) if cpu_values else 0.0

                if avg_cpu < threshold_cpu:
                    idle.append({
                        "cloud": "azure",
                        "resource_id": vm.id,
                        "resource_name": vm.name,
                        "vm_size": vm.hardware_profile.vm_size if vm.hardware_profile else "unknown",
                        "location": vm.location,
                        "avg_cpu_percent": round(avg_cpu, 2),
                        "days_checked": days,
                        "tags": vm.tags or {},
                        "recommendation": f"VM idle ({avg_cpu:.1f}% avg CPU). Consider deallocating or resizing.",
                        "estimated_monthly_saving_usd": 50.0  # Placeholder
                    })

            except Exception as metric_err:
                print(f"[Azure] Metrics fetch failed for {vm.name}: {metric_err}")

        print(f"[Azure] Found {len(idle)} idle VMs")
        return idle

    except Exception as e:
        print(f"[Azure] VM idle detection failed: {e}")
        return []


def detect_unattached_azure_disks() -> List[dict]:
    """Find Azure managed disks not attached to any VM"""
    try:
        from azure.mgmt.compute import ComputeManagementClient

        credential = get_azure_credentials()
        if not credential:
            return []

        subscription_id = os.getenv("AZURE_SUBSCRIPTION_ID")
        compute_client = ComputeManagementClient(credential, subscription_id)

        unattached = []
        for disk in compute_client.disks.list():
            if disk.disk_state == "Unattached":
                size_gb = disk.disk_size_gb or 0
                unattached.append({
                    "cloud": "azure",
                    "resource_id": disk.id,
                    "resource_name": disk.name,
                    "disk_sku": disk.sku.name if disk.sku else "unknown",
                    "size_gb": size_gb,
                    "location": disk.location,
                    "tags": disk.tags or {},
                    "recommendation": f"Unattached disk ({size_gb}GB). Delete or snapshot.",
                    "estimated_monthly_saving_usd": round(size_gb * 0.095, 2)
                })

        print(f"[Azure] Found {len(unattached)} unattached disks")
        return unattached

    except Exception as e:
        print(f"[Azure] Disk scan failed: {e}")
        return []
