# collector/normalizer.py
# Unified cost record schema — cloud-agnostic normalization layer

from dataclasses import dataclass, field, asdict
from typing import List, Optional
from datetime import datetime
import json


@dataclass
class NormalizedCostRecord:
    """Universal cost record — works for AWS, Azure, GCP"""
    cloud: str              # aws | azure | gcp
    service: str            # EC2 | AKS | GCE | S3 etc.
    resource_id: str
    resource_name: str
    region: str
    cost_usd: float
    usage_hours: float
    currency: str = "USD"
    tags: dict = field(default_factory=dict)
    date: str = ""
    account_id: str = ""
    resource_type: str = ""
    is_idle: bool = False
    idle_reason: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), indent=2)


def normalize_aws(raw: dict) -> NormalizedCostRecord:
    """Normalize AWS Cost Explorer API response"""
    groups = raw.get("Groups", [{}])
    cost_amount = 0.0
    usage_amount = 0.0

    if groups:
        metrics = groups[0].get("Metrics", {})
        cost_amount = float(metrics.get("BlendedCost", {}).get("Amount", 0))
        usage_amount = float(metrics.get("UsageQuantity", {}).get("Amount", 0))

    return NormalizedCostRecord(
        cloud="aws",
        service=raw.get("Service", "Unknown"),
        resource_id=raw.get("ResourceId", "unknown"),
        resource_name=raw.get("ResourceName", raw.get("ResourceId", "unknown")),
        region=raw.get("Region", "unknown"),
        cost_usd=round(cost_amount, 4),
        usage_hours=round(usage_amount, 2),
        tags=raw.get("Tags", {}),
        date=raw.get("TimePeriod", {}).get("Start", ""),
        account_id=raw.get("AccountId", ""),
        resource_type=raw.get("InstanceType", raw.get("ResourceType", ""))
    )


def normalize_azure(raw: dict) -> NormalizedCostRecord:
    """Normalize Azure Cost Management API response"""
    return NormalizedCostRecord(
        cloud="azure",
        service=raw.get("meterCategory", raw.get("serviceName", "Unknown")),
        resource_id=raw.get("resourceId", "unknown"),
        resource_name=raw.get("resourceName", "unknown"),
        region=raw.get("resourceLocation", raw.get("location", "unknown")),
        cost_usd=round(float(raw.get("pretaxCost", raw.get("cost", 0))), 4),
        usage_hours=round(float(raw.get("quantity", 0)), 2),
        tags=raw.get("tags", {}),
        date=raw.get("date", raw.get("usageStart", "")),
        account_id=raw.get("subscriptionId", ""),
        resource_type=raw.get("meterName", raw.get("skuName", ""))
    )


def normalize_gcp(raw: dict) -> NormalizedCostRecord:
    """Normalize GCP Billing API response"""
    cost_info = raw.get("cost", {})
    cost_usd = float(cost_info.get("units", 0)) + float(cost_info.get("nanos", 0)) / 1e9

    return NormalizedCostRecord(
        cloud="gcp",
        service=raw.get("service", {}).get("description", "Unknown"),
        resource_id=raw.get("resource", {}).get("name", "unknown"),
        resource_name=raw.get("resource", {}).get("global_name", "unknown"),
        region=raw.get("location", {}).get("region", "unknown"),
        cost_usd=round(cost_usd, 4),
        usage_hours=round(float(raw.get("usage", {}).get("amount", 0)), 2),
        tags=raw.get("labels", {}),
        date=raw.get("usage_start_time", ""),
        account_id=raw.get("billing_account_id", ""),
        resource_type=raw.get("sku", {}).get("description", "")
    )


def aggregate_costs(records: List[NormalizedCostRecord]) -> dict:
    """Aggregate cost records by cloud and service"""
    summary = {}
    total = 0.0

    for r in records:
        key = f"{r.cloud}:{r.service}"
        if key not in summary:
            summary[key] = {
                "cloud": r.cloud,
                "service": r.service,
                "total_cost_usd": 0.0,
                "resource_count": 0,
                "idle_count": 0
            }
        summary[key]["total_cost_usd"] += r.cost_usd
        summary[key]["resource_count"] += 1
        if r.is_idle:
            summary[key]["idle_count"] += 1
        total += r.cost_usd

    return {
        "breakdown": list(summary.values()),
        "total_cost_usd": round(total, 2),
        "record_count": len(records),
        "generated_at": datetime.utcnow().isoformat()
    }
