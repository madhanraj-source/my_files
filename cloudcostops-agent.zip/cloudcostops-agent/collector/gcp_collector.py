# collector/gcp_collector.py
# Collects cost and usage data from GCP Cloud Billing API

import os
from datetime import datetime, timedelta
from typing import List
from collector.normalizer import NormalizedCostRecord, normalize_gcp


def collect_gcp_costs(days: int = 7) -> List[NormalizedCostRecord]:
    """
    Collect GCP costs via BigQuery billing export or Cloud Billing API
    Returns normalized cost records
    """
    try:
        from google.cloud import bigquery

        project_id = os.getenv("GCP_PROJECT_ID")
        billing_dataset = os.getenv("GCP_BILLING_DATASET", "billing_export")
        billing_table = os.getenv("GCP_BILLING_TABLE", "gcp_billing_export_v1")

        client = bigquery.Client(project=project_id)

        end_date = datetime.utcnow().strftime("%Y-%m-%d")
        start_date = (datetime.utcnow() - timedelta(days=days)).strftime("%Y-%m-%d")

        query = f"""
            SELECT
                service.description AS service_description,
                resource.name AS resource_name,
                resource.global_name AS resource_global_name,
                location.region AS region,
                cost,
                usage.amount AS usage_amount,
                usage.unit AS usage_unit,
                labels,
                usage_start_time,
                project.id AS project_id,
                sku.description AS sku_description
            FROM `{project_id}.{billing_dataset}.{billing_table}`
            WHERE DATE(usage_start_time) BETWEEN '{start_date}' AND '{end_date}'
            AND cost > 0
            ORDER BY cost DESC
            LIMIT 1000
        """

        results = client.query(query).result()
        records = []

        for row in results:
            raw = {
                "service": {"description": row.service_description},
                "resource": {
                    "name": row.resource_name or "unknown",
                    "global_name": row.resource_global_name or "unknown"
                },
                "location": {"region": row.region or "unknown"},
                "cost": {"units": int(row.cost), "nanos": int((row.cost % 1) * 1e9)},
                "usage": {"amount": row.usage_amount or 0},
                "labels": {label["key"]: label["value"] for label in (row.labels or [])},
                "usage_start_time": str(row.usage_start_time),
                "billing_account_id": project_id,
                "sku": {"description": row.sku_description or ""}
            }
            records.append(normalize_gcp(raw))

        print(f"[GCP] Collected {len(records)} cost records")
        return records

    except ImportError:
        print("[GCP] google-cloud-bigquery not installed. Install: pip install google-cloud-bigquery")
        return []
    except Exception as e:
        print(f"[GCP] Cost collection failed: {e}")
        return []


def detect_idle_gcp_instances(threshold_cpu: float = 5.0, days: int = 7) -> List[dict]:
    """Find GCP Compute Engine instances with low CPU utilization"""
    try:
        from google.cloud import monitoring_v3
        from google.cloud import compute_v1

        project_id = os.getenv("GCP_PROJECT_ID")
        instance_client = compute_v1.InstancesClient()
        metrics_client = monitoring_v3.MetricServiceClient()

        idle = []
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(days=days)

        # List all instances across all zones
        agg_list = instance_client.aggregated_list(project=project_id)

        for zone, response in agg_list:
            for instance in response.instances:
                if instance.status != "RUNNING":
                    continue

                try:
                    # Query CPU utilization from Cloud Monitoring
                    filter_str = (
                        f'metric.type="compute.googleapis.com/instance/cpu/utilization" '
                        f'AND resource.labels.instance_id="{instance.id}"'
                    )

                    interval = monitoring_v3.TimeInterval(
                        end_time={"seconds": int(end_time.timestamp())},
                        start_time={"seconds": int(start_time.timestamp())}
                    )

                    results = metrics_client.list_time_series(
                        request={
                            "name": f"projects/{project_id}",
                            "filter": filter_str,
                            "interval": interval,
                            "view": monitoring_v3.ListTimeSeriesRequest.TimeSeriesView.FULL
                        }
                    )

                    cpu_values = [
                        point.value.double_value * 100
                        for ts in results
                        for point in ts.points
                    ]

                    avg_cpu = sum(cpu_values) / len(cpu_values) if cpu_values else 0.0

                    if avg_cpu < threshold_cpu:
                        idle.append({
                            "cloud": "gcp",
                            "resource_id": str(instance.id),
                            "resource_name": instance.name,
                            "machine_type": instance.machine_type.split("/")[-1],
                            "zone": zone.replace("zones/", ""),
                            "avg_cpu_percent": round(avg_cpu, 2),
                            "days_checked": days,
                            "tags": dict(instance.labels or {}),
                            "recommendation": f"GCE instance idle ({avg_cpu:.1f}% avg CPU). Consider stopping.",
                            "estimated_monthly_saving_usd": 40.0
                        })

                except Exception as metric_err:
                    print(f"[GCP] Metrics error for {instance.name}: {metric_err}")

        print(f"[GCP] Found {len(idle)} idle GCE instances")
        return idle

    except ImportError:
        print("[GCP] google-cloud-monitoring or google-cloud-compute not installed.")
        return []
    except Exception as e:
        print(f"[GCP] Idle detection failed: {e}")
        return []
