# collector/aws_collector.py
# Collects cost and usage data from AWS Cost Explorer + CloudWatch

import os
import boto3
from datetime import datetime, timedelta
from typing import List, Optional
from collector.normalizer import NormalizedCostRecord, normalize_aws


def get_aws_client(service: str, region: str = None):
    """Create boto3 client using env credentials"""
    region = region or os.getenv("AWS_DEFAULT_REGION", "ap-south-1")
    return boto3.client(
        service,
        region_name=region,
        aws_access_key_id=os.getenv("AWS_ACCESS_KEY_ID"),
        aws_secret_access_key=os.getenv("AWS_SECRET_ACCESS_KEY")
    )


def collect_aws_costs(days: int = 7) -> List[NormalizedCostRecord]:
    """
    Collect AWS costs for the last N days via Cost Explorer
    Returns normalized cost records
    """
    ce = get_aws_client("ce", region="us-east-1")  # Cost Explorer is global

    end_date = datetime.utcnow().strftime("%Y-%m-%d")
    start_date = (datetime.utcnow() - timedelta(days=days)).strftime("%Y-%m-%d")

    try:
        response = ce.get_cost_and_usage(
            TimePeriod={"Start": start_date, "End": end_date},
            Granularity="DAILY",
            Metrics=["BlendedCost", "UsageQuantity"],
            GroupBy=[
                {"Type": "DIMENSION", "Key": "SERVICE"},
                {"Type": "DIMENSION", "Key": "REGION"}
            ]
        )

        records = []
        for result in response.get("ResultsByTime", []):
            for group in result.get("Groups", []):
                keys = group.get("Keys", [])
                raw = {
                    "Service": keys[0] if len(keys) > 0 else "Unknown",
                    "Region": keys[1] if len(keys) > 1 else "unknown",
                    "TimePeriod": result.get("TimePeriod", {}),
                    "Metrics": group.get("Metrics", {}),
                    "Groups": [group]
                }
                records.append(normalize_aws(raw))

        print(f"[AWS] Collected {len(records)} cost records ({start_date} → {end_date})")
        return records

    except Exception as e:
        print(f"[AWS] Cost collection failed: {e}")
        return []


def detect_idle_ec2_instances(threshold_cpu: float = 5.0, days: int = 7) -> List[dict]:
    """
    Find EC2 instances with average CPU < threshold over last N days
    These are candidates for stop/terminate
    """
    ec2 = get_aws_client("ec2")
    cw = get_aws_client("cloudwatch")
    idle = []

    try:
        instances = ec2.describe_instances(
            Filters=[{"Name": "instance-state-name", "Values": ["running"]}]
        )

        end_time = datetime.utcnow()
        start_time = end_time - timedelta(days=days)

        for reservation in instances.get("Reservations", []):
            for inst in reservation.get("Instances", []):
                iid = inst["InstanceId"]
                itype = inst.get("InstanceType", "unknown")
                tags = {t["Key"]: t["Value"] for t in inst.get("Tags", [])}
                name = tags.get("Name", iid)

                metrics = cw.get_metric_statistics(
                    Namespace="AWS/EC2",
                    MetricName="CPUUtilization",
                    Dimensions=[{"Name": "InstanceId", "Value": iid}],
                    StartTime=start_time,
                    EndTime=end_time,
                    Period=86400,
                    Statistics=["Average"]
                )

                datapoints = metrics.get("Datapoints", [])
                avg_cpu = (
                    sum(d["Average"] for d in datapoints) / len(datapoints)
                    if datapoints else 0.0
                )

                if avg_cpu < threshold_cpu:
                    idle.append({
                        "cloud": "aws",
                        "resource_id": iid,
                        "resource_name": name,
                        "instance_type": itype,
                        "avg_cpu_percent": round(avg_cpu, 2),
                        "days_checked": days,
                        "tags": tags,
                        "recommendation": f"Instance idle ({avg_cpu:.1f}% avg CPU). Consider stopping or downsizing.",
                        "estimated_monthly_saving_usd": _estimate_ec2_saving(itype)
                    })

        print(f"[AWS] Found {len(idle)} idle EC2 instances")
        return idle

    except Exception as e:
        print(f"[AWS] Idle detection failed: {e}")
        return []


def detect_unattached_volumes() -> List[dict]:
    """Find EBS volumes not attached to any instance"""
    ec2 = get_aws_client("ec2")
    unattached = []

    try:
        volumes = ec2.describe_volumes(
            Filters=[{"Name": "status", "Values": ["available"]}]
        )

        for vol in volumes.get("Volumes", []):
            size_gb = vol.get("Size", 0)
            vol_type = vol.get("VolumeType", "gp2")
            tags = {t["Key"]: t["Value"] for t in vol.get("Tags", [])}

            unattached.append({
                "cloud": "aws",
                "resource_id": vol["VolumeId"],
                "resource_name": tags.get("Name", vol["VolumeId"]),
                "volume_type": vol_type,
                "size_gb": size_gb,
                "tags": tags,
                "recommendation": f"Unattached {vol_type} volume ({size_gb}GB). Delete or snapshot.",
                "estimated_monthly_saving_usd": round(size_gb * 0.10, 2)  # ~$0.10/GB/month gp2
            })

        print(f"[AWS] Found {len(unattached)} unattached EBS volumes")
        return unattached

    except Exception as e:
        print(f"[AWS] Volume scan failed: {e}")
        return []


def _estimate_ec2_saving(instance_type: str) -> float:
    """Rough monthly saving estimate by instance type"""
    price_map = {
        "t2.micro": 8.5, "t2.small": 17, "t2.medium": 34,
        "t3.small": 15, "t3.medium": 30, "t3.large": 60,
        "m5.large": 70, "m5.xlarge": 140, "m5.2xlarge": 280,
        "c5.large": 62, "c5.xlarge": 124
    }
    return price_map.get(instance_type, 50.0)
