# agent/memory.py
# Vector memory layer using ChromaDB — stores past recommendations for context

import os
import json
import hashlib
from datetime import datetime
from typing import List, Optional


def _get_chroma_client():
    """Initialize ChromaDB client"""
    try:
        import chromadb
        host = os.getenv("CHROMADB_HOST", "localhost")
        port = int(os.getenv("CHROMADB_PORT", "8001"))

        try:
            # Try HTTP client first (remote ChromaDB)
            client = chromadb.HttpClient(host=host, port=port)
            client.heartbeat()
            return client
        except Exception:
            # Fall back to local persistent client
            print("[Memory] Using local ChromaDB storage")
            return chromadb.PersistentClient(path="./chroma_storage")

    except ImportError:
        print("[Memory] ChromaDB not installed. Run: pip install chromadb")
        return None


def _get_collection(name: str = "cost_recommendations"):
    """Get or create a ChromaDB collection"""
    client = _get_chroma_client()
    if not client:
        return None
    return client.get_or_create_collection(
        name=name,
        metadata={"description": "CloudCostOps Agent recommendation history"}
    )


def store_recommendation(cloud: str, recommendations: dict, context: dict = {}) -> bool:
    """
    Store a recommendation run in vector memory
    
    Args:
        cloud: Cloud provider (aws|azure|gcp|multi)
        recommendations: LLM recommendations dict
        context: Additional context (cost summary, etc.)
    """
    collection = _get_collection()
    if not collection:
        return False

    try:
        doc_id = hashlib.md5(
            f"{cloud}:{datetime.utcnow().isoformat()}".encode()
        ).hexdigest()

        document = f"""
Cloud: {cloud}
Date: {datetime.utcnow().strftime('%Y-%m-%d')}
Summary: {recommendations.get('summary', '')}
Saving Potential: ${recommendations.get('total_potential_saving_usd', 0):.2f}/month
Quick Wins: {', '.join(recommendations.get('quick_wins', []))}
Top Actions: {json.dumps(recommendations.get('priority_actions', [])[:3])}
"""
        collection.add(
            documents=[document],
            ids=[doc_id],
            metadatas=[{
                "cloud": cloud,
                "date": datetime.utcnow().strftime("%Y-%m-%d"),
                "saving_usd": str(recommendations.get("total_potential_saving_usd", 0)),
                "confidence": str(recommendations.get("confidence", 0))
            }]
        )
        print(f"[Memory] Stored recommendation for {cloud} (ID: {doc_id[:8]}...)")
        return True

    except Exception as e:
        print(f"[Memory] Store failed: {e}")
        return False


def search_past_recommendations(cloud: str, query: str = "", n_results: int = 3) -> List[str]:
    """
    Search past recommendations for similar context
    Used to inject history into LLM prompts
    
    Args:
        cloud: Cloud provider to filter by
        query: Semantic search query
        n_results: Number of past recommendations to return
    """
    collection = _get_collection()
    if not collection:
        return []

    try:
        search_query = query or f"cost optimization recommendations for {cloud}"

        results = collection.query(
            query_texts=[search_query],
            n_results=min(n_results, collection.count()),
            where={"cloud": cloud} if cloud != "multi" else None
        )

        docs = results.get("documents", [[]])[0]
        print(f"[Memory] Found {len(docs)} past recommendations for {cloud}")
        return docs

    except Exception as e:
        print(f"[Memory] Search failed: {e}")
        return []


def get_recommendation_history(days: int = 30) -> List[dict]:
    """Get recent recommendation history for reporting"""
    collection = _get_collection()
    if not collection:
        return []

    try:
        from datetime import timedelta
        cutoff = (datetime.utcnow() - timedelta(days=days)).strftime("%Y-%m-%d")

        results = collection.get(
            where={"date": {"$gte": cutoff}}
        )

        history = []
        for i, doc_id in enumerate(results.get("ids", [])):
            meta = results.get("metadatas", [{}])[i]
            history.append({
                "id": doc_id,
                "cloud": meta.get("cloud"),
                "date": meta.get("date"),
                "saving_usd": float(meta.get("saving_usd", 0)),
                "confidence": float(meta.get("confidence", 0))
            })

        return sorted(history, key=lambda x: x["date"], reverse=True)

    except Exception as e:
        print(f"[Memory] History fetch failed: {e}")
        return []
