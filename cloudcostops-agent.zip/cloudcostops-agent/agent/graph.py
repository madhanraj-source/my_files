# agent/graph.py
# LangGraph-based agentic workflow for CloudCostOps

import os
import json
from typing import TypedDict, List, Optional, Annotated
from datetime import datetime


# ─── Agent State ──────────────────────────────────────────────────────────────

class AgentState(TypedDict):
    clouds: List[str]                  # Which clouds to scan
    days_lookback: int                 # How many days of data
    cost_records: list                 # Raw normalized cost records
    cost_summary: dict                 # Aggregated cost summary
    idle_resources: list               # Detected idle resources
    unattached_storage: list           # Unattached disks/volumes
    anomalies: list                    # Cost anomalies detected
    llm_recommendations: dict          # LLM analysis output
    actions_taken: list                # Auto-applied actions
    notifications_sent: bool           # Whether Slack was notified
    run_id: str                        # Unique run identifier
    errors: list                       # Error log


# ─── Agent Nodes ──────────────────────────────────────────────────────────────

def node_collect_data(state: AgentState) -> AgentState:
    """Node 1: Collect cost data from all configured clouds"""
    from collector.aws_collector import collect_aws_costs, detect_idle_ec2_instances, detect_unattached_volumes
    from collector.azure_collector import collect_azure_costs, detect_idle_azure_vms, detect_unattached_azure_disks
    from collector.gcp_collector import collect_gcp_costs, detect_idle_gcp_instances
    from collector.normalizer import aggregate_costs

    print(f"\n[Agent] 📊 Collecting data from clouds: {state['clouds']}")

    all_records = []
    all_idle = []
    all_storage = []
    errors = state.get("errors", [])

    days = state.get("days_lookback", 7)
    threshold = float(os.getenv("IDLE_CPU_THRESHOLD", "5.0"))

    if "aws" in state["clouds"]:
        try:
            records = collect_aws_costs(days)
            all_records.extend(records)
            idle = detect_idle_ec2_instances(threshold, days)
            all_idle.extend(idle)
            storage = detect_unattached_volumes()
            all_storage.extend(storage)
        except Exception as e:
            errors.append(f"AWS collection error: {e}")
            print(f"[Agent] AWS error: {e}")

    if "azure" in state["clouds"]:
        try:
            records = collect_azure_costs(days)
            all_records.extend(records)
            idle = detect_idle_azure_vms(threshold, days)
            all_idle.extend(idle)
            storage = detect_unattached_azure_disks()
            all_storage.extend(storage)
        except Exception as e:
            errors.append(f"Azure collection error: {e}")
            print(f"[Agent] Azure error: {e}")

    if "gcp" in state["clouds"]:
        try:
            records = collect_gcp_costs(days)
            all_records.extend(records)
            idle = detect_idle_gcp_instances(threshold, days)
            all_idle.extend(idle)
        except Exception as e:
            errors.append(f"GCP collection error: {e}")
            print(f"[Agent] GCP error: {e}")

    cost_summary = aggregate_costs(all_records)

    print(f"[Agent] ✅ Collected {len(all_records)} records, {len(all_idle)} idle resources, {len(all_storage)} storage items")

    return {
        **state,
        "cost_records": [r.to_dict() for r in all_records],
        "cost_summary": cost_summary,
        "idle_resources": all_idle,
        "unattached_storage": all_storage,
        "errors": errors
    }


def node_detect_anomalies(state: AgentState) -> AgentState:
    """Node 2: Detect cost anomalies and spikes"""
    print("[Agent] 🔍 Detecting cost anomalies...")

    threshold_pct = float(os.getenv("COST_ANOMALY_THRESHOLD", "20.0"))
    anomalies = []

    breakdown = state["cost_summary"].get("breakdown", [])

    # Simple spike detection: services with very high individual cost
    total = state["cost_summary"].get("total_cost_usd", 1)
    for item in breakdown:
        cost = item.get("total_cost_usd", 0)
        pct_of_total = (cost / total * 100) if total > 0 else 0

        if pct_of_total > 40:  # Single service > 40% of total
            anomalies.append({
                "type": "high_concentration",
                "cloud": item["cloud"],
                "service": item["service"],
                "cost_usd": cost,
                "pct_of_total": round(pct_of_total, 1),
                "message": f"{item['service']} on {item['cloud']} is {pct_of_total:.0f}% of total spend"
            })

    print(f"[Agent] Found {len(anomalies)} anomalies")
    return {**state, "anomalies": anomalies}


def node_analyze_with_llm(state: AgentState) -> AgentState:
    """Node 3: LLM-powered analysis and recommendations"""
    from agent.llm import analyze_costs_with_llm
    from agent.memory import search_past_recommendations, store_recommendation

    print("[Agent] 🤖 Running LLM cost analysis...")

    # Fetch past recommendations for context
    cloud_key = "+".join(state["clouds"])
    past_context = search_past_recommendations(cloud_key)
    if past_context:
        print(f"[Agent] Injecting {len(past_context)} past recommendations as context")

    # Combine idle + storage as resources list
    all_idle = state["idle_resources"] + state["unattached_storage"]

    recommendations = analyze_costs_with_llm(
        cost_summary=state["cost_summary"],
        idle_resources=all_idle,
        anomalies=state["anomalies"]
    )

    # Store in memory for future context
    store_recommendation(cloud_key, recommendations, state["cost_summary"])

    saving = recommendations.get("total_potential_saving_usd", 0)
    print(f"[Agent] 💡 LLM identified ${saving:.2f}/month potential savings")

    return {**state, "llm_recommendations": recommendations}


def node_take_actions(state: AgentState) -> AgentState:
    """Node 4: Auto-apply SAFE actions only"""
    from actions.slack_notify import send_slack_notification

    print("[Agent] ⚡ Evaluating auto-actions...")
    actions_taken = []

    priority_actions = state["llm_recommendations"].get("priority_actions", [])

    for action in priority_actions:
        if action.get("risk") == "safe" and action.get("effort") == "low":
            # Currently log safe actions — expand in Month 5 for actual execution
            actions_taken.append({
                "action": action["action"],
                "cloud": action["cloud"],
                "saving_usd": action.get("saving_usd", 0),
                "status": "logged",  # Change to "executed" in Month 5
                "timestamp": datetime.utcnow().isoformat()
            })
            print(f"[Agent] ✅ Auto-action logged: {action['action'][:60]}...")

    print(f"[Agent] {len(actions_taken)} safe actions logged")
    return {**state, "actions_taken": actions_taken}


def node_notify(state: AgentState) -> AgentState:
    """Node 5: Send Slack notification with results"""
    from actions.slack_notify import send_slack_notification

    print("[Agent] 📢 Sending Slack notification...")

    success = send_slack_notification(
        cost_summary=state["cost_summary"],
        recommendations=state["llm_recommendations"],
        idle_count=len(state["idle_resources"]),
        storage_count=len(state["unattached_storage"]),
        actions_taken=state["actions_taken"],
        run_id=state["run_id"]
    )

    return {**state, "notifications_sent": success}


# ─── Build Graph ───────────────────────────────────────────────────────────────

def build_agent():
    """Build and compile the LangGraph agent"""
    try:
        from langgraph.graph import StateGraph, END

        workflow = StateGraph(AgentState)

        workflow.add_node("collect_data", node_collect_data)
        workflow.add_node("detect_anomalies", node_detect_anomalies)
        workflow.add_node("analyze_with_llm", node_analyze_with_llm)
        workflow.add_node("take_actions", node_take_actions)
        workflow.add_node("notify", node_notify)

        workflow.set_entry_point("collect_data")
        workflow.add_edge("collect_data", "detect_anomalies")
        workflow.add_edge("detect_anomalies", "analyze_with_llm")
        workflow.add_edge("analyze_with_llm", "take_actions")
        workflow.add_edge("take_actions", "notify")
        workflow.add_edge("notify", END)

        return workflow.compile()

    except ImportError:
        print("[Agent] LangGraph not installed. Using sequential fallback.")
        return None


def run_agent(clouds: List[str] = None, days: int = 7) -> dict:
    """
    Run the CloudCostOps Agent
    
    Args:
        clouds: List of clouds to scan ['aws', 'azure', 'gcp']
        days: Days of historical data to analyze
    
    Returns:
        Final agent state with all results
    """
    import uuid

    clouds = clouds or _detect_configured_clouds()
    run_id = str(uuid.uuid4())[:8]

    print(f"\n{'='*60}")
    print(f"  CloudCostOps Agent — Run {run_id}")
    print(f"  Clouds: {clouds} | Lookback: {days} days")
    print(f"{'='*60}\n")

    initial_state: AgentState = {
        "clouds": clouds,
        "days_lookback": days,
        "cost_records": [],
        "cost_summary": {},
        "idle_resources": [],
        "unattached_storage": [],
        "anomalies": [],
        "llm_recommendations": {},
        "actions_taken": [],
        "notifications_sent": False,
        "run_id": run_id,
        "errors": []
    }

    agent = build_agent()

    if agent:
        final_state = agent.invoke(initial_state)
    else:
        # Sequential fallback without LangGraph
        state = node_collect_data(initial_state)
        state = node_detect_anomalies(state)
        state = node_analyze_with_llm(state)
        state = node_take_actions(state)
        final_state = node_notify(state)

    print(f"\n[Agent] ✅ Run {run_id} complete")
    return final_state


def _detect_configured_clouds() -> List[str]:
    """Auto-detect which clouds are configured via env vars"""
    clouds = []
    if os.getenv("AWS_ACCESS_KEY_ID"):
        clouds.append("aws")
    if os.getenv("AZURE_SUBSCRIPTION_ID"):
        clouds.append("azure")
    if os.getenv("GCP_PROJECT_ID"):
        clouds.append("gcp")
    return clouds or ["aws"]  # Default to AWS
