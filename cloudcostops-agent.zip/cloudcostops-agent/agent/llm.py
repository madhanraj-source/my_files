# agent/llm.py
# LLM abstraction layer — switch between local Ollama and hosted LLMs

import os
import json
import requests
from typing import Optional


def get_llm_response(prompt: str, system: str = "", use_local: Optional[bool] = None) -> str:
    """
    Universal LLM caller — auto-switches between local and hosted.
    
    Priority:
    1. USE_LOCAL_LLM env var (true → Ollama, false → hosted)
    2. Falls back to hosted if Ollama is unreachable
    
    Args:
        prompt: User prompt
        system: System instruction
        use_local: Override env setting if provided
    
    Returns:
        LLM response as string
    """
    if use_local is None:
        use_local = os.getenv("USE_LOCAL_LLM", "true").lower() == "true"

    if use_local:
        response = _call_ollama(prompt, system)
        if response:
            return response
        print("[LLM] Ollama unavailable — falling back to hosted LLM")

    return _call_hosted_llm(prompt, system)


def _call_ollama(prompt: str, system: str = "") -> Optional[str]:
    """Call local Ollama server"""
    base_url = os.getenv("LOCAL_LLM_URL", "http://localhost:11434")
    model = os.getenv("LOCAL_LLM_MODEL", "mistral")

    full_prompt = f"{system}\n\n{prompt}" if system else prompt

    try:
        response = requests.post(
            f"{base_url}/api/generate",
            json={
                "model": model,
                "prompt": full_prompt,
                "stream": False,
                "options": {
                    "temperature": 0.3,
                    "top_p": 0.9
                }
            },
            timeout=120
        )
        response.raise_for_status()
        return response.json().get("response", "")

    except requests.exceptions.ConnectionError:
        print(f"[LLM] Cannot connect to Ollama at {base_url}")
        return None
    except Exception as e:
        print(f"[LLM] Ollama error: {e}")
        return None


def _call_hosted_llm(prompt: str, system: str = "") -> str:
    """Call hosted LLM — Anthropic, OpenAI, or Gemini"""
    provider = os.getenv("LLM_PROVIDER", "anthropic").lower()

    if provider == "anthropic":
        return _call_anthropic(prompt, system)
    elif provider == "openai":
        return _call_openai(prompt, system)
    else:
        return _call_anthropic(prompt, system)  # Default to Anthropic


def _call_anthropic(prompt: str, system: str = "") -> str:
    """Call Anthropic Claude API"""
    try:
        import anthropic
        client = anthropic.Anthropic(api_key=os.getenv("ANTHROPIC_API_KEY"))

        kwargs = {
            "model": "claude-opus-4-5",
            "max_tokens": 2000,
            "messages": [{"role": "user", "content": prompt}]
        }
        if system:
            kwargs["system"] = system

        response = client.messages.create(**kwargs)
        return response.content[0].text

    except Exception as e:
        print(f"[LLM] Anthropic error: {e}")
        return f"LLM Error: {e}"


def _call_openai(prompt: str, system: str = "") -> str:
    """Call OpenAI API"""
    try:
        from openai import OpenAI
        client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

        messages = []
        if system:
            messages.append({"role": "system", "content": system})
        messages.append({"role": "user", "content": prompt})

        response = client.chat.completions.create(
            model="gpt-4o",
            messages=messages,
            temperature=0.3
        )
        return response.choices[0].message.content

    except Exception as e:
        print(f"[LLM] OpenAI error: {e}")
        return f"LLM Error: {e}"


def analyze_costs_with_llm(cost_summary: dict, idle_resources: list, anomalies: list = []) -> dict:
    """
    Core cost analysis prompt — structured LLM output for recommendations
    Returns parsed JSON recommendations
    """
    system = """You are a FinOps expert and Senior Cloud Cost Optimization Engineer.
Analyze cloud cost data and return ONLY valid JSON — no markdown, no preamble.
Be specific, actionable, and quantify savings wherever possible."""

    prompt = f"""Analyze this multi-cloud cost data and provide optimization recommendations.

COST SUMMARY:
{json.dumps(cost_summary, indent=2)}

IDLE RESOURCES DETECTED:
{json.dumps(idle_resources[:10], indent=2)}

ANOMALIES:
{json.dumps(anomalies, indent=2)}

Return a JSON object with this exact structure:
{{
  "total_potential_saving_usd": <number>,
  "saving_percentage": <number>,
  "priority_actions": [
    {{
      "action": "<specific action to take>",
      "resource_id": "<resource ID or 'multiple'>",
      "cloud": "<aws|azure|gcp|all>",
      "saving_usd": <monthly saving estimate>,
      "risk": "<safe|medium|high>",
      "effort": "<low|medium|high>",
      "category": "<idle|rightsizing|reservation|storage|tagging|other>",
      "reasoning": "<1-2 sentences why>"
    }}
  ],
  "quick_wins": ["<action 1>", "<action 2>", "<action 3>"],
  "summary": "<2-3 sentence executive summary>",
  "confidence": <0-100>
}}"""

    raw_response = get_llm_response(prompt, system)

    try:
        # Clean response in case LLM adds markdown
        cleaned = raw_response.strip()
        if cleaned.startswith("```"):
            cleaned = cleaned.split("```")[1]
            if cleaned.startswith("json"):
                cleaned = cleaned[4:]
        return json.loads(cleaned)
    except json.JSONDecodeError:
        print(f"[LLM] Failed to parse JSON response. Raw: {raw_response[:200]}")
        return {
            "total_potential_saving_usd": 0,
            "saving_percentage": 0,
            "priority_actions": [],
            "quick_wins": [],
            "summary": raw_response[:500],
            "confidence": 0
        }
