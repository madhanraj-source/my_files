# actions/slack_notify.py
# Sends formatted cost optimization reports to Slack

import os
import json
import requests
from datetime import datetime
from typing import List


def send_slack_notification(
    cost_summary: dict,
    recommendations: dict,
    idle_count: int = 0,
    storage_count: int = 0,
    actions_taken: list = [],
    run_id: str = "unknown"
) -> bool:
    """
    Send a rich Slack message with cost optimization findings
    
    Returns True if notification was sent successfully
    """
    webhook_url = os.getenv("SLACK_WEBHOOK_URL")
    if not webhook_url:
        print("[Slack] SLACK_WEBHOOK_URL not set — skipping notification")
        return False

    total_cost = cost_summary.get("total_cost_usd", 0)
    saving_potential = recommendations.get("total_potential_saving_usd", 0)
    saving_pct = recommendations.get("saving_percentage", 0)
    summary = recommendations.get("summary", "No summary available")
    quick_wins = recommendations.get("quick_wins", [])
    priority_actions = recommendations.get("priority_actions", [])[:5]
    confidence = recommendations.get("confidence", 0)

    # Build priority actions text
    actions_text = ""
    for i, action in enumerate(priority_actions, 1):
        risk_emoji = {"safe": "🟢", "medium": "🟡", "high": "🔴"}.get(action.get("risk"), "⚪")
        saving = action.get("saving_usd", 0)
        actions_text += f"{i}. {risk_emoji} *{action.get('action', 'N/A')}*\n"
        actions_text += f"   └ Cloud: `{action.get('cloud', 'N/A')}` | Saving: `${saving:.0f}/mo` | Risk: `{action.get('risk', 'N/A')}`\n"

    # Build quick wins text
    wins_text = "\n".join([f"• {w}" for w in quick_wins[:3]]) or "No quick wins identified"

    blocks = [
        {
            "type": "header",
            "text": {
                "type": "plain_text",
                "text": "💰 CloudCostOps Agent — Daily Report",
                "emoji": True
            }
        },
        {
            "type": "section",
            "fields": [
                {"type": "mrkdwn", "text": f"*Run ID:*\n`{run_id}`"},
                {"type": "mrkdwn", "text": f"*Date:*\n{datetime.utcnow().strftime('%Y-%m-%d %H:%M UTC')}"},
                {"type": "mrkdwn", "text": f"*Total Cloud Spend:*\n`${total_cost:,.2f}`"},
                {"type": "mrkdwn", "text": f"*Saving Potential:*\n`${saving_potential:,.2f}/month ({saving_pct:.1f}%)`"},
                {"type": "mrkdwn", "text": f"*Idle Resources:*\n`{idle_count}` found"},
                {"type": "mrkdwn", "text": f"*Unattached Storage:*\n`{storage_count}` found"},
            ]
        },
        {"type": "divider"},
        {
            "type": "section",
            "text": {"type": "mrkdwn", "text": f"*🤖 AI Summary* (Confidence: {confidence}%)\n{summary}"}
        },
        {"type": "divider"},
        {
            "type": "section",
            "text": {"type": "mrkdwn", "text": f"*🎯 Top Priority Actions*\n\n{actions_text}"}
        },
        {
            "type": "section",
            "text": {"type": "mrkdwn", "text": f"*⚡ Quick Wins*\n{wins_text}"}
        }
    ]

    if actions_taken:
        auto_text = "\n".join([f"• ✅ {a['action'][:60]}..." for a in actions_taken[:3]])
        blocks.append({
            "type": "section",
            "text": {"type": "mrkdwn", "text": f"*🤖 Auto-Actions Logged*\n{auto_text}"}
        })

    if cost_summary.get("record_count", 0) == 0:
        blocks.append({
            "type": "section",
            "text": {"type": "mrkdwn", "text": "⚠️ *No cost data collected* — check cloud credentials in `.env`"}
        })

    payload = {
        "username": "CloudCostOps Agent",
        "icon_emoji": ":moneybag:",
        "blocks": blocks
    }

    try:
        response = requests.post(
            webhook_url,
            data=json.dumps(payload),
            headers={"Content-Type": "application/json"},
            timeout=10
        )
        response.raise_for_status()
        print(f"[Slack] ✅ Notification sent successfully")
        return True

    except Exception as e:
        print(f"[Slack] ❌ Failed to send notification: {e}")
        return False


def send_alert(message: str, level: str = "info") -> bool:
    """Send a simple text alert to Slack"""
    webhook_url = os.getenv("SLACK_WEBHOOK_URL")
    if not webhook_url:
        return False

    emoji = {"info": "ℹ️", "warning": "⚠️", "critical": "🚨"}.get(level, "ℹ️")

    payload = {
        "text": f"{emoji} *CloudCostOps Agent*: {message}",
        "username": "CloudCostOps Agent",
        "icon_emoji": ":moneybag:"
    }

    try:
        response = requests.post(webhook_url, json=payload, timeout=10)
        response.raise_for_status()
        return True
    except Exception as e:
        print(f"[Slack] Alert failed: {e}")
        return False
