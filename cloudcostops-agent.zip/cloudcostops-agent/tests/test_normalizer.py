# tests/test_normalizer.py
# Unit tests for cost data normalizer

import pytest
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from collector.normalizer import (
    normalize_aws, normalize_azure, normalize_gcp,
    aggregate_costs, NormalizedCostRecord
)


def test_normalize_aws_basic():
    raw = {
        "Service": "Amazon EC2",
        "Region": "ap-south-1",
        "TimePeriod": {"Start": "2025-01-01"},
        "ResourceId": "i-0abc12345",
        "ResourceName": "build-server-01",
        "Groups": [{"Metrics": {"BlendedCost": {"Amount": "125.50"}, "UsageQuantity": {"Amount": "720"}}}],
        "Tags": {"Project": "QuickShare", "Env": "prod"}
    }
    record = normalize_aws(raw)
    assert record.cloud == "aws"
    assert record.service == "Amazon EC2"
    assert record.region == "ap-south-1"
    assert record.cost_usd == 125.5
    assert record.tags == {"Project": "QuickShare", "Env": "prod"}


def test_normalize_azure_basic():
    raw = {
        "meterCategory": "Virtual Machines",
        "resourceId": "/subscriptions/xxx/resourceGroups/rg-devinfra/providers/Microsoft.Compute/virtualMachines/aks-node-01",
        "resourceName": "aks-node-01",
        "resourceLocation": "southindia",
        "pretaxCost": 89.25,
        "quantity": 744.0,
        "date": "2025-01-01",
        "subscriptionId": "sub-123"
    }
    record = normalize_azure(raw)
    assert record.cloud == "azure"
    assert record.service == "Virtual Machines"
    assert record.cost_usd == 89.25


def test_normalize_gcp_basic():
    raw = {
        "service": {"description": "Compute Engine"},
        "resource": {"name": "instance-1", "global_name": "projects/my-project/zones/us-central1-a/instances/instance-1"},
        "location": {"region": "us-central1"},
        "cost": {"units": 50, "nanos": 500000000},
        "usage": {"amount": 720.0},
        "labels": [{"key": "env", "value": "dev"}],
        "usage_start_time": "2025-01-01T00:00:00Z",
        "billing_account_id": "my-project",
        "sku": {"description": "N1 Predefined Instance Core"}
    }
    record = normalize_gcp(raw)
    assert record.cloud == "gcp"
    assert record.cost_usd == 50.5
    assert record.tags == {"env": "dev"}


def test_aggregate_costs():
    records = [
        NormalizedCostRecord("aws", "EC2", "i-1", "server-1", "ap-south-1", 100.0, 720.0),
        NormalizedCostRecord("aws", "S3", "bucket-1", "data-bucket", "ap-south-1", 15.0, 100.0),
        NormalizedCostRecord("azure", "Virtual Machines", "vm-1", "node-1", "southindia", 80.0, 744.0),
    ]
    summary = aggregate_costs(records)
    assert summary["total_cost_usd"] == 195.0
    assert summary["record_count"] == 3
    assert len(summary["breakdown"]) == 3


def test_record_to_dict():
    record = NormalizedCostRecord(
        cloud="aws", service="EC2", resource_id="i-1",
        resource_name="server", region="ap-south-1",
        cost_usd=50.0, usage_hours=720.0,
        tags={"Project": "Camera"}
    )
    d = record.to_dict()
    assert isinstance(d, dict)
    assert d["cloud"] == "aws"
    assert d["tags"]["Project"] == "Camera"
