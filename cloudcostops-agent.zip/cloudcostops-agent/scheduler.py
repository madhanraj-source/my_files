# scheduler.py
# Daily/weekly scheduled scans using APScheduler

import os
from datetime import datetime
from apscheduler.schedulers.blocking import BlockingScheduler
from dotenv import load_dotenv

load_dotenv()

scheduler = BlockingScheduler()


@scheduler.scheduled_job(
    'cron',
    hour=int(os.getenv("DAILY_SCAN_TIME", "08:00").split(":")[0]),
    minute=int(os.getenv("DAILY_SCAN_TIME", "08:00").split(":")[1]),
    id='daily_cost_scan'
)
def daily_scan():
    """Run full cost scan every day"""
    from agent.graph import run_agent
    print(f"[Scheduler] Starting daily scan at {datetime.utcnow().isoformat()}")
    run_agent(days=7)


@scheduler.scheduled_job(
    'cron',
    day_of_week='mon',
    hour=9,
    minute=0,
    id='weekly_report'
)
def weekly_report():
    """Generate weekly PDF report every Monday"""
    print(f"[Scheduler] Generating weekly report at {datetime.utcnow().isoformat()}")
    # TODO: Month 6 — add PDF report generation here


if __name__ == "__main__":
    print("[Scheduler] CloudCostOps scheduled jobs started")
    print(f"  Daily scan at: {os.getenv('DAILY_SCAN_TIME', '08:00')} UTC")
    print("  Weekly report: Every Monday at 09:00 UTC")
    scheduler.start()
