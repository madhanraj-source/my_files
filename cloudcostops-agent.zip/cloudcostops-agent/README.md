# ☁️ CloudCostOps Agent
### AI-Powered Multi-Cloud Cost Optimization Agent

> Autonomous AI agent that analyzes cloud spend across AWS, Azure, and GCP — detects waste, recommends optimizations, and takes safe corrective actions. Powered by local LLM (Ollama/Mistral) or hosted LLM (Claude/GPT-4o).

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     CloudCostOps Agent                          │
├─────────────────────────────────────────────────────────────────┤
│  COLLECT → DETECT ANOMALIES → LLM ANALYZE → ACT → NOTIFY       │
├─────────────────────────────────────────────────────────────────┤
│  AWS Cost Explorer │ Azure Cost Mgmt │ GCP Billing API          │
│  Unified Normalizer → ChromaDB Memory → LangGraph Agent         │
│  Ollama (local Mistral) ↔ Anthropic/OpenAI (hosted fallback)    │
│  Slack Notifications │ FastAPI REST API │ Grafana Dashboard      │
└─────────────────────────────────────────────────────────────────┘
```

---

## 📁 Project Structure

```
cloudcostops-agent/
├── collector/          # Cloud data collectors (AWS, Azure, GCP)
│   ├── aws_collector.py
│   ├── azure_collector.py
│   ├── gcp_collector.py
│   └── normalizer.py   # Unified cost schema
├── agent/              # AI agent core
│   ├── graph.py        # LangGraph state machine
│   ├── llm.py          # LLM abstraction (local/hosted)
│   └── memory.py       # ChromaDB vector memory
├── actions/            # Agent action layer
│   └── slack_notify.py # Slack notifications
├── api/                # REST API
│   └── main.py         # FastAPI application
├── config/             # Configuration files
│   └── prometheus.yml
├── tests/              # Unit tests
├── run.py              # CLI entry point
├── scheduler.py        # Daily/weekly scheduled scans
├── docker-compose.yml  # Full stack deployment
├── Dockerfile
├── requirements.txt
└── .env.example        # Configuration template
```

---

## 🚀 Quick Start

### Option A — Local (Python)

```bash
# 1. Clone and setup
git clone <repo>
cd cloudcostops-agent
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

# 2. Configure environment
cp .env.example .env
# Edit .env — add your cloud credentials and LLM settings

# 3. Pull local LLM model (optional — skip if using hosted)
curl -fsSL https://ollama.com/install.sh | sh
ollama pull mistral

# 4. Run agent
python run.py --clouds aws --days 7

# Quick idle detection only (no LLM needed)
python run.py --idle-only --clouds aws
```

### Option B — Docker Compose (Recommended)

```bash
# 1. Configure
cp .env.example .env
# Edit .env with your credentials

# 2. Start full stack (API + Ollama + ChromaDB + Grafana)
docker-compose up -d

# 3. Wait for Ollama to pull Mistral (~3 mins first time)
docker-compose logs -f ollama

# 4. Trigger a scan via API
curl -X POST http://localhost:8000/scan/sync \
  -H "Content-Type: application/json" \
  -d '{"clouds": ["aws"], "days": 7}'

# 5. View Grafana dashboard
open http://localhost:3000   # admin / admin123
```

---

## ⚙️ Configuration

Copy `.env.example` to `.env` and fill in values:

```bash
# LLM — choose local or hosted
USE_LOCAL_LLM=true
LOCAL_LLM_MODEL=mistral          # or llama3, codellama

# If USE_LOCAL_LLM=false, set hosted provider
LLM_PROVIDER=anthropic
ANTHROPIC_API_KEY=sk-ant-...

# AWS
AWS_ACCESS_KEY_ID=AKIA...
AWS_SECRET_ACCESS_KEY=...
AWS_DEFAULT_REGION=ap-south-1

# Azure
AZURE_SUBSCRIPTION_ID=...
AZURE_TENANT_ID=...
AZURE_CLIENT_ID=...
AZURE_CLIENT_SECRET=...

# Slack
SLACK_WEBHOOK_URL=https://hooks.slack.com/...
```

---

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/health` | Health check + LLM mode |
| POST | `/scan` | Trigger async scan |
| POST | `/scan/sync` | Trigger sync scan (wait for result) |
| GET | `/runs` | List all scan history |
| GET | `/runs/{run_id}` | Get specific run results |
| GET | `/idle-resources` | Quick idle detection only |
| GET | `/recommendations/history` | Past recommendations |

**Interactive Docs:** http://localhost:8000/docs

---

## 🖥️ CLI Usage

```bash
# Full scan — auto-detect clouds from .env
python run.py

# Scan specific clouds
python run.py --clouds aws azure

# Last 14 days of data
python run.py --days 14

# Fast idle detection (no LLM, no Slack)
python run.py --idle-only --no-slack

# Multi-cloud
python run.py --clouds aws azure gcp --days 7
```

---

## 🧪 Running Tests

```bash
pytest tests/ -v
```

---

## 📅 6-Month Roadmap

| Month | Focus | Key Deliverable |
|-------|-------|----------------|
| 1 ✅ | Foundation | AWS/Azure collectors, LLM diagnosis, Slack alerts |
| 2 | Memory | ChromaDB learning, semantic search, confidence scoring |
| 3 | Multi-cloud | GCP + OpenCost (K8s) + Steampipe SQL queries |
| 4 | Prediction | Cost spike alerts, budget breach forecast, flaky detector |
| 5 | Auto-action | Tag fixer, idle cleanup, Terraform rightsizing PRs |
| 6 | Dashboard | Grafana, weekly PDF report, Samsung INN submission |

---

## 💰 Expected Impact

| Optimization | Typical Saving |
|---|---|
| Idle compute cleanup | 15–25% |
| Rightsizing | 20–30% |
| Reserved Instance advice | 30–40% |
| Unattached storage | 5–10% |
| **Total (non-prod)** | **~40–50%** |

---

## 🛠️ Tech Stack

| Component | Technology |
|---|---|
| Agent Framework | LangGraph |
| LLM (local) | Ollama + Mistral 7B |
| LLM (hosted) | Anthropic Claude / OpenAI GPT-4o |
| Vector Memory | ChromaDB |
| API | FastAPI |
| Metrics | Prometheus + Grafana |
| Notifications | Slack Webhooks |
| Scheduler | APScheduler |
| Containers | Docker + Docker Compose |

---

## 🤝 Contributing

Built for Samsung DevInfra Team — CloudCostOps Innovation (INN-01).
Ekambaram | Senior Chief Engineer — Cloud & DevOps
